import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import PrescriptionAnalyzer from './pages/PrescriptionAnalyzer';
import DrugChecker from './pages/DrugChecker';
import PillIdentifier from './pages/PillIdentifier';
import Reminders from './pages/Reminders';
import ChatAssistant from './pages/ChatAssistant';
import Profile from './pages/Profile';
import MedicationHistory from './pages/MedicationHistory';
import CaregiverMode from './pages/CaregiverMode';
import SymptomChecker from './components/SymptomChecker';
import SymptomHistory from './pages/SymptomHistory';
import Login from './pages/Login';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { NotificationProvider } from './contexts/NotificationContext';
import { LanguageProvider } from './contexts/LanguageContext';
import EmergencyAlert from './components/EmergencyAlert';

function AppContent() {
  const { user, loading } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      <Header onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
      <div className="flex min-h-[calc(100vh-4rem)]">
        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          isCollapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
        <main className={`flex-1 p-4 md:p-6 transition-all duration-300 ${
          sidebarCollapsed ? 'lg:ml-0' : 'lg:ml-0'
        }`}>
          <EmergencyAlert />
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/prescription" element={<PrescriptionAnalyzer />} />
            <Route path="/drug-checker" element={<DrugChecker />} />
            <Route path="/pill-identifier" element={<PillIdentifier />} />
            <Route path="/reminders" element={<Reminders />} />
            <Route path="/chat" element={<ChatAssistant />} />
            <Route path="/symptom-checker" element={<SymptomChecker />} />
            <Route path="/symptom-history" element={<SymptomHistory />} />
            <Route path="/history" element={<MedicationHistory />} />
            <Route path="/caregiver" element={<CaregiverMode />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <NotificationProvider>
          <Router>
            <AppContent />
          </Router>
        </NotificationProvider>
      </LanguageProvider>
    </AuthProvider>
  );
}

export default App;