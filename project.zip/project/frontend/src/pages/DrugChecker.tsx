import React, { useState } from 'react';
import { Search, Plus, X, AlertTriangle, CheckCircle, Shield } from 'lucide-react';
import { useNotification } from '../contexts/NotificationContext';
import Together from 'together-ai';

interface Medication {
  id: string;
  name: string;
  dosage: string;
}

interface InteractionResult {
  severity: 'low' | 'moderate' | 'high' | 'severe';
  description: string;
  recommendation: string;
  medications: string[];
}

interface SideEffectResult {
  medication: string;
  commonSideEffects: string[];
  seriousSideEffects: string[];
  warnings: string[];
  contraindications: string[];
  dosageInfo: string;
  storage: string;
}

export default function DrugChecker() {
  const [medications, setMedications] = useState<Medication[]>([]);
  const [newMedication, setNewMedication] = useState({ name: '', dosage: '' });
  const [searchQuery, setSearchQuery] = useState('');
  const [interactions, setInteractions] = useState<InteractionResult[]>([]);
  const [sideEffects, setSideEffects] = useState<SideEffectResult[]>([]);
  const [selectedMedication, setSelectedMedication] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [sideEffectsLoading, setSideEffectsLoading] = useState(false);

  const { addNotification } = useNotification();

  const together = new Together({
    apiKey: import.meta.env.VITE_TOGETHER_API_KEY || '7323b782a40ca2bdbdf780016aeb8662befc0894c9f4e5385bfcdde33f5147a1'
  });

  const addMedication = () => {
    if (!newMedication.name.trim()) {
      addNotification({
        type: 'error',
        title: 'Invalid Input',
        message: 'Please enter a medication name'
      });
      return;
    }

    const medication: Medication = {
      id: Date.now().toString(),
      name: newMedication.name.trim(),
      dosage: newMedication.dosage.trim()
    };

    setMedications([...medications, medication]);
    setNewMedication({ name: '', dosage: '' });
    
    addNotification({
      type: 'success',
      title: 'Medication Added',
      message: `${medication.name} added to your list`
    });
  };

  const removeMedication = (id: string) => {
    setMedications(medications.filter(med => med.id !== id));
  };

  const checkInteractions = async () => {
    if (medications.length < 2) {
      addNotification({
        type: 'error',
        title: 'Insufficient Medications',
        message: 'Please add at least 2 medications to check for interactions'
      });
      return;
    }

    setLoading(true);

    try {
      const medicationList = medications.map(med => `${med.name} ${med.dosage}`).join(', ');

      const prompt = `Analyze drug interactions for these medications: ${medicationList}

Please provide a comprehensive analysis in JSON format with this structure:
[
  {
    "severity": "low|moderate|high|severe",
    "description": "detailed description of the interaction",
    "recommendation": "clinical recommendation",
    "medications": ["med1", "med2"]
  }
]

If no significant interactions are found, return an empty array: []`;

      const response = await together.chat.completions.create({
        messages: [{ role: "user", content: prompt }],
        model: "mistralai/Mistral-7B-Instruct-v0.1",
        max_tokens: 1500,
        temperature: 0.1
      });

      const content = response.choices[0]?.message?.content;
      if (content) {
        try {
          const jsonStart = content.indexOf('[');
          const jsonEnd = content.lastIndexOf(']') + 1;
          const jsonStr = content.slice(jsonStart, jsonEnd);
          const parsedInteractions = JSON.parse(jsonStr);
          setInteractions(parsedInteractions);

          addNotification({
            type: 'success',
            title: 'Analysis Complete',
            message: `Found ${parsedInteractions.length} potential interactions`
          });
        } catch (parseError) {
          throw new Error('Failed to parse AI response');
        }
      }
    } catch (error: any) {
      console.error('Interaction check error:', error);
      addNotification({
        type: 'error',
        title: 'Analysis Failed',
        message: error.message || 'Failed to check drug interactions'
      });
    } finally {
      setLoading(false);
    }
  };

  const getSideEffects = async (medication: Medication) => {
    setSideEffectsLoading(true);
    setSelectedMedication(medication.id);

    try {
      const prompt = `Provide detailed side effect information for ${medication.name} ${medication.dosage}

Please provide comprehensive information in JSON format with this structure:
{
  "medication": "${medication.name}",
  "commonSideEffects": ["list of common side effects"],
  "seriousSideEffects": ["list of serious side effects"],
  "warnings": ["list of warnings and precautions"],
  "contraindications": ["list of contraindications"],
  "dosageInfo": "dosage and administration information",
  "storage": "storage instructions"
}`;

      const response = await together.chat.completions.create({
        messages: [{ role: "user", content: prompt }],
        model: "mistralai/Mistral-7B-Instruct-v0.1",
        max_tokens: 1000,
        temperature: 0.1
      });

      const content = response.choices[0]?.message?.content;
      if (content) {
        try {
          const jsonStart = content.indexOf('{');
          const jsonEnd = content.lastIndexOf('}') + 1;
          const jsonStr = content.slice(jsonStart, jsonEnd);
          const parsedSideEffects = JSON.parse(jsonStr);

          // Update or add to side effects array
          setSideEffects(prev => {
            const existing = prev.findIndex(se => se.medication === medication.name);
            if (existing >= 0) {
              const updated = [...prev];
              updated[existing] = parsedSideEffects;
              return updated;
            } else {
              return [...prev, parsedSideEffects];
            }
          });

          addNotification({
            type: 'success',
            title: 'Side Effects Retrieved',
            message: `Side effect information for ${medication.name} loaded successfully`
          });
        } catch (parseError) {
          throw new Error('Failed to parse side effects response');
        }
      }
    } catch (error: any) {
      console.error('Side effects error:', error);
      addNotification({
        type: 'error',
        title: 'Side Effects Failed',
        message: error.message || 'Failed to get side effect information'
      });
    } finally {
      setSideEffectsLoading(false);
      setSelectedMedication(null);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'text-green-700 bg-green-50 border-green-200';
      case 'moderate': return 'text-yellow-700 bg-yellow-50 border-yellow-200';
      case 'high': return 'text-orange-700 bg-orange-50 border-orange-200';
      case 'severe': return 'text-red-700 bg-red-50 border-red-200';
      default: return 'text-gray-700 bg-gray-50 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'low': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'moderate': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'high': return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      case 'severe': return <AlertTriangle className="h-5 w-5 text-red-500" />;
      default: return <Shield className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Drug Interaction Checker</h1>
        <div className="text-sm text-gray-500">
          Check for medication interactions
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Medication List */}
        <div className="space-y-6">
          {/* Add Medication */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Add Medications</h3>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="medication-name" className="block text-sm font-medium text-gray-700">
                  Medication Name
                </label>
                <input
                  type="text"
                  id="medication-name"
                  value={newMedication.name}
                  onChange={(e) => setNewMedication({...newMedication, name: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., Metformin"
                />
              </div>
              
              <div>
                <label htmlFor="dosage" className="block text-sm font-medium text-gray-700">
                  Dosage (Optional)
                </label>
                <input
                  type="text"
                  id="dosage"
                  value={newMedication.dosage}
                  onChange={(e) => setNewMedication({...newMedication, dosage: e.target.value})}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., 500mg"
                />
              </div>
              
              <button
                onClick={addMedication}
                className="w-full flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Medication
              </button>
            </div>
          </div>

          {/* Current Medications */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Current Medications ({medications.length})</h3>
            
            {medications.length === 0 ? (
              <div className="text-center py-6">
                <Shield className="mx-auto h-12 w-12 text-gray-400" />
                <h4 className="mt-2 text-sm font-medium text-gray-900">No medications added</h4>
                <p className="mt-1 text-sm text-gray-500">Add medications to check for interactions</p>
              </div>
            ) : (
              <div className="space-y-3">
                {medications.map((medication) => (
                  <div key={medication.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">{medication.name}</h4>
                      {medication.dosage && (
                        <p className="text-sm text-gray-500">{medication.dosage}</p>
                      )}
                    </div>
                    <button
                      onClick={() => removeMedication(medication.id)}
                      className="p-1 text-gray-400 hover:text-red-500"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
                
                <button
                  onClick={checkInteractions}
                  disabled={loading || medications.length < 2}
                  className="w-full flex justify-center items-center px-4 py-3 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Checking Interactions...
                    </>
                  ) : (
                    <>
                      <Shield className="h-4 w-4 mr-2" />
                      Check Interactions
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Interaction Results */}
        <div className="space-y-6">
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Interaction Results</h3>
            
            {interactions.length === 0 ? (
              <div className="text-center py-6">
                <Search className="mx-auto h-12 w-12 text-gray-400" />
                <h4 className="mt-2 text-sm font-medium text-gray-900">No interactions checked yet</h4>
                <p className="mt-1 text-sm text-gray-500">Add medications and check for interactions</p>
              </div>
            ) : (
              <div className="space-y-4">
                {interactions.map((interaction, index) => (
                  <div key={index} className={`border rounded-lg p-4 ${getSeverityColor(interaction.severity)}`}>
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        {getSeverityIcon(interaction.severity)}
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex items-center">
                          <h4 className="text-sm font-medium capitalize">
                            {interaction.severity} Severity
                          </h4>
                          <span className="ml-2 text-xs px-2 py-1 rounded-full bg-white bg-opacity-50">
                            {interaction.medications.join(' + ')}
                          </span>
                        </div>
                        <p className="mt-2 text-sm">{interaction.description}</p>
                        <div className="mt-3 p-3 bg-white bg-opacity-50 rounded-md">
                          <h5 className="text-xs font-medium uppercase tracking-wide">Recommendation</h5>
                          <p className="mt-1 text-sm">{interaction.recommendation}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Side Effect Checker */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Individual Side Effects</h3>
            <div className="space-y-3">
              {medications.map((medication) => {
                const sideEffectData = sideEffects.find(se => se.medication === medication.name);
                const isLoading = sideEffectsLoading && selectedMedication === medication.id;

                return (
                  <div key={medication.id} className="border border-gray-200 rounded-lg">
                    <div className="p-3">
                      <h4 className="font-medium text-gray-900">{medication.name}</h4>
                      <p className="text-sm text-gray-500 mt-1">
                        {medication.dosage && `${medication.dosage} • `}
                        Click to view detailed side effects and warnings
                      </p>
                      <button
                        onClick={() => getSideEffects(medication)}
                        disabled={isLoading}
                        className="mt-2 text-xs text-blue-600 hover:text-blue-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                      >
                        {isLoading ? (
                          <>
                            <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-blue-600 mr-1"></div>
                            Loading...
                          </>
                        ) : (
                          'View Details →'
                        )}
                      </button>
                    </div>

                    {/* Side Effects Details */}
                    {sideEffectData && (
                      <div className="border-t border-gray-200 p-4 bg-gray-50">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {/* Common Side Effects */}
                          <div>
                            <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                              <div className="w-2 h-2 bg-yellow-400 rounded-full mr-2"></div>
                              Common Side Effects
                            </h5>
                            <ul className="text-sm text-gray-700 space-y-1">
                              {sideEffectData.commonSideEffects.map((effect, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-gray-400 mr-2">•</span>
                                  {effect}
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Serious Side Effects */}
                          <div>
                            <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                              <div className="w-2 h-2 bg-red-500 rounded-full mr-2"></div>
                              Serious Side Effects
                            </h5>
                            <ul className="text-sm text-gray-700 space-y-1">
                              {sideEffectData.seriousSideEffects.map((effect, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-red-400 mr-2">•</span>
                                  {effect}
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Warnings */}
                          <div>
                            <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                              <AlertTriangle className="w-4 h-4 text-orange-500 mr-2" />
                              Warnings
                            </h5>
                            <ul className="text-sm text-gray-700 space-y-1">
                              {sideEffectData.warnings.map((warning, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-orange-400 mr-2">•</span>
                                  {warning}
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* Storage & Dosage */}
                          <div>
                            <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                              <Shield className="w-4 h-4 text-blue-500 mr-2" />
                              Storage & Dosage
                            </h5>
                            <div className="text-sm text-gray-700 space-y-2">
                              <p><strong>Dosage:</strong> {sideEffectData.dosageInfo}</p>
                              <p><strong>Storage:</strong> {sideEffectData.storage}</p>
                            </div>
                          </div>
                        </div>

                        {/* Contraindications */}
                        {sideEffectData.contraindications.length > 0 && (
                          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                            <h5 className="font-medium text-red-900 mb-2 flex items-center">
                              <X className="w-4 h-4 text-red-500 mr-2" />
                              Contraindications
                            </h5>
                            <ul className="text-sm text-red-800 space-y-1">
                              {sideEffectData.contraindications.map((contra, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="text-red-400 mr-2">•</span>
                                  {contra}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}

              {medications.length === 0 && (
                <div className="text-center py-6">
                  <Shield className="mx-auto h-12 w-12 text-gray-400" />
                  <h4 className="mt-2 text-sm font-medium text-gray-900">No medications added</h4>
                  <p className="mt-1 text-sm text-gray-500">Add medications to view side effects</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Medical Disclaimer */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex">
          <AlertTriangle className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">Important Medical Disclaimer</h3>
            <p className="mt-1 text-sm text-red-700">
              This tool provides general information about potential drug interactions. It does not replace professional medical advice. 
              Always consult your healthcare provider or pharmacist before starting, stopping, or changing any medications.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}