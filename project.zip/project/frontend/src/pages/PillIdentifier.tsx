import React, { useState } from 'react';
import { Camera, Upload, Search, Pill, AlertTriangle, Info, CheckCircle } from 'lucide-react';
import { useNotification } from '../contexts/NotificationContext';
import Together from 'together-ai';

interface PillCharacteristics {
  shape: string;
  color: string;
  size: string;
  imprint: string;
  scoring: string;
}

interface IdentificationResult {
  name: string;
  genericName: string;
  strength: string;
  manufacturer: string;
  ndc: string;
  description: string;
  uses: string;
  warnings: string[];
  confidence: number;
}

export default function PillIdentifier() {
  const [characteristics, setCharacteristics] = useState<PillCharacteristics>({
    shape: '',
    color: '',
    size: '',
    imprint: '',
    scoring: ''
  });
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [results, setResults] = useState<IdentificationResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'characteristics' | 'image'>('characteristics');

  const { addNotification } = useNotification();

  const together = new Together({
    apiKey: import.meta.env.VITE_TOGETHER_API_KEY || '7323b782a40ca2bdbdf780016aeb8662befc0894c9f4e5385bfcdde33f5147a1'
  });

  const handleCharacteristicChange = (field: keyof PillCharacteristics, value: string) => {
    setCharacteristics(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        addNotification({
          type: 'error',
          title: 'File Too Large',
          message: 'Please select an image smaller than 5MB'
        });
        return;
      }

      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const identifyByCharacteristics = async () => {
    const filledFields = Object.values(characteristics).filter(value => value.trim()).length;

    if (filledFields < 2) {
      addNotification({
        type: 'error',
        title: 'Insufficient Information',
        message: 'Please fill in at least 2 characteristics to identify the pill'
      });
      return;
    }

    setLoading(true);

    try {
      const characteristicsText = Object.entries(characteristics)
        .filter(([_, value]) => value.trim())
        .map(([key, value]) => `${key}: ${value}`)
        .join(', ');

      const prompt = `Identify a pill with these characteristics: ${characteristicsText}

Please provide detailed information in JSON format with this structure:
[
  {
    "name": "brand name",
    "genericName": "generic name",
    "strength": "dosage strength",
    "manufacturer": "manufacturer name",
    "ndc": "NDC number if available",
    "description": "detailed physical description",
    "uses": "what this medication is used for",
    "warnings": ["warning1", "warning2"],
    "confidence": 85
  }
]

Provide up to 3 most likely matches. If no matches found, return empty array: []`;

      const response = await together.chat.completions.create({
        messages: [{ role: "user", content: prompt }],
        model: "mistralai/Mistral-7B-Instruct-v0.1",
        max_tokens: 2000,
        temperature: 0.1
      });

      const content = response.choices[0]?.message?.content;
      if (content) {
        try {
          const jsonStart = content.indexOf('[');
          const jsonEnd = content.lastIndexOf(']') + 1;
          const jsonStr = content.slice(jsonStart, jsonEnd);
          const parsedResults = JSON.parse(jsonStr);
          setResults(parsedResults);

          addNotification({
            type: 'success',
            title: 'Identification Complete',
            message: `Found ${parsedResults.length} potential matches`
          });
        } catch (parseError) {
          throw new Error('Failed to parse identification results');
        }
      }
    } catch (error: any) {
      console.error('Pill identification error:', error);
      addNotification({
        type: 'error',
        title: 'Identification Failed',
        message: error.message || 'Failed to identify pill'
      });
    } finally {
      setLoading(false);
    }
  };

  const identifyByImage = async () => {
    if (!selectedImage) {
      addNotification({
        type: 'error',
        title: 'No Image Selected',
        message: 'Please upload an image of the pill first'
      });
      return;
    }

    setLoading(true);

    try {
      // Convert image to base64
      const base64Image = await convertImageToBase64(selectedImage);

      // Use Together AI vision model to analyze the pill image
      const prompt = `Analyze this pill image and identify the medication. Look for:
1. Shape (round, oval, capsule, etc.)
2. Color(s)
3. Size (estimate)
4. Any text, numbers, or markings (imprint)
5. Scoring or lines

Based on these visual characteristics, provide detailed information in JSON format:
[
  {
    "name": "brand name",
    "genericName": "generic name",
    "strength": "dosage strength",
    "manufacturer": "manufacturer name",
    "ndc": "NDC number if identifiable",
    "description": "detailed physical description matching the image",
    "uses": "what this medication is used for",
    "warnings": ["warning1", "warning2"],
    "confidence": 75,
    "visualCharacteristics": {
      "shape": "observed shape",
      "color": "observed color(s)",
      "imprint": "any visible text/numbers",
      "size": "estimated size"
    }
  }
]

If you cannot identify the pill with reasonable confidence, return an empty array: []

Important: Only identify if you can see clear distinguishing features. If the image is unclear or you're uncertain, return empty array.`;

      const response = await together.chat.completions.create({
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: prompt
              },
              {
                type: "image_url",
                image_url: {
                  url: base64Image
                }
              }
            ]
          }
        ],
        model: "meta-llama/Llama-Vision-Free",
        max_tokens: 2000,
        temperature: 0.1
      });

      const content = response.choices[0]?.message?.content;
      if (content) {
        try {
          const jsonStart = content.indexOf('[');
          const jsonEnd = content.lastIndexOf(']') + 1;

          if (jsonStart === -1 || jsonEnd === 0) {
            throw new Error('No valid JSON found in response');
          }

          const jsonStr = content.slice(jsonStart, jsonEnd);
          const parsedResults = JSON.parse(jsonStr);

          if (Array.isArray(parsedResults) && parsedResults.length > 0) {
            setResults(parsedResults);
            addNotification({
              type: 'success',
              title: 'Image Analysis Complete',
              message: `Found ${parsedResults.length} potential matches from image analysis`
            });
          } else {
            setResults([]);
            addNotification({
              type: 'info',
              title: 'No Matches Found',
              message: 'Could not identify the pill from the image. Try using the characteristics method or upload a clearer image.'
            });
          }
        } catch (parseError) {
          console.error('JSON parsing error:', parseError);
          addNotification({
            type: 'error',
            title: 'Analysis Error',
            message: 'Failed to parse identification results. Please try again or use the characteristics method.'
          });
        }
      } else {
        throw new Error('No response from vision model');
      }
    } catch (error: any) {
      console.error('Image identification error:', error);
      addNotification({
        type: 'error',
        title: 'Analysis Failed',
        message: error.message || 'Failed to analyze image. Please try again or use the characteristics method.'
      });
    } finally {
      setLoading(false);
    }
  };

  // Helper function to convert image to base64
  const convertImageToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          resolve(reader.result);
        } else {
          reject(new Error('Failed to convert image to base64'));
        }
      };
      reader.onerror = () => reject(new Error('Failed to read image file'));
      reader.readAsDataURL(file);
    });
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-green-700 bg-green-50 border-green-200';
    if (confidence >= 60) return 'text-yellow-700 bg-yellow-50 border-yellow-200';
    return 'text-red-700 bg-red-50 border-red-200';
  };

  const getConfidenceIcon = (confidence: number) => {
    if (confidence >= 80) return <CheckCircle className="h-5 w-5 text-green-500" />;
    if (confidence >= 60) return <Info className="h-5 w-5 text-yellow-500" />;
    return <AlertTriangle className="h-5 w-5 text-red-500" />;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Pill Identifier</h1>
        <div className="text-sm text-gray-500">
          Identify medications by characteristics or image
        </div>
      </div>

      {/* Method Selection Tabs */}
      <div className="bg-white shadow rounded-lg">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex">
            <button
              onClick={() => setActiveTab('characteristics')}
              className={`py-4 px-6 text-sm font-medium border-b-2 ${
                activeTab === 'characteristics'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Search className="h-4 w-4 inline mr-2" />
              By Characteristics
            </button>
            <button
              onClick={() => setActiveTab('image')}
              className={`py-4 px-6 text-sm font-medium border-b-2 ${
                activeTab === 'image'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Camera className="h-4 w-4 inline mr-2" />
              By Image
            </button>
          </nav>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          {activeTab === 'characteristics' ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="shape" className="block text-sm font-medium text-gray-700">
                    Shape
                  </label>
                  <select
                    id="shape"
                    value={characteristics.shape}
                    onChange={(e) => handleCharacteristicChange('shape', e.target.value)}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select shape</option>
                    <option value="round">Round</option>
                    <option value="oval">Oval</option>
                    <option value="capsule">Capsule</option>
                    <option value="square">Square</option>
                    <option value="diamond">Diamond</option>
                    <option value="triangle">Triangle</option>
                    <option value="rectangular">Rectangular</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="color" className="block text-sm font-medium text-gray-700">
                    Color
                  </label>
                  <select
                    id="color"
                    value={characteristics.color}
                    onChange={(e) => handleCharacteristicChange('color', e.target.value)}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select color</option>
                    <option value="white">White</option>
                    <option value="yellow">Yellow</option>
                    <option value="pink">Pink</option>
                    <option value="blue">Blue</option>
                    <option value="green">Green</option>
                    <option value="red">Red</option>
                    <option value="orange">Orange</option>
                    <option value="purple">Purple</option>
                    <option value="brown">Brown</option>
                    <option value="gray">Gray</option>
                    <option value="black">Black</option>
                    <option value="multicolor">Multi-color</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="size" className="block text-sm font-medium text-gray-700">
                    Size (approximate)
                  </label>
                  <select
                    id="size"
                    value={characteristics.size}
                    onChange={(e) => handleCharacteristicChange('size', e.target.value)}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select size</option>
                    <option value="very small">Very Small (≤ 6mm)</option>
                    <option value="small">Small (6-10mm)</option>
                    <option value="medium">Medium (10-15mm)</option>
                    <option value="large">Large (15-20mm)</option>
                    <option value="very large">Very Large (≥ 20mm)</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="scoring" className="block text-sm font-medium text-gray-700">
                    Scoring/Lines
                  </label>
                  <select
                    id="scoring"
                    value={characteristics.scoring}
                    onChange={(e) => handleCharacteristicChange('scoring', e.target.value)}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select scoring</option>
                    <option value="none">No scoring</option>
                    <option value="single">Single line</option>
                    <option value="cross">Cross/Plus shape</option>
                    <option value="multiple">Multiple lines</option>
                    <option value="partial">Partial scoring</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="imprint" className="block text-sm font-medium text-gray-700">
                  Imprint/Text (letters, numbers, symbols)
                </label>
                <input
                  type="text"
                  id="imprint"
                  value={characteristics.imprint}
                  onChange={(e) => handleCharacteristicChange('imprint', e.target.value)}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., 'M 30', 'PFIZER', '325'"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Enter any text, numbers, or symbols visible on the pill
                </p>
              </div>

              <button
                onClick={identifyByCharacteristics}
                disabled={loading}
                className="w-full flex justify-center items-center px-4 py-3 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Identifying Pill...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Identify Pill
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                <div className="text-center">
                  {imagePreview ? (
                    <div className="space-y-4">
                      <img
                        src={imagePreview}
                        alt="Pill preview"
                        className="mx-auto h-48 w-48 object-cover rounded-lg border border-gray-200"
                      />
                      <div>
                        <p className="text-sm text-gray-600">
                          {selectedImage?.name} ({Math.round((selectedImage?.size || 0) / 1024)} KB)
                        </p>
                        <button
                          onClick={() => {
                            setSelectedImage(null);
                            setImagePreview(null);
                          }}
                          className="mt-2 text-sm text-red-600 hover:text-red-800"
                        >
                          Remove image
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="mt-4">
                        <label htmlFor="pill-image" className="cursor-pointer">
                          <span className="mt-2 block text-sm font-medium text-gray-900">
                            Upload a clear photo of your pill
                          </span>
                          <span className="mt-1 block text-xs text-gray-500">
                            PNG, JPG up to 5MB
                          </span>
                        </label>
                        <input
                          id="pill-image"
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex">
                  <Info className="h-5 w-5 text-blue-400" />
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-blue-800">Photo Tips for Best Results</h3>
                    <ul className="mt-1 text-sm text-blue-700 list-disc list-inside space-y-1">
                      <li>Take photo in bright, natural lighting</li>
                      <li>Place pill on a plain, contrasting background</li>
                      <li>Ensure any text, numbers, or markings are clearly visible</li>
                      <li>Take photo from directly above the pill</li>
                      <li>If pill has different sides, take separate photos</li>
                      <li>Avoid shadows and reflections</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex">
                  <Info className="h-5 w-5 text-green-400" />
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-green-800">AI Vision Analysis</h3>
                    <p className="mt-1 text-sm text-green-700">
                      Our AI can analyze pill images to identify shape, color, size, and any visible markings or text.
                      For best results, ensure the image is clear and well-lit.
                    </p>
                  </div>
                </div>
              </div>

              <button
                onClick={identifyByImage}
                disabled={loading || !selectedImage}
                className="w-full flex justify-center items-center px-4 py-3 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Analyzing Image with AI...
                  </>
                ) : (
                  <>
                    <Camera className="h-4 w-4 mr-2" />
                    Identify Pill from Image
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Results Section */}
      {results.length > 0 && (
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Identification Results ({results.length})
          </h3>

          <div className="space-y-4">
            {results.map((result, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center">
                      <h4 className="text-lg font-medium text-gray-900">{result.name}</h4>
                      <div className={`ml-3 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getConfidenceColor(result.confidence)}`}>
                        {getConfidenceIcon(result.confidence)}
                        <span className="ml-1">{result.confidence}% match</span>
                      </div>
                    </div>

                    <p className="text-sm text-gray-600 mt-1">
                      <span className="font-medium">Generic:</span> {result.genericName}
                    </p>

                    {result.strength && (
                      <p className="text-sm text-gray-600">
                        <span className="font-medium">Strength:</span> {result.strength}
                      </p>
                    )}

                    {result.manufacturer && (
                      <p className="text-sm text-gray-600">
                        <span className="font-medium">Manufacturer:</span> {result.manufacturer}
                      </p>
                    )}

                    {result.ndc && (
                      <p className="text-sm text-gray-600">
                        <span className="font-medium">NDC:</span> {result.ndc}
                      </p>
                    )}
                  </div>
                </div>

                <div className="mt-4 space-y-3">
                  <div>
                    <h5 className="text-sm font-medium text-gray-900">Description</h5>
                    <p className="text-sm text-gray-600 mt-1">{result.description}</p>
                  </div>

                  <div>
                    <h5 className="text-sm font-medium text-gray-900">Uses</h5>
                    <p className="text-sm text-gray-600 mt-1">{result.uses}</p>
                  </div>

                  {result.warnings && result.warnings.length > 0 && (
                    <div>
                      <h5 className="text-sm font-medium text-gray-900 flex items-center">
                        <AlertTriangle className="h-4 w-4 text-yellow-500 mr-1" />
                        Important Warnings
                      </h5>
                      <ul className="text-sm text-gray-600 mt-1 list-disc list-inside space-y-1">
                        {result.warnings.map((warning, warningIndex) => (
                          <li key={warningIndex}>{warning}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Reference Guide */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Quick Reference Guide</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-2">Common Pill Shapes</h4>
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-blue-500 rounded-full mr-2"></div>
                <span>Round - Most common for tablets</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-3 bg-green-500 rounded-full mr-2"></div>
                <span>Oval - Extended release tablets</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-3 bg-red-500 rounded-full mr-2"></div>
                <span>Capsule - Liquid or powder inside</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-2">Reading Imprints</h4>
            <div className="space-y-1 text-sm text-gray-600">
              <p>• Look for letters, numbers, or symbols</p>
              <p>• Check both sides of the pill</p>
              <p>• Note any scoring or break lines</p>
              <p>• Some pills have no imprint (rare)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Medical Disclaimer */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex">
          <AlertTriangle className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">Important Medical Disclaimer</h3>
            <p className="mt-1 text-sm text-red-700">
              This pill identifier is for informational purposes only and should not replace professional medical advice.
              If you have found an unknown pill, do not take it. Contact your healthcare provider, pharmacist, or poison control center.
              Always verify medication identity with a healthcare professional before taking any medication.
            </p>
            <div className="mt-2">
              <p className="text-xs text-red-600 font-medium">
                Emergency: Call 911 | Poison Control: 1-800-222-1222
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}