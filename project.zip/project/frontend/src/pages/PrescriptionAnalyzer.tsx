import React, { useState } from 'react';
import { Upload, FileText, Loader, CheckCircle, AlertTriangle } from 'lucide-react';
import { useNotification } from '../contexts/NotificationContext';
import Together from 'together-ai';

interface AnalysisResult {
  medication: string;
  dosage: string;
  frequency: string;
  instructions: string;
  sideEffects: string[];
  warnings: string[];
  foodInteractions: string;
  storage: string;
  simplified: string;
}

export default function PrescriptionAnalyzer() {
  const [file, setFile] = useState<File | null>(null);
  const [textInput, setTextInput] = useState('');
  const [analysis, setAnalysis] = useState<AnalysisResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  
  const { addNotification } = useNotification();

  const together = new Together({
    apiKey: import.meta.env.VITE_TOGETHER_API_KEY || '7323b782a40ca2bdbdf780016aeb8662befc0894c9f4e5385bfcdde33f5147a1'
  });

  const handleFileUpload = (uploadedFile: File) => {
    if (uploadedFile.type.startsWith('image/') || uploadedFile.type === 'application/pdf') {
      setFile(uploadedFile);
      addNotification({
        type: 'success',
        title: 'File Uploaded',
        message: 'Ready to analyze prescription'
      });
    } else {
      addNotification({
        type: 'error',
        title: 'Invalid File',
        message: 'Please upload an image or PDF file'
      });
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleFileUpload(droppedFile);
    }
  };

  const analyzePrescription = async () => {
    if (!file && !textInput.trim()) {
      addNotification({
        type: 'error',
        title: 'No Input',
        message: 'Please upload a file or enter prescription text'
      });
      return;
    }

    setLoading(true);
    
    try {
      let prescriptionText = textInput;
      
      if (file) {
        // In a real implementation, you would use OCR to extract text from images
        prescriptionText = "Metformin 500mg - Take twice daily with meals for Type 2 Diabetes";
      }

      const prompt = `Analyze this prescription and provide detailed information in JSON format:

Prescription: ${prescriptionText}

Please provide analysis in this exact JSON structure:
{
  "medication": "medication name",
  "dosage": "dosage information",
  "frequency": "how often to take",
  "instructions": "detailed instructions",
  "sideEffects": ["list", "of", "side", "effects"],
  "warnings": ["list", "of", "warnings"],
  "foodInteractions": "food interaction information",
  "storage": "storage instructions",
  "simplified": "simple explanation for patients"
}`;

      const response = await together.chat.completions.create({
        messages: [{ role: "user", content: prompt }],
        model: "mistralai/Mistral-7B-Instruct-v0.1",
        max_tokens: 1000,
        temperature: 0.1
      });

      const content = response.choices[0]?.message?.content;
      if (content) {
        try {
          // Parse multiple JSON objects from the response
          const parsedAnalyses: AnalysisResult[] = [];

          // Split content by looking for JSON object boundaries
          const jsonObjects = content.split(/(?<=})\s*(?={)/);

          for (const jsonStr of jsonObjects) {
            const trimmed = jsonStr.trim();
            if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
              try {
                const parsed = JSON.parse(trimmed);
                parsedAnalyses.push(parsed);
              } catch (e) {
                console.warn('Failed to parse individual JSON object:', trimmed);
              }
            }
          }

          // If no objects were parsed using the split method, try extracting all JSON objects manually
          if (parsedAnalyses.length === 0) {
            let startIndex = 0;
            while (startIndex < content.length) {
              const jsonStart = content.indexOf('{', startIndex);
              if (jsonStart === -1) break;

              let braceCount = 0;
              let jsonEnd = jsonStart;

              for (let i = jsonStart; i < content.length; i++) {
                if (content[i] === '{') braceCount++;
                if (content[i] === '}') braceCount--;
                if (braceCount === 0) {
                  jsonEnd = i;
                  break;
                }
              }

              if (braceCount === 0) {
                const jsonStr = content.slice(jsonStart, jsonEnd + 1);
                try {
                  const parsed = JSON.parse(jsonStr);
                  parsedAnalyses.push(parsed);
                } catch (e) {
                  console.warn('Failed to parse JSON object:', jsonStr);
                }
              }

              startIndex = jsonEnd + 1;
            }
          }

          if (parsedAnalyses.length > 0) {
            setAnalysis(parsedAnalyses);
            addNotification({
              type: 'success',
              title: 'Analysis Complete',
              message: `Found ${parsedAnalyses.length} medication(s) in prescription`
            });
          } else {
            throw new Error('No valid medication data found in response');
          }
        } catch (parseError) {
          console.error('Parse error:', parseError);
          throw new Error('Failed to parse AI response');
        }
      }
    } catch (error: any) {
      console.error('Analysis error:', error);
      addNotification({
        type: 'error',
        title: 'Analysis Failed',
        message: error.message || 'Failed to analyze prescription'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Prescription Analyzer</h1>
        <div className="text-sm text-gray-500">
          AI-powered prescription analysis
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="space-y-6">
          {/* File Upload */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Upload Prescription</h3>
            <div
              className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                dragOver ? 'border-blue-400 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
              }`}
              onDrop={handleDrop}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
            >
              <Upload className="mx-auto h-12 w-12 text-gray-400" />
              <div className="mt-4">
                <label htmlFor="file-upload" className="cursor-pointer">
                  <span className="mt-2 block text-sm font-medium text-gray-900">
                    Drop prescription image here or click to upload
                  </span>
                  <input
                    id="file-upload"
                    name="file-upload"
                    type="file"
                    className="sr-only"
                    accept="image/*,.pdf"
                    onChange={(e) => {
                      const uploadedFile = e.target.files?.[0];
                      if (uploadedFile) handleFileUpload(uploadedFile);
                    }}
                  />
                </label>
                <p className="mt-1 text-xs text-gray-500">
                  PNG, JPG, PDF up to 10MB
                </p>
              </div>
            </div>
            
            {file && (
              <div className="mt-4 flex items-center p-3 bg-green-50 border border-green-200 rounded-lg">
                <FileText className="h-5 w-5 text-green-500" />
                <span className="ml-2 text-sm text-green-700">{file.name}</span>
              </div>
            )}
          </div>

          {/* Text Input */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Or Enter Prescription Text</h3>
            <textarea
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              rows={6}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter prescription details here..."
            />
          </div>

          <button
            onClick={analyzePrescription}
            disabled={loading || (!file && !textInput.trim())}
            className="w-full flex justify-center items-center px-4 py-3 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <Loader className="animate-spin -ml-1 mr-3 h-5 w-5" />
                Analyzing...
              </>
            ) : (
              'Analyze Prescription'
            )}
          </button>
        </div>

        {/* Results Section */}
        <div className="space-y-6">
          {analysis.length > 0 ? (
            <div className="space-y-6">
              <div className="bg-white shadow rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <CheckCircle className="h-6 w-6 text-green-500" />
                  <h3 className="ml-2 text-lg font-medium text-gray-900">
                    Analysis Results ({analysis.length} medication{analysis.length > 1 ? 's' : ''} found)
                  </h3>
                </div>
              </div>

              {analysis.map((medication, index) => (
                <div key={index} className="bg-white shadow rounded-lg p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <h3 className="ml-3 text-lg font-medium text-gray-900">{medication.medication}</h3>
                  </div>

                  <div className="space-y-6">
                    {/* Simplified Explanation */}
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="font-medium text-blue-900 mb-2">Simple Explanation</h4>
                      <p className="text-blue-800">{medication.simplified}</p>
                    </div>

                    {/* Medication Details */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Dosage</h4>
                        <p className="text-gray-700">{medication.dosage}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Frequency</h4>
                        <p className="text-gray-700">{medication.frequency}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Storage</h4>
                        <p className="text-gray-700">{medication.storage}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Food Interactions</h4>
                        <p className="text-gray-700">{medication.foodInteractions}</p>
                      </div>
                    </div>

                    {/* Instructions */}
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Instructions</h4>
                      <p className="text-gray-700">{medication.instructions}</p>
                    </div>

                    {/* Side Effects */}
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Possible Side Effects</h4>
                      <ul className="list-disc list-inside text-gray-700 space-y-1">
                        {medication.sideEffects.map((effect, effectIndex) => (
                          <li key={effectIndex}>{effect}</li>
                        ))}
                      </ul>
                    </div>

                    {/* Warnings */}
                    {medication.warnings.length > 0 && (
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <div className="flex items-center mb-2">
                          <AlertTriangle className="h-5 w-5 text-yellow-500" />
                          <h4 className="ml-2 font-medium text-yellow-900">Important Warnings</h4>
                        </div>
                        <ul className="list-disc list-inside text-yellow-800 space-y-1">
                          {medication.warnings.map((warning, warningIndex) => (
                            <li key={warningIndex}>{warning}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white shadow rounded-lg p-6 text-center">
              <FileText className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No Analysis Yet</h3>
              <p className="mt-1 text-sm text-gray-500">
                Upload a prescription or enter text to get started
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Medical Disclaimer */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex">
          <AlertTriangle className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">Medical Disclaimer</h3>
            <p className="mt-1 text-sm text-red-700">
              This analysis is for informational purposes only and should not replace professional medical advice. 
              Always consult with your healthcare provider or pharmacist before making any changes to your medication regimen.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}