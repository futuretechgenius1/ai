import React, { useState, useEffect } from 'react';
import { Plus, Clock, Bell, Trash2, Edit, AlertCircle, MessageSquare, Phone } from 'lucide-react';
import { useNotification } from '../contexts/NotificationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { remindersAPI, medicationsAPI } from '../services/api';

interface Reminder {
  id: string;
  prescription_id: string;
  medication_name: string;
  dosage: string;
  reminder_type: string;
  scheduled_time: string;
  message: string;
  is_sent: boolean;
  // Legacy fields for backward compatibility
  medication_id?: string;
  reminder_time?: string;
  days_of_week?: string;
  active?: boolean;
  sms_enabled?: boolean;
  last_sent?: string;
}

interface Medication {
  id: string;
  medication_name: string;
  dosage: string;
  frequency: string;
  // Legacy field for backward compatibility
  name?: string;
}

export default function Reminders() {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingReminder, setEditingReminder] = useState<Reminder | null>(null);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    prescriptionId: '',
    scheduledTime: '',
    reminderType: 'dose',
    message: ''
  });

  const { addNotification } = useNotification();
  const { t } = useLanguage();

  useEffect(() => {
    loadReminders();
    loadMedications();
  }, []);

  const loadReminders = async () => {
    try {
      setLoading(true);
      const data = await remindersAPI.getAll();
      setReminders(data);
    } catch (error) {
      console.error('Error loading reminders:', error);
      addNotification({
        type: 'error',
        title: t('error.loadReminders', 'Error'),
        message: t('error.loadRemindersMessage', 'Failed to load reminders')
      });
    } finally {
      setLoading(false);
    }
  };

  const loadMedications = async () => {
    try {
      const data = await medicationsAPI.getAll();
      setMedications(data);
    } catch (error) {
      console.error('Error loading medications:', error);
      addNotification({
        type: 'error',
        title: t('error.loadMedications', 'Error'),
        message: t('error.loadMedicationsMessage', 'Failed to load medications')
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.prescriptionId || !formData.scheduledTime) {
      addNotification({
        type: 'error',
        title: t('error.validation', 'Validation Error'),
        message: t('error.fillRequired', 'Please fill in all required fields')
      });
      return;
    }

    try {
      setLoading(true);

      // Create a proper datetime string
      const scheduledDateTime = new Date(formData.scheduledTime).toISOString();

      if (editingReminder) {
        await remindersAPI.update(editingReminder.id, {
          scheduledTime: scheduledDateTime,
          message: formData.message,
          reminderType: formData.reminderType
        });

        addNotification({
          type: 'success',
          title: t('success.updated', 'Updated'),
          message: t('success.reminderUpdated', 'Reminder updated successfully')
        });
      } else {
        await remindersAPI.create({
          prescriptionId: formData.prescriptionId,
          scheduledTime: scheduledDateTime,
          reminderType: formData.reminderType,
          message: formData.message || `Time to take your medication`
        });

        addNotification({
          type: 'success',
          title: t('success.created', 'Created'),
          message: t('success.reminderCreated', 'Reminder created successfully')
        });
      }

      await loadReminders();
      resetForm();
    } catch (error) {
      console.error('Error saving reminder:', error);
      addNotification({
        type: 'error',
        title: t('error.save', 'Error'),
        message: t('error.saveReminder', 'Failed to save reminder')
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      prescriptionId: '',
      scheduledTime: '',
      reminderType: 'dose',
      message: ''
    });
    setShowForm(false);
    setEditingReminder(null);
  };

  const handleEdit = (reminder: Reminder) => {
    setEditingReminder(reminder);
    setFormData({
      medicationId: reminder.medication_id,
      reminderTime: reminder.reminder_time,
      daysOfWeek: reminder.days_of_week,
      smsEnabled: reminder.sms_enabled
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm(t('confirm.deleteReminder', 'Are you sure you want to delete this reminder?'))) {
      return;
    }

    try {
      setLoading(true);
      await remindersAPI.delete(id);

      addNotification({
        type: 'success',
        title: t('success.deleted', 'Deleted'),
        message: t('success.reminderDeleted', 'Reminder deleted successfully')
      });

      await loadReminders();
    } catch (error) {
      console.error('Error deleting reminder:', error);
      addNotification({
        type: 'error',
        title: t('error.delete', 'Error'),
        message: t('error.deleteReminder', 'Failed to delete reminder')
      });
    } finally {
      setLoading(false);
    }
  };

  const getDayNames = (daysString: string | undefined): string => {
    if (!daysString) {
      return t('reminders.noSchedule', 'No schedule set');
    }

    const days = daysString.split(',').map(Number);
    const dayNames = [
      t('days.sunday', 'Sun'),
      t('days.monday', 'Mon'),
      t('days.tuesday', 'Tue'),
      t('days.wednesday', 'Wed'),
      t('days.thursday', 'Thu'),
      t('days.friday', 'Fri'),
      t('days.saturday', 'Sat')
    ];

    if (days.length === 7) {
      return t('frequency.daily', 'Daily');
    }

    return days.map(day => dayNames[day === 7 ? 0 : day]).filter(Boolean).join(', ');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">{t('reminders.title', 'Medication Reminders')}</h1>
        <button
          onClick={() => setShowForm(true)}
          disabled={loading}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          <Plus className="h-4 w-4 mr-2" />
          {t('reminders.add', 'Add Reminder')}
        </button>
      </div>

      {/* Add/Edit Form */}
      {showForm && (
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            {editingReminder ? t('reminders.edit', 'Edit Reminder') : t('reminders.addNew', 'Add New Reminder')}
          </h3>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('medication.name', 'Medication')} *
                </label>
                <select
                  value={formData.prescriptionId}
                  onChange={(e) => setFormData({...formData, prescriptionId: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">{t('reminders.selectMedication', 'Select a medication')}</option>
                  {medications.map((medication) => (
                    <option key={medication.id} value={medication.id}>
                      {medication.medication_name || medication.name} - {medication.dosage}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('reminder.scheduledTime', 'Scheduled Time')} *
                </label>
                <input
                  type="datetime-local"
                  value={formData.scheduledTime}
                  onChange={(e) => setFormData({...formData, scheduledTime: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('reminder.type', 'Reminder Type')}
              </label>
              <select
                value={formData.reminderType}
                onChange={(e) => setFormData({...formData, reminderType: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="dose">{t('reminder.dose', 'Dose Reminder')}</option>
                <option value="refill">{t('reminder.refill', 'Refill Reminder')}</option>
                <option value="appointment">{t('reminder.appointment', 'Appointment Reminder')}</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {t('reminder.message', 'Reminder Message')}
              </label>
              <textarea
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                placeholder={t('reminder.messagePlaceholder', 'Enter a custom reminder message (optional)')}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
              />
            </div>

            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              >
                {t('common.cancel', 'Cancel')}
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {loading ? t('common.saving', 'Saving...') : (editingReminder ? t('common.update', 'Update') : t('common.create', 'Create'))}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Reminders List */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            {t('reminders.active', 'Active Reminders')} ({reminders.filter(r => r.active).length})
          </h3>
        </div>

        {loading ? (
          <div className="p-6 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-2 text-gray-500">{t('common.loading', 'Loading...')}</p>
          </div>
        ) : reminders.length === 0 ? (
          <div className="p-6 text-center">
            <Clock className="mx-auto h-12 w-12 text-gray-400" />
            <h4 className="mt-2 text-sm font-medium text-gray-900">
              {t('reminders.noReminders', 'No reminders set')}
            </h4>
            <p className="mt-1 text-sm text-gray-500">
              {t('reminders.addFirst', 'Add your first medication reminder to get started')}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {reminders.map((reminder) => (
              <div key={reminder.id} className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center">
                      <h4 className="text-lg font-medium text-gray-900">
                        {reminder.medication_name}
                      </h4>
                      <span className="ml-2 text-sm text-gray-500">
                        {reminder.dosage}
                      </span>
                      {reminder.sms_enabled && (
                        <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          <Phone className="h-3 w-3 mr-1" />
                          SMS
                        </span>
                      )}
                    </div>

                    <div className="mt-2 flex items-center text-sm text-gray-600">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>
                        {reminder.scheduled_time
                          ? new Date(reminder.scheduled_time).toLocaleString()
                          : reminder.reminder_time || 'No time set'
                        }
                      </span>
                      {reminder.days_of_week && (
                        <>
                          <span className="mx-2">•</span>
                          <span>{getDayNames(reminder.days_of_week)}</span>
                        </>
                      )}
                    </div>

                    {reminder.is_sent && (
                      <div className="mt-1 text-xs text-gray-500">
                        {t('reminders.sent', 'Sent')}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEdit(reminder)}
                      className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title={t('common.edit', 'Edit')}
                    >
                      <Edit className="h-4 w-4" />
                    </button>

                    <button
                      onClick={() => handleDelete(reminder.id)}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title={t('common.delete', 'Delete')}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SMS Setup Instructions */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex">
          <MessageSquare className="h-5 w-5 text-blue-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">
              {t('reminders.smsSetup', 'SMS Reminder Setup')}
            </h3>
            <p className="mt-1 text-sm text-blue-700">
              {t('reminders.smsInstructions', 'To receive SMS reminders, make sure your phone number is added to your profile and SMS notifications are enabled for each reminder.')}
            </p>
          </div>
        </div>
      </div>

      {/* Medical Disclaimer */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex">
          <AlertCircle className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">
              {t('disclaimer.title', 'Important Medical Disclaimer')}
            </h3>
            <p className="mt-1 text-sm text-red-700">
              {t('disclaimer.reminders', 'These reminders are for convenience only and should not replace proper medical supervision. Always follow your healthcare provider\'s instructions and consult them for any medication concerns.')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}