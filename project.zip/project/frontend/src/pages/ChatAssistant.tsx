import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Bot, User, Loader, Volume2 } from 'lucide-react';
import { useNotification } from '../contexts/NotificationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useVoiceInput } from '../hooks/useVoiceInput';
import Together from 'together-ai';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function ChatAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Hello! I\'m your AI Virtual Pharmacist Assistant. I can help you with medication questions, drug interactions, side effects, and general health inquiries. How can I assist you today?',
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { addNotification } = useNotification();
  const { t, translate } = useLanguage();

  const together = new Together({
    apiKey: import.meta.env.VITE_TOGETHER_API_KEY || '7323b782a40ca2bdbdf780016aeb8662befc0894c9f4e5385bfcdde33f5147a1'
  });

  // Voice input hook
  const {
    isListening,
    isSupported: isVoiceSupported,
    transcript,
    interimTranscript,
    error: voiceError,
    startListening,
    stopListening,
    resetTranscript,
  } = useVoiceInput({
    continuous: false,
    interimResults: true,
    onResult: (transcript, isFinal) => {
      if (isFinal) {
        setInputText(prev => prev + transcript);
        resetTranscript();
      }
    },
    onError: (error) => {
      addNotification({
        type: 'error',
        title: 'Voice Input Error',
        message: error
      });
    }
  });

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Text-to-speech functionality
  const speakText = async (text: string) => {
    if ('speechSynthesis' in window) {
      // Stop any ongoing speech
      window.speechSynthesis.cancel();

      setIsSpeaking(true);

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.8;
      utterance.pitch = 1;
      utterance.volume = 1;

      // Set language based on current language
      const voiceLangMap: Record<string, string> = {
        'en': 'en-US',
        'es': 'es-ES',
        'hi': 'hi-IN',
        'te': 'te-IN'
      };

      utterance.lang = voiceLangMap[t('currentLanguage') || 'en'] || 'en-US';

      utterance.onend = () => {
        setIsSpeaking(false);
      };

      utterance.onerror = () => {
        setIsSpeaking(false);
        addNotification({
          type: 'error',
          title: 'Speech Error',
          message: 'Failed to speak the message'
        });
      };

      window.speechSynthesis.speak(utterance);
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const sendMessage = async () => {
    if (!inputText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      const systemPrompt = `You are an AI Virtual Pharmacist Assistant. You provide helpful, accurate information about medications, drug interactions, side effects, and general health questions. Always include appropriate medical disclaimers and encourage users to consult healthcare professionals for personalized medical advice.

Key guidelines:
- Be helpful and informative
- Use simple, easy-to-understand language
- Always include safety warnings when appropriate
- Recommend consulting healthcare professionals for serious concerns
- Never provide specific dosing instructions
- Be empathetic and supportive

Current conversation context: The user is asking about medications and health-related topics.`;

      const response = await together.chat.completions.create({
        messages: [
          { role: "system", content: systemPrompt },
          ...messages.slice(-5).map(msg => ({
            role: msg.type === 'user' ? 'user' as const : 'assistant' as const,
            content: msg.content
          })),
          { role: "user", content: inputText }
        ],
        model: "mistralai/Mistral-7B-Instruct-v0.1",
        max_tokens: 800,
        temperature: 0.7
      });

      const assistantResponse = response.choices[0]?.message?.content;

      if (assistantResponse) {
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: 'assistant',
          content: assistantResponse,
          timestamp: new Date()
        };

        setMessages(prev => [...prev, assistantMessage]);
      }
    } catch (error: any) {
      console.error('Chat error:', error);
      addNotification({
        type: 'error',
        title: 'Chat Error',
        message: 'Failed to send message. Please try again.'
      });

      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'I apologize, but I\'m having trouble connecting right now. Please try again in a moment.',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };



  const quickQuestions = [
    "What are the side effects of aspirin?",
    "Can I take ibuprofen with blood pressure medication?"
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-6rem)]">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-900">AI Pharmacist Assistant</h1>
        <div className="text-sm text-gray-500">
          Ask me anything about medications
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 bg-white shadow rounded-lg mb-4 overflow-hidden flex flex-col min-h-0">
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex w-full max-w-none ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`flex-shrink-0 ${message.type === 'user' ? 'ml-4' : 'mr-4'}`}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    message.type === 'user' ? 'bg-blue-500' : 'bg-green-500'
                  }`}>
                    {message.type === 'user' ? (
                      <User className="w-5 h-5 text-white" />
                    ) : (
                      <Bot className="w-5 h-5 text-white" />
                    )}
                  </div>
                </div>
                <div className={`flex flex-col flex-1 ${message.type === 'user' ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`px-6 py-4 rounded-lg max-w-none w-full ${
                      message.type === 'user'
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <div className={`text-base leading-relaxed whitespace-pre-wrap ${
                      message.type === 'assistant' ? 'prose prose-sm max-w-none' : ''
                    }`}>
                      {message.content}
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 mt-2">
                    <span className="text-xs text-gray-500">
                      {message.timestamp.toLocaleTimeString()}
                    </span>
                    {message.type === 'assistant' && 'speechSynthesis' in window && (
                      <button
                        onClick={() => isSpeaking ? stopSpeaking() : speakText(message.content)}
                        className="text-xs text-blue-600 hover:text-blue-800 flex items-center space-x-1 px-2 py-1 rounded hover:bg-blue-50"
                        title={isSpeaking ? t('voice.stopSpeaking', 'Stop speaking') : t('voice.speak', 'Read aloud')}
                      >
                        <Volume2 className="w-3 h-3" />
                        <span>{isSpeaking ? t('voice.stop', 'Stop') : t('voice.speak', 'Speak')}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex justify-start">
              <div className="flex w-full">
                <div className="mr-4">
                  <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                </div>
                <div className="bg-gray-100 px-6 py-4 rounded-lg flex-1">
                  <div className="flex items-center space-x-2">
                    <Loader className="w-5 h-5 animate-spin text-gray-500" />
                    <span className="text-base text-gray-500">Thinking...</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Questions */}
        {messages.length === 1 && (
          <div className="border-t border-gray-200 p-3">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Popular Questions:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {quickQuestions.map((question, index) => (
                <button
                  key={index}
                  onClick={() => setInputText(question)}
                  className="text-left text-xs text-blue-600 hover:text-blue-800 hover:bg-blue-50 p-2 rounded-md transition-colors border border-blue-200 hover:border-blue-300"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="bg-white shadow rounded-lg p-4">
        <div className="flex items-center space-x-3">
          <div className="flex-1">
            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me about medications, side effects, interactions..."
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={isLoading}
            />
          </div>
          
          {isVoiceSupported && (
            <button
              onClick={isListening ? stopListening : startListening}
              disabled={isLoading}
              className={`p-2 rounded-lg transition-colors ${
                isListening
                  ? 'bg-red-500 text-white animate-pulse'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
              title={isListening ? t('voice.stopListening', 'Stop listening') : t('voice.startListening', 'Start voice input')}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          )}

          <button
            onClick={sendMessage}
            disabled={!inputText.trim() || isLoading}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center space-x-2"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </div>
        
        {/* Voice feedback */}
        {isListening && (
          <div className="mt-2 flex items-center space-x-2 text-sm text-blue-600">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            <span>{t('voice.listening', 'Listening...')}</span>
            {interimTranscript && (
              <span className="text-gray-500 italic">"{interimTranscript}"</span>
            )}
          </div>
        )}

        {voiceError && (
          <div className="mt-2 text-sm text-red-600">
            {voiceError}
          </div>
        )}

        <div className="mt-2 text-xs text-gray-500">
          {t('chat.inputHelp', 'Press Enter to send')}
          {isVoiceSupported && ` • ${t('chat.voiceHelp', 'Click mic for voice input')}`}
        </div>
      </div>

      {/* Medical Disclaimer */}
      <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
        <p className="text-xs text-yellow-800">
          <strong>Medical Disclaimer:</strong> This AI assistant provides general information only and should not replace professional medical advice, diagnosis, or treatment. Always consult qualified healthcare professionals for personalized medical guidance.
        </p>
      </div>
    </div>
  );
}