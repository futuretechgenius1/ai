import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
  Calendar,
  AlertTriangle,
  Clock,
  Eye,
  TrendingUp,
  Activity,
  Heart,
  Stethoscope,
  LogIn
} from 'lucide-react';

interface SymptomAssessment {
  id: number;
  symptoms: string[];
  risk_score: number;
  urgency_level: string;
  ai_analysis: string;
  recommended_action: string;
  follow_up_needed: boolean;
  created_at: string;
}

const SymptomHistory: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [assessments, setAssessments] = useState<SymptomAssessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAssessment, setSelectedAssessment] = useState<SymptomAssessment | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAssessmentHistory();
  }, []);

  const fetchAssessmentHistory = async () => {
    try {
      setError(null);
      const token = localStorage.getItem('token');

      const response = await fetch('/api/symptoms/history', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setAssessments(data);
      } else if (response.status === 401 || response.status === 403) {
        setError('Please log in to view your assessment history.');
      } else {
        setError('Failed to load assessment history. Please try again.');
      }
    } catch (error) {
      console.error('Error fetching assessment history:', error);
      setError('Failed to load assessment history. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  const getUrgencyColor = (urgencyLevel: string) => {
    switch (urgencyLevel) {
      case 'emergency': return 'text-red-600 bg-red-50 border-red-200';
      case 'urgent': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'moderate': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default: return 'text-green-600 bg-green-50 border-green-200';
    }
  };

  const getUrgencyIcon = (urgencyLevel: string) => {
    switch (urgencyLevel) {
      case 'emergency': return <AlertTriangle className="h-5 w-5 text-red-600" />;
      case 'urgent': return <Clock className="h-5 w-5 text-orange-600" />;
      case 'moderate': return <Activity className="h-5 w-5 text-yellow-600" />;
      default: return <Heart className="h-5 w-5 text-green-600" />;
    }
  };

  // Show loading while checking authentication
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Show login prompt if not authenticated
  if (!user) {
    return (
      <div className="max-w-2xl mx-auto p-6 text-center">
        <div className="bg-white p-8 rounded-lg shadow-md">
          <LogIn className="h-16 w-16 mx-auto text-blue-600 mb-4" />
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Login Required</h1>
          <p className="text-gray-600 mb-6">
            Please log in to view your symptom assessment history. Guest assessments are not saved.
          </p>
          <div className="space-y-4">
            <button
              onClick={() => navigate('/')}
              className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Go to Login
            </button>
            <button
              onClick={() => navigate('/symptom-checker')}
              className="w-full bg-gray-100 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Try Symptom Checker
            </button>
            <p className="text-sm text-gray-500">
              Demo credentials: demo@pharmacist.com / demo123
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Stethoscope className="h-8 w-8 mr-3 text-blue-600" />
            Symptom Assessment History
          </h1>
          <p className="text-gray-600 mt-2">Review your previous symptom assessments and health insights</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500">Total Assessments</p>
          <p className="text-2xl font-bold text-blue-600">{assessments.length}</p>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
            <p className="text-red-800">{error}</p>
            <button
              onClick={fetchAssessmentHistory}
              className="ml-auto text-red-600 hover:text-red-800 text-sm underline"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {!error && assessments.length === 0 ? (
        <div className="text-center py-12">
          <Stethoscope className="h-16 w-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Assessments Yet</h3>
          <p className="text-gray-500 mb-6">Start using the AI Symptom Checker to track your health insights</p>
          <button
            onClick={() => navigate('/symptom-checker')}
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Start Assessment
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Assessment List */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Assessments</h2>
            {assessments.map((assessment) => (
              <div
                key={assessment.id}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all hover:shadow-md ${
                  selectedAssessment?.id === assessment.id 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
                onClick={() => setSelectedAssessment(assessment)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    {getUrgencyIcon(assessment.urgency_level)}
                    <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getUrgencyColor(assessment.urgency_level)}`}>
                      {assessment.urgency_level.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Risk Score</p>
                    <p className="font-bold text-lg">{assessment.risk_score}/10</p>
                  </div>
                </div>

                <div className="mb-3">
                  <p className="font-medium text-gray-900 mb-1">Symptoms:</p>
                  <div className="flex flex-wrap gap-1">
                    {assessment.symptoms.slice(0, 3).map((symptom, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                      >
                        {symptom}
                      </span>
                    ))}
                    {assessment.symptoms.length > 3 && (
                      <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                        +{assessment.symptoms.length - 3} more
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {new Date(assessment.created_at).toLocaleDateString()}
                  </div>
                  <div className="flex items-center">
                    <Eye className="h-4 w-4 mr-1" />
                    View Details
                  </div>
                </div>

                {assessment.follow_up_needed && (
                  <div className="mt-2 flex items-center text-orange-600">
                    <AlertTriangle className="h-4 w-4 mr-1" />
                    <span className="text-xs font-medium">Follow-up needed</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Assessment Details */}
          <div className="lg:sticky lg:top-6">
            {selectedAssessment ? (
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Assessment Details</h2>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getUrgencyColor(selectedAssessment.urgency_level)}`}>
                    {selectedAssessment.urgency_level.toUpperCase()}
                  </span>
                </div>

                <div className="space-y-6">
                  {/* Symptoms */}
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Reported Symptoms</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedAssessment.symptoms.map((symptom, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full"
                        >
                          {symptom}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Risk Assessment */}
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Risk Assessment</h3>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">Risk Score</span>
                        <span className="font-bold text-lg">{selectedAssessment.risk_score}/10</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            selectedAssessment.risk_score >= 7 ? 'bg-red-500' :
                            selectedAssessment.risk_score >= 4 ? 'bg-yellow-500' : 'bg-green-500'
                          }`}
                          style={{ width: `${(selectedAssessment.risk_score / 10) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  {/* Recommended Action */}
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Recommended Action</h3>
                    <div className={`p-4 rounded-lg border ${getUrgencyColor(selectedAssessment.urgency_level)}`}>
                      <p className="text-sm">{selectedAssessment.recommended_action}</p>
                    </div>
                  </div>

                  {/* AI Analysis */}
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">AI Medical Analysis</h3>
                    <div className="bg-gray-50 p-4 rounded-lg max-h-64 overflow-y-auto">
                      <pre className="whitespace-pre-wrap text-sm font-sans text-gray-700">
                        {selectedAssessment.ai_analysis}
                      </pre>
                    </div>
                  </div>

                  {/* Assessment Date */}
                  <div>
                    <h3 className="font-medium text-gray-900 mb-2">Assessment Date</h3>
                    <div className="flex items-center text-gray-600">
                      <Calendar className="h-4 w-4 mr-2" />
                      {new Date(selectedAssessment.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-gray-50 p-8 rounded-lg text-center">
                <TrendingUp className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Select an Assessment</h3>
                <p className="text-gray-500">Choose an assessment from the list to view detailed information</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SymptomHistory;
