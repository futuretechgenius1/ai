import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  TrendingUp,
  Users,
  Eye,
  FileText,
  Shield,
  Pill,
  Clock,
  MessageCircle,
  Activity,
  CheckCircle,
  AlertTriangle,
  XCircle,
  MoreHorizontal,
  Download,
  Share,
  ArrowUp,
  ArrowDown,
  Calendar,
  Heart,
  Stethoscope
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { dashboardAPI, caregiversAPI } from '../services/api';
import { useNotification } from '../contexts/NotificationContext';

interface DashboardStats {
  totalPrescriptions: number;
  activeReminders: number;
  drugsChecked: number;
  activeMedications: number;
  recentActions: number;
}

interface RecentActivity {
  id: string;
  type: 'prescription' | 'reminder' | 'interaction' | 'consultation';
  title: string;
  description: string;
  timestamp: string;
  status: 'completed' | 'in-progress' | 'pending' | 'overdue';
}

interface Patient {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  userId: string;
  signedUp: string;
  status: 'active' | 'pending' | 'inactive';
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalPrescriptions: 0,
    activeReminders: 0,
    drugsChecked: 0,
    activeMedications: 0,
    recentActions: 0
  });
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const { addNotification } = useNotification();

  const loadDashboardData = async () => {
    try {
      setLoading(true);

      // Fetch dashboard statistics
      const statsData = await dashboardAPI.getStats();
      setStats(statsData);

      // Fetch recent activity
      const activityData = await dashboardAPI.getActivity();
      const formattedActivity = activityData.map((item: any) => ({
        id: item.id.toString(),
        type: item.type === 'taken' ? 'prescription' :
              item.type === 'missed' ? 'reminder' :
              item.type === 'consultation' ? 'consultation' : 'reminder',
        title: item.title || 'Activity',
        description: item.description || 'No description available',
        timestamp: formatTimestamp(item.timestamp),
        status: item.status
      }));
      setRecentActivity(formattedActivity);

      // Fetch patients (if user is a caregiver)
      try {
        const patientsData = await caregiversAPI.getPatients();
        const formattedPatients = patientsData.map((patient: any) => ({
          id: patient.id.toString(),
          name: `${patient.first_name} ${patient.last_name}`,
          email: patient.email,
          userId: `#${patient.id}`,
          signedUp: new Date(patient.created_at || Date.now()).toLocaleDateString(),
          status: patient.active ? 'active' : 'inactive'
        }));
        setPatients(formattedPatients);
      } catch (error) {
        // User might not be a caregiver, that's okay
        setPatients([]);
      }

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      addNotification({
        type: 'error',
        title: 'Error',
        message: 'Failed to load dashboard data'
      });
    } finally {
      setLoading(false);
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
      case 'active':
        return 'text-green-600 bg-green-50';
      case 'in-progress':
        return 'text-blue-600 bg-blue-50';
      case 'pending':
        return 'text-yellow-600 bg-yellow-50';
      case 'overdue':
      case 'inactive':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'prescription':
        return <FileText className="w-4 h-4" />;
      case 'reminder':
        return <Clock className="w-4 h-4" />;
      case 'consultation':
        return <MessageCircle className="w-4 h-4" />;
      case 'interaction':
        return <AlertTriangle className="w-4 h-4" />;
      default:
        return <Activity className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Loading Dashboard</h2>
          <p className="text-gray-600">Preparing your healthcare data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-sm text-gray-600 mt-1">Welcome back! Here's what's happening with your health today.</p>
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={loadDashboardData}
              disabled={loading}
              className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
            >
              <Activity className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            <div className="text-sm text-gray-500">
              Last updated: {new Date().toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Prescriptions</p>
                <p className="text-3xl font-bold text-gray-900">{stats.totalPrescriptions.toLocaleString()}</p>
                <p className="text-sm text-gray-500 mt-1">
                  {stats.totalPrescriptions > 0 ? 'Active medications' : 'No prescriptions yet'}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Reminders</p>
                <p className="text-3xl font-bold text-gray-900">{stats.activeReminders}</p>
                <p className="text-sm text-gray-500 mt-1">
                  {stats.activeReminders > 0 ? 'Pending notifications' : 'All caught up!'}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Drugs Checked</p>
                <p className="text-3xl font-bold text-gray-900">{stats.drugsChecked}</p>
                <p className="text-sm text-gray-500 mt-1">
                  {stats.drugsChecked > 0 ? 'Unique medications' : 'No history yet'}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Medications</p>
                <p className="text-3xl font-bold text-gray-900">{stats.activeMedications}</p>
                <p className="text-sm text-gray-500 mt-1">
                  {stats.activeMedications > 0 ? 'Current medications' : 'No active medications'}
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-50 rounded-lg flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Activity */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
                <button className="text-sm text-blue-600 hover:text-blue-700">View all</button>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">{activity.title}</p>
                      <p className="text-sm text-gray-600">{activity.description}</p>
                      <p className="text-xs text-gray-500 mt-1">{activity.timestamp}</p>
                    </div>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(activity.status)}`}>
                      {activity.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-2 gap-4">
                <Link
                  to="/prescription"
                  className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:shadow-md transition-all duration-200 group"
                >
                  <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center mb-3 group-hover:bg-blue-100">
                    <FileText className="w-5 h-5 text-blue-600" />
                  </div>
                  <h4 className="font-medium text-gray-900">Analyze Prescription</h4>
                  <p className="text-sm text-gray-600 mt-1">Check drug interactions</p>
                </Link>

                <Link
                  to="/reminders"
                  className="p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:shadow-md transition-all duration-200 group"
                >
                  <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center mb-3 group-hover:bg-green-100">
                    <Clock className="w-5 h-5 text-green-600" />
                  </div>
                  <h4 className="font-medium text-gray-900">Set Reminder</h4>
                  <p className="text-sm text-gray-600 mt-1">Never miss a dose</p>
                </Link>

                <Link
                  to="/pill-identifier"
                  className="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:shadow-md transition-all duration-200 group"
                >
                  <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center mb-3 group-hover:bg-purple-100">
                    <Pill className="w-5 h-5 text-purple-600" />
                  </div>
                  <h4 className="font-medium text-gray-900">Identify Pill</h4>
                  <p className="text-sm text-gray-600 mt-1">Upload pill image</p>
                </Link>

                <Link
                  to="/chat"
                  className="p-4 border border-gray-200 rounded-lg hover:border-orange-300 hover:shadow-md transition-all duration-200 group"
                >
                  <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center mb-3 group-hover:bg-orange-100">
                    <MessageCircle className="w-5 h-5 text-orange-600" />
                  </div>
                  <h4 className="font-medium text-gray-900">AI Assistant</h4>
                  <p className="text-sm text-gray-600 mt-1">Get health advice</p>
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Patients Table */}
        {patients.length > 0 && (
          <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Your Patients</h3>
                <div className="flex items-center space-x-2">
                  <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </button>
                  <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    <Share className="w-4 h-4 mr-2" />
                    Share
                  </button>
                  <button className="p-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Patient Name
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Patient ID
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Registered
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {patients.map((patient) => (
                    <tr key={patient.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-8 w-8">
                            {patient.avatar ? (
                              <img className="h-8 w-8 rounded-full" src={patient.avatar} alt="" />
                            ) : (
                              <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                                <span className="text-sm font-medium text-gray-600">
                                  {patient.name.split(' ').map(n => n[0]).join('')}
                                </span>
                              </div>
                            )}
                          </div>
                          <div className="ml-3">
                            <div className="text-sm font-medium text-gray-900">{patient.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{patient.email}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{patient.userId}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{patient.signedUp}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(patient.status)}`}>
                          {patient.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="bg-gray-50 px-6 py-3 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-700">
                  Showing <span className="font-medium">1</span> to <span className="font-medium">{patients.length}</span> of{' '}
                  <span className="font-medium">{patients.length}</span> results
                </div>
                <div className="text-sm text-gray-500">
                  © AI Virtual Pharmacist. 2024
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
