import React, { useState, useEffect } from 'react';
import { Users, Plus, Shield, Eye, Settings, UserPlus, Heart, Clock, Pill, AlertTriangle } from 'lucide-react';
import { useNotification } from '../contexts/NotificationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { caregiversAPI, medicationsAPI, remindersAPI, medicationHistoryAPI } from '../services/api';

interface Caregiver {
  id: string;
  caregiver_id: string;
  patient_id: string;
  first_name: string;
  last_name: string;
  email: string;
  relationship: string;
  permissions: {
    viewMedications: boolean;
    manageReminders: boolean;
    viewHistory: boolean;
    receiveAlerts: boolean;
  };
  active: boolean;
  created_at: string;
}

interface Patient {
  id: string;
  patient_id: string;
  caregiver_id: string;
  first_name: string;
  last_name: string;
  email: string;
  relationship: string;
  permissions: any;
  active: boolean;
  created_at: string;
}

interface PatientOverview {
  medications: number;
  activeReminders: number;
  adherenceRate: number;
  lastActivity: string;
  recentMissedDoses: number;
}

export default function CaregiverMode() {
  const [activeTab, setActiveTab] = useState<'caregivers' | 'patients'>('caregivers');
  const [caregivers, setCaregivers] = useState<Caregiver[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<string>('');
  const [patientOverview, setPatientOverview] = useState<PatientOverview | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    caregiverEmail: '',
    relationship: '',
    permissions: {
      viewMedications: true,
      manageReminders: true,
      viewHistory: true,
      receiveAlerts: true
    }
  });

  const { addNotification } = useNotification();
  const { t } = useLanguage();
  const { user } = useAuth();

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (selectedPatient) {
      loadPatientOverview(selectedPatient);
    }
  }, [selectedPatient]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [caregiversData, patientsData] = await Promise.all([
        caregiversAPI.getCaregivers(),
        caregiversAPI.getPatients()
      ]);
      
      setCaregivers(caregiversData);
      setPatients(patientsData);
      
      if (patientsData.length > 0 && !selectedPatient) {
        setSelectedPatient(patientsData[0].patient_id);
      }
    } catch (error) {
      console.error('Error loading caregiver data:', error);
      addNotification({
        type: 'error',
        title: t('error.loadData', 'Error'),
        message: t('error.loadCaregiverData', 'Failed to load caregiver data')
      });
    } finally {
      setLoading(false);
    }
  };

  const loadPatientOverview = async (patientId: string) => {
    try {
      // This would need to be implemented in the backend to get patient-specific data
      // For now, we'll use placeholder data
      setPatientOverview({
        medications: 3,
        activeReminders: 8,
        adherenceRate: 85,
        lastActivity: new Date().toISOString(),
        recentMissedDoses: 2
      });
    } catch (error) {
      console.error('Error loading patient overview:', error);
    }
  };

  const handleAddCaregiver = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.caregiverEmail || !formData.relationship) {
      addNotification({
        type: 'error',
        title: t('error.validation', 'Validation Error'),
        message: t('error.fillRequired', 'Please fill in all required fields')
      });
      return;
    }

    try {
      setLoading(true);
      
      await caregiversAPI.addCaregiver({
        caregiverEmail: formData.caregiverEmail,
        relationship: formData.relationship,
        permissions: formData.permissions
      });
      
      addNotification({
        type: 'success',
        title: t('success.added', 'Added'),
        message: t('success.caregiverAdded', 'Caregiver added successfully')
      });
      
      await loadData();
      resetForm();
    } catch (error) {
      console.error('Error adding caregiver:', error);
      addNotification({
        type: 'error',
        title: t('error.add', 'Error'),
        message: t('error.addCaregiver', 'Failed to add caregiver')
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      caregiverEmail: '',
      relationship: '',
      permissions: {
        viewMedications: true,
        manageReminders: true,
        viewHistory: true,
        receiveAlerts: true
      }
    });
    setShowAddForm(false);
  };

  const getRelationshipOptions = () => [
    { value: 'spouse', label: t('relationship.spouse', 'Spouse') },
    { value: 'child', label: t('relationship.child', 'Child') },
    { value: 'parent', label: t('relationship.parent', 'Parent') },
    { value: 'sibling', label: t('relationship.sibling', 'Sibling') },
    { value: 'friend', label: t('relationship.friend', 'Friend') },
    { value: 'caregiver', label: t('relationship.caregiver', 'Professional Caregiver') },
    { value: 'other', label: t('relationship.other', 'Other') }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">{t('caregiver.title', 'Caregiver Mode')}</h1>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <UserPlus className="h-4 w-4 mr-2" />
          {t('caregiver.addCaregiver', 'Add Caregiver')}
        </button>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white shadow rounded-lg">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex">
            <button
              onClick={() => setActiveTab('caregivers')}
              className={`py-4 px-6 text-sm font-medium border-b-2 ${
                activeTab === 'caregivers'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Users className="h-4 w-4 inline mr-2" />
              {t('caregiver.myCaregivers', 'My Caregivers')} ({caregivers.length})
            </button>
            <button
              onClick={() => setActiveTab('patients')}
              className={`py-4 px-6 text-sm font-medium border-b-2 ${
                activeTab === 'patients'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Heart className="h-4 w-4 inline mr-2" />
              {t('caregiver.myPatients', 'My Patients')} ({patients.length})
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'caregivers' ? (
            <div className="space-y-4">
              <p className="text-gray-600">
                {t('caregiver.caregiversDescription', 'Manage who can help you with your medication management. Caregivers can view your medications, manage reminders, and receive alerts based on the permissions you grant.')}
              </p>
              
              {caregivers.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="mx-auto h-12 w-12 text-gray-400" />
                  <h4 className="mt-2 text-sm font-medium text-gray-900">
                    {t('caregiver.noCaregivers', 'No caregivers added')}
                  </h4>
                  <p className="mt-1 text-sm text-gray-500">
                    {t('caregiver.addFirstCaregiver', 'Add your first caregiver to get started')}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {caregivers.map((caregiver) => (
                    <div key={caregiver.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">
                            {caregiver.first_name} {caregiver.last_name}
                          </h4>
                          <p className="text-sm text-gray-500">{caregiver.email}</p>
                          <p className="text-sm text-blue-600 capitalize">{caregiver.relationship}</p>
                        </div>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          caregiver.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                          {caregiver.active ? t('status.active', 'Active') : t('status.inactive', 'Inactive')}
                        </span>
                      </div>
                      
                      <div className="mt-3">
                        <h5 className="text-xs font-medium text-gray-700 mb-2">
                          {t('caregiver.permissions', 'Permissions')}
                        </h5>
                        <div className="flex flex-wrap gap-1">
                          {caregiver.permissions.viewMedications && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                              <Pill className="h-3 w-3 mr-1" />
                              {t('permissions.viewMedications', 'View Medications')}
                            </span>
                          )}
                          {caregiver.permissions.manageReminders && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">
                              <Clock className="h-3 w-3 mr-1" />
                              {t('permissions.manageReminders', 'Manage Reminders')}
                            </span>
                          )}
                          {caregiver.permissions.viewHistory && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800">
                              <Eye className="h-3 w-3 mr-1" />
                              {t('permissions.viewHistory', 'View History')}
                            </span>
                          )}
                          {caregiver.permissions.receiveAlerts && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              {t('permissions.receiveAlerts', 'Receive Alerts')}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-gray-600">
                {t('caregiver.patientsDescription', 'Patients you are helping to manage their medications. You can view their information and help them based on the permissions they have granted you.')}
              </p>

              {patients.length === 0 ? (
                <div className="text-center py-8">
                  <Heart className="mx-auto h-12 w-12 text-gray-400" />
                  <h4 className="mt-2 text-sm font-medium text-gray-900">
                    {t('caregiver.noPatients', 'No patients assigned')}
                  </h4>
                  <p className="mt-1 text-sm text-gray-500">
                    {t('caregiver.waitForInvitation', 'Wait for patients to add you as their caregiver')}
                  </p>
                </div>
              ) : (
                <div>
                  {/* Patient Selector */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t('caregiver.selectPatient', 'Select Patient')}
                    </label>
                    <select
                      value={selectedPatient}
                      onChange={(e) => setSelectedPatient(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {patients.map((patient) => (
                        <option key={patient.patient_id} value={patient.patient_id}>
                          {patient.first_name} {patient.last_name} ({patient.relationship})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Patient Overview */}
                  {patientOverview && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <div className="flex items-center">
                          <Pill className="h-8 w-8 text-blue-600" />
                          <div className="ml-3">
                            <p className="text-sm font-medium text-blue-600">{t('stats.medications', 'Medications')}</p>
                            <p className="text-2xl font-bold text-blue-900">{patientOverview.medications}</p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-green-50 p-4 rounded-lg">
                        <div className="flex items-center">
                          <Clock className="h-8 w-8 text-green-600" />
                          <div className="ml-3">
                            <p className="text-sm font-medium text-green-600">{t('stats.reminders', 'Reminders')}</p>
                            <p className="text-2xl font-bold text-green-900">{patientOverview.activeReminders}</p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-purple-50 p-4 rounded-lg">
                        <div className="flex items-center">
                          <Shield className="h-8 w-8 text-purple-600" />
                          <div className="ml-3">
                            <p className="text-sm font-medium text-purple-600">{t('stats.adherence', 'Adherence')}</p>
                            <p className="text-2xl font-bold text-purple-900">{patientOverview.adherenceRate}%</p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-red-50 p-4 rounded-lg">
                        <div className="flex items-center">
                          <AlertTriangle className="h-8 w-8 text-red-600" />
                          <div className="ml-3">
                            <p className="text-sm font-medium text-red-600">{t('stats.missedDoses', 'Missed Doses')}</p>
                            <p className="text-2xl font-bold text-red-900">{patientOverview.recentMissedDoses}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Add Caregiver Form */}
      {showAddForm && (
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            {t('caregiver.addNewCaregiver', 'Add New Caregiver')}
          </h3>

          <form onSubmit={handleAddCaregiver} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('caregiver.email', 'Caregiver Email')} *
                </label>
                <input
                  type="email"
                  value={formData.caregiverEmail}
                  onChange={(e) => setFormData({...formData, caregiverEmail: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder={t('caregiver.emailPlaceholder', 'Enter caregiver\'s email address')}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t('caregiver.relationship', 'Relationship')} *
                </label>
                <select
                  value={formData.relationship}
                  onChange={(e) => setFormData({...formData, relationship: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">{t('caregiver.selectRelationship', 'Select relationship')}</option>
                  {getRelationshipOptions().map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                {t('caregiver.permissions', 'Permissions')}
              </label>
              <div className="space-y-3">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="viewMedications"
                    checked={formData.permissions.viewMedications}
                    onChange={(e) => setFormData({
                      ...formData,
                      permissions: { ...formData.permissions, viewMedications: e.target.checked }
                    })}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="viewMedications" className="ml-3 flex items-center text-sm text-gray-700">
                    <Pill className="h-4 w-4 mr-2 text-blue-500" />
                    {t('permissions.viewMedications', 'View Medications')}
                    <span className="ml-2 text-xs text-gray-500">
                      ({t('permissions.viewMedicationsDesc', 'Can see medication list and details')})
                    </span>
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="manageReminders"
                    checked={formData.permissions.manageReminders}
                    onChange={(e) => setFormData({
                      ...formData,
                      permissions: { ...formData.permissions, manageReminders: e.target.checked }
                    })}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="manageReminders" className="ml-3 flex items-center text-sm text-gray-700">
                    <Clock className="h-4 w-4 mr-2 text-green-500" />
                    {t('permissions.manageReminders', 'Manage Reminders')}
                    <span className="ml-2 text-xs text-gray-500">
                      ({t('permissions.manageRemindersDesc', 'Can create, edit, and delete reminders')})
                    </span>
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="viewHistory"
                    checked={formData.permissions.viewHistory}
                    onChange={(e) => setFormData({
                      ...formData,
                      permissions: { ...formData.permissions, viewHistory: e.target.checked }
                    })}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="viewHistory" className="ml-3 flex items-center text-sm text-gray-700">
                    <Eye className="h-4 w-4 mr-2 text-purple-500" />
                    {t('permissions.viewHistory', 'View History')}
                    <span className="ml-2 text-xs text-gray-500">
                      ({t('permissions.viewHistoryDesc', 'Can see medication history and adherence')})
                    </span>
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="receiveAlerts"
                    checked={formData.permissions.receiveAlerts}
                    onChange={(e) => setFormData({
                      ...formData,
                      permissions: { ...formData.permissions, receiveAlerts: e.target.checked }
                    })}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <label htmlFor="receiveAlerts" className="ml-3 flex items-center text-sm text-gray-700">
                    <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500" />
                    {t('permissions.receiveAlerts', 'Receive Alerts')}
                    <span className="ml-2 text-xs text-gray-500">
                      ({t('permissions.receiveAlertsDesc', 'Get notified about missed doses and issues')})
                    </span>
                  </label>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              >
                {t('common.cancel', 'Cancel')}
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {loading ? t('common.adding', 'Adding...') : t('caregiver.addCaregiver', 'Add Caregiver')}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Information Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <div className="flex">
            <Shield className="h-6 w-6 text-blue-500" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-blue-800">
                {t('caregiver.privacyTitle', 'Privacy & Security')}
              </h3>
              <p className="mt-1 text-sm text-blue-700">
                {t('caregiver.privacyDescription', 'You control what information caregivers can access. Permissions can be modified or revoked at any time. All caregiver actions are logged for your security.')}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-6">
          <div className="flex">
            <Heart className="h-6 w-6 text-green-500" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-green-800">
                {t('caregiver.benefitsTitle', 'Benefits of Caregiver Support')}
              </h3>
              <p className="mt-1 text-sm text-green-700">
                {t('caregiver.benefitsDescription', 'Caregivers can help ensure medication adherence, provide reminders, and offer support during your healthcare journey. They receive alerts when you miss doses or experience issues.')}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Medical Disclaimer */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <div className="flex">
          <AlertTriangle className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">
              {t('disclaimer.title', 'Important Medical Disclaimer')}
            </h3>
            <p className="mt-1 text-sm text-red-700">
              {t('disclaimer.caregiver', 'Caregivers are not medical professionals unless specifically qualified. This system is for support and convenience only. Always consult healthcare providers for medical decisions and emergencies.')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
