import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Pill, TrendingUp, AlertTriangle, CheckCircle, XCircle, Filter, Download, Search } from 'lucide-react';
import { useNotification } from '../contexts/NotificationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { medicationHistoryAPI, medicationsAPI } from '../services/api';

interface MedicationHistoryEntry {
  id: string;
  medication_id: string;
  medication_name: string;
  dosage: string;
  action: string;
  taken_at: string;
  notes?: string;
  side_effects?: string;
}

interface Medication {
  id: string;
  medication_name: string;
  dosage: string;
  frequency: string;
  start_date: string;
  end_date?: string;
  is_active: boolean;
  // Legacy fields for backward compatibility
  name?: string;
  active?: boolean;
}

interface HistoryStats {
  totalEntries: number;
  adherenceRate: number;
  missedDoses: number;
  sideEffectsReported: number;
  activeMedications: number;
}

export default function MedicationHistory() {
  const [history, setHistory] = useState<MedicationHistoryEntry[]>([]);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [stats, setStats] = useState<HistoryStats>({
    totalEntries: 0,
    adherenceRate: 0,
    missedDoses: 0,
    sideEffectsReported: 0,
    activeMedications: 0
  });
  const [loading, setLoading] = useState(false);
  const [selectedMedication, setSelectedMedication] = useState<string>('');
  const [selectedAction, setSelectedAction] = useState<string>('');
  const [expandedEntries, setExpandedEntries] = useState<Set<string>>(new Set());
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days ago
    end: new Date().toISOString().split('T')[0]
  });
  const [searchTerm, setSearchTerm] = useState('');

  const { addNotification } = useNotification();
  const { t } = useLanguage();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [historyData, medicationsData] = await Promise.all([
        medicationHistoryAPI.getAll(),
        medicationsAPI.getAll()
      ]);
      
      setHistory(historyData);
      setMedications(medicationsData);
      calculateStats(historyData, medicationsData);
    } catch (error) {
      console.error('Error loading data:', error);
      addNotification({
        type: 'error',
        title: t('error.loadData', 'Error'),
        message: t('error.loadDataMessage', 'Failed to load medication history')
      });
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (historyData: MedicationHistoryEntry[], medicationsData: Medication[]) => {
    const totalEntries = historyData.length;
    const takenEntries = historyData.filter(entry => entry.action === 'taken').length;
    const missedEntries = historyData.filter(entry => entry.action === 'missed').length;
    const sideEffectsEntries = historyData.filter(entry => entry.side_effects && entry.side_effects.trim()).length;
    const activeMedications = medicationsData.filter(med => med.active).length;
    
    const adherenceRate = totalEntries > 0 ? Math.round((takenEntries / (takenEntries + missedEntries)) * 100) : 0;

    setStats({
      totalEntries,
      adherenceRate: isNaN(adherenceRate) ? 0 : adherenceRate,
      missedDoses: missedEntries,
      sideEffectsReported: sideEffectsEntries,
      activeMedications
    });
  };

  const filteredHistory = history.filter(entry => {
    const matchesMedication = !selectedMedication || entry.medication_id === selectedMedication;
    const matchesAction = !selectedAction || entry.action === selectedAction;
    const matchesSearch = !searchTerm || 
      entry.medication_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (entry.notes && entry.notes.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (entry.side_effects && entry.side_effects.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const entryDate = new Date(entry.taken_at).toISOString().split('T')[0];
    const matchesDateRange = entryDate >= dateRange.start && entryDate <= dateRange.end;
    
    return matchesMedication && matchesAction && matchesSearch && matchesDateRange;
  });

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'taken':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'missed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'skipped':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return <Pill className="h-4 w-4 text-gray-500" />;
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'taken':
        return 'bg-green-100 text-green-800';
      case 'missed':
        return 'bg-red-100 text-red-800';
      case 'skipped':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const exportHistory = () => {
    const csvContent = [
      ['Date', 'Time', 'Medication', 'Dosage', 'Action', 'Notes', 'Side Effects'].join(','),
      ...filteredHistory.map(entry => [
        new Date(entry.taken_at).toLocaleDateString(),
        new Date(entry.taken_at).toLocaleTimeString(),
        entry.medication_name,
        entry.dosage,
        entry.action,
        entry.notes || '',
        entry.side_effects || ''
      ].map(field => `"${field}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medication-history-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);

    addNotification({
      type: 'success',
      title: t('export.success', 'Export Successful'),
      message: t('export.historyMessage', 'Medication history exported successfully')
    });
  };

  const recordMedicationAction = async (medicationId: string, action: string, notes?: string, sideEffects?: string) => {
    try {
      await medicationHistoryAPI.record({
        medicationId,
        action,
        notes,
        sideEffects
      });

      await loadData();

      addNotification({
        type: 'success',
        title: t('success.recorded', 'Recorded'),
        message: t('success.medicationAction', 'Medication action recorded successfully')
      });
    } catch (error) {
      console.error('Error recording medication action:', error);
      addNotification({
        type: 'error',
        title: t('error.record', 'Error'),
        message: t('error.recordAction', 'Failed to record medication action')
      });
    }
  };

  const toggleEntryExpansion = (entryId: string) => {
    const newExpanded = new Set(expandedEntries);
    if (newExpanded.has(entryId)) {
      newExpanded.delete(entryId);
    } else {
      newExpanded.add(entryId);
    }
    setExpandedEntries(newExpanded);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">{t('history.title', 'Medication History')}</h1>
        <button
          onClick={exportHistory}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Download className="h-4 w-4 mr-2" />
          {t('history.export', 'Export History')}
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Pill className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">{t('stats.activeMedications', 'Active Medications')}</p>
              <p className="text-2xl font-bold text-gray-900">{stats.activeMedications}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">{t('stats.adherenceRate', 'Adherence Rate')}</p>
              <p className="text-2xl font-bold text-gray-900">{stats.adherenceRate}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-gray-100 rounded-lg">
              <Calendar className="h-6 w-6 text-gray-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">{t('stats.totalEntries', 'Total Entries')}</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalEntries}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-red-100 rounded-lg">
              <XCircle className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">{t('stats.missedDoses', 'Missed Doses')}</p>
              <p className="text-2xl font-bold text-gray-900">{stats.missedDoses}</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <div className="flex items-center">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <AlertTriangle className="h-6 w-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">{t('stats.sideEffects', 'Side Effects')}</p>
              <p className="text-2xl font-bold text-gray-900">{stats.sideEffectsReported}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
          <Filter className="h-5 w-5 mr-2" />
          {t('history.filters', 'Filters')}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('history.searchTerm', 'Search')}
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={t('history.searchPlaceholder', 'Search medications, notes...')}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('history.medication', 'Medication')}
            </label>
            <select
              value={selectedMedication}
              onChange={(e) => setSelectedMedication(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">{t('history.allMedications', 'All Medications')}</option>
              {medications.map((medication) => (
                <option key={medication.id} value={medication.id}>
                  {medication.medication_name || medication.name} - {medication.dosage}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('history.action', 'Action')}
            </label>
            <select
              value={selectedAction}
              onChange={(e) => setSelectedAction(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">{t('history.allActions', 'All Actions')}</option>
              <option value="taken">{t('actions.taken', 'Taken')}</option>
              <option value="missed">{t('actions.missed', 'Missed')}</option>
              <option value="skipped">{t('actions.skipped', 'Skipped')}</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('history.startDate', 'Start Date')}
            </label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              {t('history.endDate', 'End Date')}
            </label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* History List */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            {t('history.entries', 'History Entries')} ({filteredHistory.length})
          </h3>
        </div>

        {loading ? (
          <div className="p-6 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-2 text-gray-500">{t('common.loading', 'Loading...')}</p>
          </div>
        ) : filteredHistory.length === 0 ? (
          <div className="p-6 text-center">
            <Calendar className="mx-auto h-12 w-12 text-gray-400" />
            <h4 className="mt-2 text-sm font-medium text-gray-900">
              {t('history.noEntries', 'No history entries found')}
            </h4>
            <p className="mt-1 text-sm text-gray-500">
              {t('history.noEntriesMessage', 'Try adjusting your filters or record some medication actions')}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {filteredHistory.map((entry) => {
              const isExpanded = expandedEntries.has(entry.id);
              return (
                <div key={entry.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          {getActionIcon(entry.action)}
                          <h4 className="ml-2 text-lg font-medium text-gray-900">
                            {entry.medication_name}
                          </h4>
                          <span className="ml-2 text-sm text-gray-500">
                            {entry.dosage}
                          </span>
                          <span className={`ml-3 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getActionColor(entry.action)}`}>
                            {t(`actions.${entry.action}`, entry.action)}
                          </span>
                        </div>

                        <button
                          onClick={() => toggleEntryExpansion(entry.id)}
                          className="ml-4 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                          <svg
                            className={`w-5 h-5 transform transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                          >
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                          </svg>
                        </button>
                      </div>

                      <div className="mt-2 flex items-center text-sm text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{new Date(entry.taken_at).toLocaleString()}</span>
                      </div>

                      {/* Expandable Details */}
                      {isExpanded && (
                        <div className="mt-4 space-y-3 border-t border-gray-200 pt-4">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-blue-50 p-3 rounded-lg">
                              <h5 className="font-medium text-blue-900 mb-1">Action Details</h5>
                              <p className="text-sm text-blue-700">
                                Action: <span className="font-medium">{t(`actions.${entry.action}`, entry.action)}</span>
                              </p>
                              <p className="text-sm text-blue-700">
                                Time: <span className="font-medium">{new Date(entry.taken_at).toLocaleString()}</span>
                              </p>
                            </div>

                            <div className="bg-green-50 p-3 rounded-lg">
                              <h5 className="font-medium text-green-900 mb-1">Medication Info</h5>
                              <p className="text-sm text-green-700">
                                Name: <span className="font-medium">{entry.medication_name}</span>
                              </p>
                              <p className="text-sm text-green-700">
                                Dosage: <span className="font-medium">{entry.dosage}</span>
                              </p>
                            </div>
                          </div>

                          {entry.notes && (
                            <div className="bg-gray-50 p-3 rounded-lg">
                              <h5 className="font-medium text-gray-900 mb-1">{t('history.notes', 'Notes')}</h5>
                              <p className="text-sm text-gray-700">{entry.notes}</p>
                            </div>
                          )}

                          {entry.side_effects && (
                            <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                              <div className="flex items-start">
                                <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                                <div>
                                  <h5 className="font-medium text-yellow-900 mb-1">{t('history.sideEffects', 'Side Effects')}</h5>
                                  <p className="text-sm text-yellow-700">{entry.side_effects}</p>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Quick Summary when collapsed */}
                      {!isExpanded && (entry.notes || entry.side_effects) && (
                        <div className="mt-2 text-xs text-gray-500">
                          {entry.notes && <span className="mr-3">📝 Has notes</span>}
                          {entry.side_effects && <span className="mr-3">⚠️ Side effects reported</span>}
                          <span className="text-blue-600 cursor-pointer" onClick={() => toggleEntryExpansion(entry.id)}>
                            Click to view details
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          {t('history.quickActions', 'Quick Actions')}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {medications.filter(med => med.is_active || med.active).slice(0, 3).map((medication) => (
            <div key={medication.id} className="border border-gray-200 rounded-lg p-4">
              <h4 className="font-medium text-gray-900">{medication.medication_name || medication.name}</h4>
              <p className="text-sm text-gray-500 mb-3">{medication.dosage}</p>

              <div className="flex space-x-2">
                <button
                  onClick={() => recordMedicationAction(medication.id, 'taken')}
                  className="flex-1 px-3 py-2 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700 transition-colors"
                >
                  {t('actions.markTaken', 'Mark Taken')}
                </button>
                <button
                  onClick={() => recordMedicationAction(medication.id, 'missed')}
                  className="flex-1 px-3 py-2 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition-colors"
                >
                  {t('actions.markMissed', 'Mark Missed')}
                </button>
              </div>
            </div>
          ))}
        </div>

        {medications.filter(med => med.active).length === 0 && (
          <div className="text-center py-8">
            <Pill className="mx-auto h-12 w-12 text-gray-400" />
            <h4 className="mt-2 text-sm font-medium text-gray-900">
              {t('history.noActiveMedications', 'No active medications')}
            </h4>
            <p className="mt-1 text-sm text-gray-500">
              {t('history.addMedicationsMessage', 'Add some medications to start tracking your history')}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
