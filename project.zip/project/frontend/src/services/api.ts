import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('authToken');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: async (userData: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phone?: string;
    dateOfBirth?: string;
    emergencyContact?: string;
    preferredLanguage?: string;
  }) => {
    const response = await api.post('/auth/register', userData);
    return response.data;
  },

  login: async (credentials: { email: string; password: string }) => {
    const response = await api.post('/auth/login', credentials);
    return response.data;
  },
};

// Medications API
export const medicationsAPI = {
  getAll: async () => {
    const response = await api.get('/medications');
    return response.data;
  },

  create: async (medication: {
    name: string;
    genericName?: string;
    dosage: string;
    frequency: string;
    instructions?: string;
    startDate: string;
    endDate?: string;
    prescriber?: string;
    pharmacy?: string;
    refillsRemaining?: number;
  }) => {
    const response = await api.post('/medications', medication);
    return response.data;
  },

  update: async (id: string, medication: any) => {
    const response = await api.put(`/medications/${id}`, medication);
    return response.data;
  },

  delete: async (id: string) => {
    const response = await api.delete(`/medications/${id}`);
    return response.data;
  },
};

// Reminders API
export const remindersAPI = {
  getAll: async () => {
    const response = await api.get('/reminders');
    return response.data;
  },

  create: async (reminder: {
    medicationId: string;
    reminderTime: string;
    daysOfWeek?: string;
    smsEnabled?: boolean;
  }) => {
    const response = await api.post('/reminders', reminder);
    return response.data;
  },

  update: async (id: string, reminder: any) => {
    const response = await api.put(`/reminders/${id}`, reminder);
    return response.data;
  },

  delete: async (id: string) => {
    const response = await api.delete(`/reminders/${id}`);
    return response.data;
  },
};

// Medication History API
export const medicationHistoryAPI = {
  getAll: async () => {
    const response = await api.get('/medication-history');
    return response.data;
  },

  record: async (history: {
    medicationId: string;
    action: string;
    notes?: string;
    sideEffects?: string;
  }) => {
    const response = await api.post('/medication-history', history);
    return response.data;
  },
};

// Prescriptions API
export const prescriptionsAPI = {
  upload: async (file: File) => {
    const formData = new FormData();
    formData.append('prescription', file);
    
    const response = await api.post('/prescriptions/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  analyze: async (id: string, data: { originalText: string; analyzedData: any }) => {
    const response = await api.post(`/prescriptions/${id}/analyze`, data);
    return response.data;
  },
};

// Caregivers API
export const caregiversAPI = {
  getCaregivers: async () => {
    const response = await api.get('/caregivers');
    return response.data;
  },

  getPatients: async () => {
    const response = await api.get('/patients');
    return response.data;
  },

  addCaregiver: async (caregiver: {
    caregiverEmail: string;
    relationship: string;
    permissions: any;
  }) => {
    const response = await api.post('/caregivers', caregiver);
    return response.data;
  },
};

// Dashboard API
export const dashboardAPI = {
  getStats: async () => {
    const response = await api.get('/dashboard/stats');
    return response.data;
  },

  getActivity: async () => {
    const response = await api.get('/dashboard/activity');
    return response.data;
  },
};

// User API
export const userAPI = {
  getProfile: async () => {
    const response = await api.get('/user/profile');
    return response.data;
  },

  updateProfile: async (profileData: any) => {
    const response = await api.put('/user/profile', profileData);
    return response.data;
  },
};

// Translation API
export const translationAPI = {
  translate: async (text: string, targetLanguage: string) => {
    const response = await api.post('/translate', { text, targetLanguage });
    return response.data;
  },
};

// Health check
export const healthAPI = {
  check: async () => {
    const response = await api.get('/health');
    return response.data;
  },
};

export default api;
