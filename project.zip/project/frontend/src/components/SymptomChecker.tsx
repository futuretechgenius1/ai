import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
  Search,
  AlertTriangle,
  Heart,
  Phone,
  MapPin,
  Clock,
  Pill,
  User,
  Calendar,
  ChevronRight,
  X,
  Plus,
  LogIn
} from 'lucide-react';

interface Symptom {
  name: string;
  category: string;
  severity: string;
}

interface SymptomInput {
  symptom: string;
  duration: string;
  severity: string;
}

interface Assessment {
  assessmentId: number;
  riskAssessment: {
    riskScore: number;
    urgencyLevel: string;
    action: string;
    redFlags: string[];
  };
  aiAnalysis: string;
  medicationRecommendations: any[];
  nearbyProviders: any[];
  telemedicineOptions: any[];
  disclaimer: string;
}

// Fallback symptoms in case API fails
const FALLBACK_SYMPTOMS: Symptom[] = [
  { name: 'headache', category: 'neurological', severity: 'mild' },
  { name: 'fever', category: 'general', severity: 'moderate' },
  { name: 'cough', category: 'respiratory', severity: 'mild' },
  { name: 'nausea', category: 'gastrointestinal', severity: 'mild' },
  { name: 'fatigue', category: 'general', severity: 'mild' },
  { name: 'dizziness', category: 'neurological', severity: 'moderate' },
  { name: 'chest pain', category: 'cardiovascular', severity: 'high' },
  { name: 'abdominal pain', category: 'gastrointestinal', severity: 'moderate' },
  { name: 'shortness of breath', category: 'respiratory', severity: 'moderate' },
  { name: 'diarrhea', category: 'gastrointestinal', severity: 'mild' }
];

const SymptomChecker: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [availableSymptoms, setAvailableSymptoms] = useState<Symptom[]>(FALLBACK_SYMPTOMS);
  const [selectedSymptoms, setSelectedSymptoms] = useState<SymptomInput[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [patientInfo, setPatientInfo] = useState({
    age: '',
    gender: '',
    conditions: [] as string[],
    medications: [] as string[]
  });
  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    fetchAvailableSymptoms();
  }, []);

  const fetchAvailableSymptoms = async () => {
    try {
      const response = await fetch('/api/symptoms/list');
      if (response.ok) {
        const symptoms = await response.json();

        if (symptoms && symptoms.length > 0) {
          setAvailableSymptoms(symptoms);
        } else {
          console.log('Using fallback symptoms');
          setAvailableSymptoms(FALLBACK_SYMPTOMS);
        }
      } else {
        console.error('Failed to fetch symptoms:', response.status);
        console.log('Using fallback symptoms due to API error');
        setAvailableSymptoms(FALLBACK_SYMPTOMS);
      }
    } catch (error) {
      console.error('Error fetching symptoms:', error);
      console.log('Using fallback symptoms due to network error');
      setAvailableSymptoms(FALLBACK_SYMPTOMS);
    }
  };

  const addSymptom = (symptom: Symptom) => {
    if (!selectedSymptoms.find(s => s.symptom === symptom.name)) {
      setSelectedSymptoms([...selectedSymptoms, {
        symptom: symptom.name,
        duration: '',
        severity: ''
      }]);
      setSearchTerm('');
    }
  };

  const removeSymptom = (index: number) => {
    setSelectedSymptoms(selectedSymptoms.filter((_, i) => i !== index));
  };

  const updateSymptom = (index: number, field: string, value: string) => {
    const updated = [...selectedSymptoms];
    updated[index] = { ...updated[index], [field]: value };
    setSelectedSymptoms(updated);
  };

  const analyzeSymptoms = async () => {
    if (selectedSymptoms.length === 0) {
      alert('Please select at least one symptom');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/symptoms/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          symptoms: selectedSymptoms.map(s => s.symptom),
          duration: selectedSymptoms.map(s => s.duration),
          severity: selectedSymptoms.map(s => s.severity),
          patientInfo,
          location: 'user-location' // Would get from geolocation
        })
      });

      if (response.ok) {
        const result = await response.json();
        setAssessment(result);
        setShowResults(true);
      } else {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || 'Failed to analyze symptoms');
      }
    } catch (error) {
      console.error('Error analyzing symptoms:', error);
      alert(`Error analyzing symptoms: ${error.message}. Please try again.`);
    } finally {
      setLoading(false);
    }
  };

  const getUrgencyColor = (urgencyLevel: string) => {
    switch (urgencyLevel) {
      case 'emergency': return 'text-red-600 bg-red-50 border-red-200';
      case 'urgent': return 'text-orange-600 bg-orange-50 border-orange-200';
      case 'moderate': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default: return 'text-green-600 bg-green-50 border-green-200';
    }
  };

  const filteredSymptoms = availableSymptoms.filter(symptom =>
    symptom.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Show loading while checking authentication
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Show guest mode notice if not authenticated
  const isGuestMode = !user;

  if (showResults && assessment) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-gray-900">Symptom Assessment Results</h1>
          <button
            onClick={() => setShowResults(false)}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Risk Assessment */}
        <div className={`p-6 rounded-lg border-2 mb-6 ${getUrgencyColor(assessment.riskAssessment.urgencyLevel)}`}>
          <div className="flex items-center mb-4">
            <AlertTriangle className="h-6 w-6 mr-2" />
            <h2 className="text-xl font-semibold">Risk Assessment</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="font-medium">Urgency Level: {assessment.riskAssessment.urgencyLevel.toUpperCase()}</p>
              <p className="font-medium">Risk Score: {assessment.riskAssessment.riskScore}/10</p>
            </div>
            <div>
              <p className="font-medium">Recommended Action:</p>
              <p>{assessment.riskAssessment.action}</p>
            </div>
          </div>
          {assessment.riskAssessment.redFlags.length > 0 && (
            <div className="mt-4">
              <p className="font-medium text-red-600">Warning Signs to Watch For:</p>
              <ul className="list-disc list-inside mt-2">
                {assessment.riskAssessment.redFlags.map((flag, index) => (
                  <li key={index} className="text-red-600">{flag}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* AI Analysis */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <User className="h-5 w-5 mr-2" />
            AI Medical Analysis
          </h2>
          <div className="prose max-w-none">
            <pre className="whitespace-pre-wrap font-sans">{assessment.aiAnalysis}</pre>
          </div>
        </div>

        {/* Medication Recommendations */}
        {assessment.medicationRecommendations.length > 0 && (
          <div className="bg-white p-6 rounded-lg shadow-md mb-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Pill className="h-5 w-5 mr-2" />
              Medication Recommendations
            </h2>
            {assessment.medicationRecommendations.map((rec, index) => (
              <div key={index} className="mb-4">
                <h3 className="font-medium text-lg mb-2">For {rec.symptom}:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {rec.medications.map((med: any, medIndex: number) => (
                    <div key={medIndex} className="border rounded-lg p-4">
                      <h4 className="font-medium">{med.name}</h4>
                      <p className="text-sm text-gray-600">{med.type}</p>
                      <p className="text-sm">{med.dosage}</p>
                      <p className="text-xs text-gray-500 mt-2">{med.notes}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Healthcare Providers */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <MapPin className="h-5 w-5 mr-2" />
              Nearby Healthcare Providers
            </h2>
            <div className="space-y-4">
              {assessment.nearbyProviders.map((provider, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <h3 className="font-medium">{provider.name}</h3>
                  <p className="text-sm text-gray-600">{provider.type}</p>
                  <p className="text-sm">{provider.address}</p>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm text-gray-500">{provider.distance}</span>
                    <span className="text-sm text-green-600">{provider.waitTime}</span>
                  </div>
                  <button className="mt-2 text-blue-600 hover:text-blue-800 flex items-center">
                    <Phone className="h-4 w-4 mr-1" />
                    {provider.phone}
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Heart className="h-5 w-5 mr-2" />
              Telemedicine Options
            </h2>
            <div className="space-y-4">
              {assessment.telemedicineOptions.map((option, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <h3 className="font-medium">{option.name}</h3>
                  <p className="text-sm text-gray-600">{option.specialties.join(', ')}</p>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm text-green-600">{option.availability}</span>
                    <span className="text-sm font-medium">{option.cost}</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-sm text-yellow-600">★ {option.rating}</span>
                    <button className="text-blue-600 hover:text-blue-800 text-sm">
                      Start Consultation
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-sm text-yellow-800">{assessment.disclaimer}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Guest Mode Banner */}
      {isGuestMode && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
            <div className="flex-1">
              <p className="text-sm text-yellow-800">
                <strong>Guest Mode:</strong> You're using the symptom checker without logging in.
                Your assessment won't be saved to history.
              </p>
            </div>
            <button
              onClick={() => navigate('/')}
              className="ml-4 text-yellow-800 hover:text-yellow-900 text-sm underline"
            >
              Login to Save Results
            </button>
          </div>
        </div>
      )}

      <div className="text-center mb-8">
        <div className="flex items-center justify-between mb-4">
          <div></div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Symptom Checker</h1>
            <p className="text-gray-600">Describe your symptoms and get a preliminary health assessment</p>
          </div>
          {!isGuestMode && (
            <button
              onClick={() => navigate('/symptom-history')}
              className="text-blue-600 hover:text-blue-800 flex items-center text-sm"
            >
              <Calendar className="h-4 w-4 mr-1" />
              View History
            </button>
          )}
        </div>
      </div>

      {/* Patient Information */}
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">Patient Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Age</label>
            <input
              type="number"
              value={patientInfo.age}
              onChange={(e) => setPatientInfo({...patientInfo, age: e.target.value})}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter age"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Gender</label>
            <select
              value={patientInfo.gender}
              onChange={(e) => setPatientInfo({...patientInfo, gender: e.target.value})}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
              <option value="prefer-not-to-say">Prefer not to say</option>
            </select>
          </div>
        </div>
      </div>

      {/* Symptom Selection */}
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-semibold mb-4">Select Your Symptoms</h2>
        
        {/* Search for symptoms */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && searchTerm.trim()) {
                // Allow manual addition if no matches found
                if (filteredSymptoms.length === 0) {
                  addSymptom({ name: searchTerm.trim(), category: 'general', severity: 'mild' });
                }
              }
            }}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Search for symptoms... (Press Enter to add custom symptom)"
          />
        </div>

        {/* Symptom suggestions */}
        {searchTerm && (
          <div className="mb-4 max-h-40 overflow-y-auto border border-gray-200 rounded-lg">
            {filteredSymptoms.length > 0 ? (
              filteredSymptoms.map((symptom, index) => (
                <button
                  key={index}
                  onClick={() => addSymptom(symptom)}
                  className="w-full text-left p-3 hover:bg-gray-50 border-b border-gray-100 last:border-b-0"
                >
                  <div className="flex justify-between items-center">
                    <span>{symptom.name}</span>
                    <span className="text-xs text-gray-500 capitalize">{symptom.category}</span>
                  </div>
                </button>
              ))
            ) : (
              <div className="p-3 text-gray-500 text-center">
                {availableSymptoms.length === 0
                  ? 'Loading symptoms...'
                  : `No symptoms found matching "${searchTerm}"`
                }
              </div>
            )}
          </div>
        )}

        {/* Quick add common symptoms */}
        {!searchTerm && selectedSymptoms.length === 0 && (
          <div className="mb-4">
            <p className="text-sm text-gray-600 mb-2">Quick add common symptoms:</p>
            <div className="flex flex-wrap gap-2">
              {['headache', 'fever', 'cough', 'nausea', 'fatigue'].map((symptom) => (
                <button
                  key={symptom}
                  onClick={() => addSymptom({ name: symptom, category: 'general', severity: 'mild' })}
                  className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm hover:bg-blue-200"
                >
                  {symptom}
                </button>
              ))}
            </div>
          </div>
        )}



        {/* Selected symptoms */}
        <div className="space-y-4">
          {selectedSymptoms.map((symptom, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <h3 className="font-medium">{symptom.symptom}</h3>
                <button
                  onClick={() => removeSymptom(index)}
                  className="text-red-500 hover:text-red-700"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Duration</label>
                  <select
                    value={symptom.duration}
                    onChange={(e) => updateSymptom(index, 'duration', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select duration</option>
                    <option value="less-than-1-day">Less than 1 day</option>
                    <option value="1-3-days">1-3 days</option>
                    <option value="4-7-days">4-7 days</option>
                    <option value="1-2-weeks">1-2 weeks</option>
                    <option value="more-than-2-weeks">More than 2 weeks</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Severity</label>
                  <select
                    value={symptom.severity}
                    onChange={(e) => updateSymptom(index, 'severity', e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select severity</option>
                    <option value="mild">Mild</option>
                    <option value="moderate">Moderate</option>
                    <option value="severe">Severe</option>
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>

        {selectedSymptoms.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Search className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>Search and select symptoms to get started</p>
          </div>
        )}
      </div>

      {/* Analyze Button */}
      {selectedSymptoms.length > 0 && (
        <div className="text-center">
          <button
            onClick={analyzeSymptoms}
            disabled={loading}
            className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center mx-auto"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Analyzing...
              </>
            ) : (
              <>
                <Heart className="h-5 w-5 mr-2" />
                Analyze Symptoms
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};

export default SymptomChecker;
