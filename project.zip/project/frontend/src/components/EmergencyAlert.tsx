import React, { useState, useEffect } from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface EmergencyAlert {
  id: string;
  type: 'critical' | 'warning';
  title: string;
  message: string;
  medication?: string;
}

export default function EmergencyAlert() {
  const [alerts, setAlerts] = useState<EmergencyAlert[]>([]);

  useEffect(() => {
    // Simulate checking for emergency alerts
    const checkAlerts = () => {
      // This would normally check the database for high-risk medication alerts
      const mockAlerts: EmergencyAlert[] = [];
      setAlerts(mockAlerts);
    };

    checkAlerts();
    const interval = setInterval(checkAlerts, 60000); // Check every minute

    return () => clearInterval(interval);
  }, []);

  const dismissAlert = (id: string) => {
    setAlerts(alerts.filter(alert => alert.id !== id));
  };

  if (alerts.length === 0) return null;

  return (
    <div className="mb-6 space-y-4">
      {alerts.map((alert) => (
        <div
          key={alert.id}
          className={`rounded-lg p-4 ${
            alert.type === 'critical' 
              ? 'bg-red-50 border border-red-200' 
              : 'bg-yellow-50 border border-yellow-200'
          }`}
        >
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle 
                className={`h-5 w-5 ${
                  alert.type === 'critical' ? 'text-red-400' : 'text-yellow-400'
                }`} 
              />
            </div>
            <div className="ml-3 flex-1">
              <h3 className={`text-sm font-medium ${
                alert.type === 'critical' ? 'text-red-800' : 'text-yellow-800'
              }`}>
                {alert.title}
              </h3>
              <div className={`mt-2 text-sm ${
                alert.type === 'critical' ? 'text-red-700' : 'text-yellow-700'
              }`}>
                <p>{alert.message}</p>
                {alert.medication && (
                  <p className="mt-1 font-medium">Medication: {alert.medication}</p>
                )}
              </div>
            </div>
            <div className="ml-auto pl-3">
              <div className="-mx-1.5 -my-1.5">
                <button
                  onClick={() => dismissAlert(alert.id)}
                  className={`inline-flex rounded-md p-1.5 focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                    alert.type === 'critical'
                      ? 'text-red-500 hover:bg-red-100 focus:ring-offset-red-50 focus:ring-red-600'
                      : 'text-yellow-500 hover:bg-yellow-100 focus:ring-offset-yellow-50 focus:ring-yellow-600'
                  }`}
                >
                  <span className="sr-only">Dismiss</span>
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}