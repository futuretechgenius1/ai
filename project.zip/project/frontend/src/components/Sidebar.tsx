import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  Shield,
  Pill,
  Clock,
  MessageCircle,
  User,
  History,
  Users,
  X,
  ChevronLeft,
  ChevronRight,
  Bot,
  Brain,
  Sparkles,
  Heart,
  Stethoscope
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

const getNavigation = (t: (key: string, fallback?: string) => string) => [
  { name: t('nav.dashboard', 'Dashboard'), href: '/dashboard', icon: LayoutDashboard },
  { name: t('nav.prescription', 'Prescription Analyzer'), href: '/prescription', icon: FileText },
  { name: t('nav.drugChecker', 'Drug Checker'), href: '/drug-checker', icon: Shield },
  { name: t('nav.pillIdentifier', 'Pill Identifier'), href: '/pill-identifier', icon: Pill },
  { name: t('nav.reminders', 'Reminders'), href: '/reminders', icon: Clock },
  { name: t('nav.chat', 'AI Assistant'), href: '/chat', icon: MessageCircle },
  { name: t('nav.symptomChecker', 'AI Symptom Checker'), href: '/symptom-checker', icon: Stethoscope },
  { name: t('nav.history', 'Medication History'), href: '/history', icon: History },
  { name: t('nav.caregiver', 'Caregiver Mode'), href: '/caregiver', icon: Users },
  { name: t('nav.profile', 'Profile'), href: '/profile', icon: User },
];

export default function Sidebar({ isOpen, onClose, isCollapsed = false, onToggleCollapse }: SidebarProps) {
  const { t } = useLanguage();
  const navigation = getNavigation(t);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [isHovered, setIsHovered] = useState(false);

  // Handle mouse enter/leave for the entire sidebar
  const handleMouseEnter = () => {
    if (isCollapsed) {
      setIsHovered(true);
    }
  };

  const handleMouseLeave = () => {
    if (isCollapsed) {
      setIsHovered(false);
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-gradient-to-br from-blue-900/80 via-purple-900/80 to-teal-900/80 backdrop-blur-sm z-20 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div
        className={`
          fixed inset-y-0 left-0 z-30 transform transition-all duration-300 ease-in-out
          lg:relative lg:translate-x-0 lg:flex lg:flex-col lg:min-h-full
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          ${isCollapsed && !isHovered ? 'lg:w-20' : 'lg:w-72'}
          w-72
        `}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
      >
        {/* Sidebar Background with AI Theme */}
        <div className="relative h-full bg-gradient-to-b from-blue-900 via-purple-900 to-teal-900 shadow-2xl">
          {/* Animated Background Elements */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 left-4 w-8 h-8 bg-blue-400 rounded-full animate-pulse"></div>
            <div className="absolute top-32 right-4 w-6 h-6 bg-green-400 rounded-full animate-bounce"></div>
            <div className="absolute bottom-20 left-6 w-10 h-10 bg-purple-400 rounded-full animate-pulse"></div>
            <div className="absolute bottom-40 right-6 w-4 h-4 bg-teal-400 rounded-full animate-bounce"></div>
            
            {/* Medical Icons Floating */}
            <div className="absolute top-20 left-8 text-white/20">
              <Heart className="w-4 h-4 animate-pulse" />
            </div>
            <div className="absolute bottom-32 right-8 text-white/20">
              <Stethoscope className="w-5 h-5 animate-bounce" />
            </div>
          </div>

          {/* Header Section */}
          <div className="relative z-10 p-4">
            {/* Mobile Close Button */}
            <div className="flex items-center justify-between lg:hidden mb-4">
              <span className="text-lg font-semibold text-white">Menu</span>
              <button
                onClick={onClose}
                className="p-2 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-all duration-200"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Desktop Toggle Button */}
            {onToggleCollapse && (
              <button
                onClick={onToggleCollapse}
                className="hidden lg:flex absolute -right-3 top-4 w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full items-center justify-center shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-110"
              >
                {isCollapsed ? (
                  <ChevronRight className="w-3 h-3 text-white" />
                ) : (
                  <ChevronLeft className="w-3 h-3 text-white" />
                )}
              </button>
            )}
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
            {navigation.map((item, index) => (
              <div
                key={item.name}
                onMouseEnter={() => setHoveredItem(item.name)}
                onMouseLeave={() => setHoveredItem(null)}
                className="relative"
              >
                <NavLink
                  to={item.href}
                  onClick={() => onClose()}
                  className={({ isActive }) =>
                    `group relative flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-all duration-300 transform hover:scale-105 ${
                      isActive
                        ? 'bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-white border-r-4 border-blue-400 shadow-lg'
                        : 'text-blue-100 hover:bg-white/10 hover:text-white'
                    } ${isCollapsed && !isHovered ? 'justify-center' : ''}`
                  }
                >
                  {/* Icon with gradient background */}
                  <div className={`relative flex items-center justify-center rounded-lg transition-all duration-300 ${
                    isCollapsed && !isHovered ? 'w-8 h-8' : 'w-8 h-8 mr-3'
                  } ${
                    index === 0 ? 'bg-gradient-to-r from-blue-500/30 to-blue-600/30' :
                    index === 1 ? 'bg-gradient-to-r from-green-500/30 to-green-600/30' :
                    index === 2 ? 'bg-gradient-to-r from-purple-500/30 to-purple-600/30' :
                    index === 3 ? 'bg-gradient-to-r from-orange-500/30 to-orange-600/30' :
                    index === 4 ? 'bg-gradient-to-r from-red-500/30 to-red-600/30' :
                    index === 5 ? 'bg-gradient-to-r from-indigo-500/30 to-indigo-600/30' :
                    index === 6 ? 'bg-gradient-to-r from-pink-500/30 to-pink-600/30' :
                    index === 7 ? 'bg-gradient-to-r from-teal-500/30 to-teal-600/30' :
                    'bg-gradient-to-r from-gray-500/30 to-gray-600/30'
                  }`}>
                    <item.icon className="h-4 w-4 flex-shrink-0" />
                  </div>
                  
                  {/* Text */}
                  {(!isCollapsed || isHovered) && (
                    <span className="truncate">{item.name}</span>
                  )}
                  
                  {/* Hover indicator */}
                  <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-blue-400/0 via-purple-400/0 to-teal-400/0 group-hover:from-blue-400/10 group-hover:via-purple-400/10 group-hover:to-teal-400/10 transition-all duration-300"></div>
                </NavLink>

                {/* Tooltip for collapsed state - only show when collapsed and not hovered */}
                {isCollapsed && !isHovered && hoveredItem === item.name && (
                  <div className="absolute left-full ml-2 top-1/2 transform -translate-y-1/2 z-50">
                    <div className="bg-gray-900 text-white px-3 py-2 rounded-lg text-sm font-medium shadow-xl border border-gray-700">
                      {item.name}
                      <div className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-1 w-2 h-2 bg-gray-900 rotate-45 border-l border-b border-gray-700"></div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </nav>

        </div>
      </div>
    </>
  );
}
