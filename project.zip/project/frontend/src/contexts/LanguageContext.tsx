import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { translationAPI } from '../services/api';
import Together from 'together-ai';

interface Language {
  code: string;
  name: string;
  nativeName: string;
}

interface LanguageContextType {
  currentLanguage: string;
  setLanguage: (languageCode: string) => void;
  translate: (text: string, targetLanguage?: string) => Promise<string>;
  t: (key: string, fallback?: string) => string;
  languages: Language[];
  isTranslating: boolean;
}

const languages: Language[] = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు' },
];

// Basic translations for common UI elements
const translations: Record<string, Record<string, string>> = {
  en: {
    'app.title': 'AI Virtual Pharmacist Assistant',
    'nav.dashboard': 'Dashboard',
    'nav.prescription': 'Prescription Analyzer',
    'nav.drugChecker': 'Drug Checker',
    'nav.pillIdentifier': 'Pill Identifier',
    'nav.reminders': 'Reminders',
    'nav.chat': 'AI Assistant',
    'nav.profile': 'Profile',
    'auth.login': 'Login',
    'auth.register': 'Register',
    'auth.logout': 'Logout',
    'common.loading': 'Loading...',
    'common.error': 'Error',
    'common.success': 'Success',
    'common.cancel': 'Cancel',
    'common.save': 'Save',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.add': 'Add',
    'common.search': 'Search',
    'common.upload': 'Upload',
    'common.download': 'Download',
    'medication.name': 'Medication Name',
    'medication.dosage': 'Dosage',
    'medication.frequency': 'Frequency',
    'medication.instructions': 'Instructions',
    'reminder.time': 'Reminder Time',
    'reminder.daily': 'Daily',
    'reminder.weekly': 'Weekly',
    'emergency.call911': 'Emergency: Call 911',
    'emergency.poisonControl': 'Poison Control: 1-800-222-1222',
  },
  es: {
    'app.title': 'Asistente Virtual de Farmacia con IA',
    'nav.dashboard': 'Panel de Control',
    'nav.prescription': 'Analizador de Recetas',
    'nav.drugChecker': 'Verificador de Medicamentos',
    'nav.pillIdentifier': 'Identificador de Píldoras',
    'nav.reminders': 'Recordatorios',
    'nav.chat': 'Asistente IA',
    'nav.profile': 'Perfil',
    'auth.login': 'Iniciar Sesión',
    'auth.register': 'Registrarse',
    'auth.logout': 'Cerrar Sesión',
    'common.loading': 'Cargando...',
    'common.error': 'Error',
    'common.success': 'Éxito',
    'common.cancel': 'Cancelar',
    'common.save': 'Guardar',
    'common.delete': 'Eliminar',
    'common.edit': 'Editar',
    'common.add': 'Agregar',
    'common.search': 'Buscar',
    'common.upload': 'Subir',
    'common.download': 'Descargar',
    'medication.name': 'Nombre del Medicamento',
    'medication.dosage': 'Dosis',
    'medication.frequency': 'Frecuencia',
    'medication.instructions': 'Instrucciones',
    'reminder.time': 'Hora del Recordatorio',
    'reminder.daily': 'Diario',
    'reminder.weekly': 'Semanal',
    'emergency.call911': 'Emergencia: Llame al 911',
    'emergency.poisonControl': 'Control de Envenenamiento: 1-800-222-1222',
  },
  hi: {
    'app.title': 'एआई वर्चुअल फार्मासिस्ट असिस्टेंट',
    'nav.dashboard': 'डैशबोर्ड',
    'nav.prescription': 'प्रिस्क्रिप्शन एनालाइज़र',
    'nav.drugChecker': 'ड्रग चेकर',
    'nav.pillIdentifier': 'पिल आइडेंटिफायर',
    'nav.reminders': 'रिमाइंडर',
    'nav.chat': 'एआई असिस्टेंट',
    'nav.profile': 'प्रोफाइल',
    'auth.login': 'लॉगिन',
    'auth.register': 'रजिस्टर',
    'auth.logout': 'लॉगआउट',
    'common.loading': 'लोड हो रहा है...',
    'common.error': 'त्रुटि',
    'common.success': 'सफलता',
    'common.cancel': 'रद्द करें',
    'common.save': 'सेव करें',
    'common.delete': 'डिलीट करें',
    'common.edit': 'एडिट करें',
    'common.add': 'जोड़ें',
    'common.search': 'खोजें',
    'common.upload': 'अपलोड',
    'common.download': 'डाउनलोड',
    'medication.name': 'दवा का नाम',
    'medication.dosage': 'खुराक',
    'medication.frequency': 'आवृत्ति',
    'medication.instructions': 'निर्देश',
    'reminder.time': 'रिमाइंडर समय',
    'reminder.daily': 'दैनिक',
    'reminder.weekly': 'साप्ताहिक',
    'emergency.call911': 'आपातकाल: 911 पर कॉल करें',
    'emergency.poisonControl': 'पॉइज़न कंट्रोल: 1-800-222-1222',
  },
  te: {
    'app.title': 'AI వర్చువల్ ఫార్మసిస్ట్ అసిస్టెంట్',
    'nav.dashboard': 'డాష్‌బోర్డ్',
    'nav.prescription': 'ప్రిస్క్రిప్షన్ అనలైజర్',
    'nav.drugChecker': 'డ్రగ్ చెకర్',
    'nav.pillIdentifier': 'పిల్ ఐడెంటిఫైయర్',
    'nav.reminders': 'రిమైండర్లు',
    'nav.chat': 'AI అసిస్టెంట్',
    'nav.profile': 'ప్రొఫైల్',
    'auth.login': 'లాగిన్',
    'auth.register': 'రిజిస్టర్',
    'auth.logout': 'లాగ్అవుట్',
    'common.loading': 'లోడ్ అవుతోంది...',
    'common.error': 'లోపం',
    'common.success': 'విజయం',
    'common.cancel': 'రద్దు చేయండి',
    'common.save': 'సేవ్ చేయండి',
    'common.delete': 'తొలగించండి',
    'common.edit': 'ఎడిట్ చేయండి',
    'common.add': 'జోడించండి',
    'common.search': 'వెతకండి',
    'common.upload': 'అప్‌లోడ్',
    'common.download': 'డౌన్‌లోడ్',
    'medication.name': 'మందు పేరు',
    'medication.dosage': 'మోతాదు',
    'medication.frequency': 'ఫ్రీక్వెన్సీ',
    'medication.instructions': 'సూచనలు',
    'reminder.time': 'రిమైండర్ సమయం',
    'reminder.daily': 'రోజువారీ',
    'reminder.weekly': 'వారానికి',
    'emergency.call911': 'అత్యవసరం: 911కి కాల్ చేయండి',
    'emergency.poisonControl': 'పాయిజన్ కంట్రోల్: 1-800-222-1222',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<string>('en');
  const [isTranslating, setIsTranslating] = useState(false);

  const together = new Together({
    apiKey: import.meta.env.VITE_TOGETHER_API_KEY || '7323b782a40ca2bdbdf780016aeb8662befc0894c9f4e5385bfcdde33f5147a1'
  });

  useEffect(() => {
    // Load saved language preference
    const savedLanguage = localStorage.getItem('preferredLanguage');
    if (savedLanguage && languages.find(lang => lang.code === savedLanguage)) {
      setCurrentLanguage(savedLanguage);
    }
  }, []);

  const setLanguage = (languageCode: string) => {
    setCurrentLanguage(languageCode);
    localStorage.setItem('preferredLanguage', languageCode);
  };

  const translate = async (text: string, targetLanguage?: string): Promise<string> => {
    const target = targetLanguage || currentLanguage;
    
    if (target === 'en') {
      return text; // No translation needed for English
    }

    setIsTranslating(true);
    
    try {
      const languageNames = {
        es: 'Spanish',
        hi: 'Hindi',
        te: 'Telugu'
      };

      const prompt = `Translate the following text to ${languageNames[target as keyof typeof languageNames] || target}. Only return the translated text, nothing else:

${text}`;

      const response = await together.chat.completions.create({
        messages: [{ role: "user", content: prompt }],
        model: "mistralai/Mistral-7B-Instruct-v0.1",
        max_tokens: 1000,
        temperature: 0.1
      });

      const translatedText = response.choices[0]?.message?.content?.trim() || text;
      return translatedText;
    } catch (error) {
      console.error('Translation error:', error);
      return text; // Return original text if translation fails
    } finally {
      setIsTranslating(false);
    }
  };

  const t = (key: string, fallback?: string): string => {
    const translation = translations[currentLanguage]?.[key];
    return translation || fallback || key;
  };

  const value = {
    currentLanguage,
    setLanguage,
    translate,
    t,
    languages,
    isTranslating,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}
