# 🛠️ Development Guide

## Project Structure Overview

The project has been reorganized into a clean, maintainable structure:

```
project/
├── frontend/              # React + TypeScript frontend application
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Page-level components (Dashboard, Reminders, etc.)
│   │   ├── contexts/      # React Context providers (Auth, Language, etc.)
│   │   ├── services/      # API service functions
│   │   └── hooks/         # Custom React hooks
│   ├── package.json       # Frontend dependencies and scripts
│   └── vite.config.ts     # Vite configuration
├── server/                # Node.js + Express backend
│   ├── scripts/           # Database utilities and test scripts
│   ├── uploads/           # File upload storage
│   ├── package.json       # Backend dependencies and scripts
│   └── server.js          # Main server file
├── scripts/               # Development helper scripts
│   ├── dev-helper.js      # Development command helper
│   └── setup.js           # Project setup script
├── package.json           # Root package.json with orchestration scripts
└── README.md              # Main documentation
```

## 🚀 Quick Commands

### Development
```bash
npm run dev              # Start both frontend and backend
npm run dev:frontend     # Start only frontend (port 5173)
npm run dev:backend      # Start only backend (port 5000)
```

### Setup & Maintenance
```bash
npm run setup           # Initial project setup
npm run install:all     # Install all dependencies
npm run clean           # Clean all node_modules
npm run build           # Build frontend for production
```

### Testing
```bash
npm run test:api        # Test backend API endpoints
npm run test:reminders  # Test reminder CRUD operations
```

### Helper Scripts
```bash
npm run helper          # Show available development commands
npm run helper dev      # Start development servers
npm run helper install  # Install dependencies
```

## 📁 Key Directories

### Frontend (`frontend/src/`)
- **`components/`** - Reusable UI components (buttons, forms, modals)
- **`pages/`** - Main application pages:
  - `Dashboard.tsx` - Main dashboard
  - `Reminders.tsx` - Medication reminders management
  - `DrugChecker.tsx` - Drug interaction checker
  - `PrescriptionAnalyzer.tsx` - Prescription analysis
  - `PillIdentifier.tsx` - Pill identification
  - `ChatAssistant.tsx` - AI chat interface
  - `MedicationHistory.tsx` - Medication tracking
- **`contexts/`** - React contexts:
  - `AuthContext.tsx` - Authentication state
  - `LanguageContext.tsx` - Multi-language support
  - `NotificationContext.tsx` - Toast notifications
- **`services/`** - API communication:
  - `api.ts` - Main API service
  - Individual service files for different features

### Backend (`server/`)
- **`server.js`** - Main Express server with all routes
- **`scripts/`** - Utility scripts:
  - `test-api.js` - API endpoint testing
  - `test-reminders-crud.js` - Reminder operations testing
  - `add-sample-data.js` - Sample data creation
- **`uploads/`** - File storage for prescription images

## 🔧 Development Workflow

### Adding New Features

1. **Frontend Component:**
   ```bash
   cd frontend/src/components
   # Create new component file
   # Import and use in pages
   ```

2. **New Page:**
   ```bash
   cd frontend/src/pages
   # Create new page component
   # Add route in App.tsx
   ```

3. **Backend API:**
   ```bash
   cd server
   # Add new routes in server.js
   # Test with scripts/test-*.js
   ```

### Database Changes
- Modify table structure in `server.js` initialization
- Create migration scripts in `server/scripts/`
- Test with sample data scripts

### Environment Configuration
- Frontend: Environment variables in `frontend/.env`
- Backend: Database and API keys in `server/.env`
- Use `npm run setup` for initial configuration

## 🎯 Benefits of New Structure

1. **Separation of Concerns**: Frontend and backend are clearly separated
2. **Easy Maintenance**: Each part can be developed and deployed independently
3. **Scalability**: Easy to add new features or split into microservices
4. **Developer Experience**: Clear scripts and helper tools
5. **Team Collaboration**: Different teams can work on frontend/backend separately

## 🔄 Migration Benefits

- **Before**: Mixed frontend/backend files in root directory
- **After**: Clean separation with dedicated folders
- **Improved**: Better organization, easier navigation, clearer dependencies
- **Enhanced**: Development scripts for common tasks
- **Added**: Helper tools and setup automation
