# AI Virtual Pharmacist - Developer Setup Guide

## Quick Setup (5 Minutes)

### Prerequisites
- Node.js 16+ and npm
- Git
- Code editor (VS Code recommended)

### 1. Clone and Install
```bash
# Clone repository
git clone <repository-url>
cd ai-virtual-pharmacist

# Install backend dependencies
cd server
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### 2. Environment Setup
Create `server/.env` file:
```env
# Database Configuration
DB_HOST=srv1148.hstgr.io
DB_USER=u530425252_cigna
DB_PASSWORD=Anirudh@k28
DB_NAME=u530425252_cigna

# JWT Secret
JWT_SECRET=ai-virtual-pharmacist-jwt-secret-2024

# Together AI Configuration (get free API key from together.ai)
TOGETHER_API_KEY=your_together_ai_api_key

# Server Configuration
PORT=5000
NODE_ENV=development

# Optional: Twilio for SMS reminders
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=+1234567890
```

### 3. Database Setup
```bash
cd server
node database.js          # Initialize database
node create-demo-user.js  # Create demo user
node add-test-data.js     # Add sample data
```

### 4. Start Development Servers
```bash
# Terminal 1: Backend
cd server
npm run dev

# Terminal 2: Frontend
cd frontend
npm run dev
```

### 5. Access Application
- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:5000
- **Demo Login**: demo@pharmacist.com / demo123

## Development Workflow

### Project Structure
```
project/
├── frontend/              # React + TypeScript
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── contexts/      # React contexts
│   │   └── services/      # API services
│   ├── package.json
│   └── vite.config.ts
├── server/                # Node.js + Express
│   ├── uploads/           # File storage
│   ├── database.js        # Database setup
│   ├── server.js          # Main server
│   ├── symptomChecker.js  # AI analysis
│   └── package.json
└── README.md
```

### Key Technologies
- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS
- **Backend**: Node.js, Express, SQLite, JWT
- **AI**: Together AI (Mixtral-8x7B-Instruct)
- **Database**: SQLite with custom helpers

### Development Commands
```bash
# Frontend
npm run dev        # Start dev server
npm run build      # Build for production
npm run preview    # Preview production build

# Backend
npm run dev        # Start with nodemon
npm start          # Start production server
```

## API Integration

### Together AI Setup
1. Sign up at https://together.ai
2. Get free API key
3. Add to `.env` file as `TOGETHER_API_KEY`
4. Test with symptom checker

### Database Schema
```sql
-- Users table
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  first_name TEXT,
  last_name TEXT,
  phone TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Symptom assessments table
CREATE TABLE symptom_assessments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  symptoms TEXT,
  symptom_duration TEXT,
  symptom_severity TEXT,
  risk_score INTEGER,
  urgency_level TEXT,
  ai_analysis TEXT,
  recommended_action TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users (id)
);
```

### API Endpoints
```javascript
// Authentication
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/profile

// Symptom Analysis
GET  /api/symptoms/list
POST /api/symptoms/analyze
GET  /api/symptoms/history

// Medications
GET    /api/medications
POST   /api/medications
PUT    /api/medications/:id
DELETE /api/medications/:id
```

## Testing

### Manual Testing
1. **Guest Mode**: Test symptom checker without login
2. **Authentication**: Test login/register flows
3. **Symptom Analysis**: Test with various symptoms
4. **History**: Test assessment history viewing
5. **Error Handling**: Test with invalid inputs

### Demo Data
- **Demo User**: demo@pharmacist.com / demo123
- **Sample Assessments**: 6 test assessments with different risk levels
- **Fallback Symptoms**: 10 common symptoms always available

### Testing Checklist
- [ ] User registration and login
- [ ] Guest mode symptom checker
- [ ] Authenticated symptom checker
- [ ] Assessment history viewing
- [ ] Error handling and fallbacks
- [ ] Mobile responsiveness
- [ ] API error scenarios

## Deployment

### Environment Variables
```env
# Production settings
NODE_ENV=production
PORT=5000
CORS_ORIGIN=https://yourdomain.com

# Database (production)
DB_HOST=your_production_db_host
DB_USER=your_production_db_user
DB_PASSWORD=your_production_db_password
DB_NAME=your_production_db_name

# Security
JWT_SECRET=your_secure_jwt_secret_here

# AI Service
TOGETHER_API_KEY=your_production_api_key
```

### Build Commands
```bash
# Frontend build
cd frontend
npm run build

# Backend (no build needed, runs directly)
cd server
npm start
```

### Docker Deployment
```dockerfile
# Dockerfile example
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

## Troubleshooting

### Common Issues

**Port Already in Use**
```bash
# Kill process on port 5000
npx kill-port 5000

# Or use different port
PORT=5001 npm run dev
```

**Database Connection Issues**
```bash
# Reinitialize database
cd server
rm database.db  # Remove existing database
node database.js  # Recreate
```

**Together AI API Errors**
- Check API key is valid
- Verify internet connection
- Check API rate limits
- Fallback analysis will work if API fails

**Frontend Build Issues**
```bash
# Clear node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Debug Mode
```bash
# Enable debug logging
DEBUG=* npm run dev

# Backend debug
NODE_ENV=development DEBUG=express:* npm run dev
```

## Contributing

### Code Style
- **Frontend**: ESLint + Prettier
- **Backend**: Standard JavaScript style
- **TypeScript**: Strict mode enabled
- **Commits**: Conventional commit format

### Pull Request Process
1. Fork the repository
2. Create feature branch: `git checkout -b feature/new-feature`
3. Make changes and test thoroughly
4. Commit with descriptive messages
5. Push and create pull request

### Development Guidelines
- Write TypeScript for new frontend code
- Add error handling for all API calls
- Include fallback UI for loading states
- Test on mobile devices
- Follow existing code patterns

## Resources

### Documentation
- **React**: https://react.dev
- **TypeScript**: https://typescriptlang.org
- **Vite**: https://vitejs.dev
- **Express**: https://expressjs.com
- **Together AI**: https://together.ai/docs

### Tools
- **VS Code Extensions**: ES7+ React snippets, TypeScript Hero
- **Browser DevTools**: React Developer Tools
- **API Testing**: Postman or Thunder Client
- **Database**: SQLite Browser

### Support
- **GitHub Issues**: Report bugs and feature requests
- **Discussions**: Community support and questions
- **Documentation**: Comprehensive guides and examples

---

**Happy coding! 🚀**
