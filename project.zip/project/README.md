# AI Virtual Pharmacist Assistant

A comprehensive healthcare application that provides AI-powered medication analysis, symptom checking, and personalized health recommendations with guest mode support.

## 🚀 Features

### Core Healthcare Features
- **🔍 AI Symptom Checker**: Advanced symptom analysis with Together AI integration
- **💊 Prescription Analysis**: Upload and analyze prescription images using AI
- **⚠️ Drug Interaction Checker**: Check for dangerous drug interactions
- **🔍 Pill Identifier**: Identify pills by visual characteristics
- **⏰ Medication Reminders**: Set and manage medication schedules
- **🤖 AI Chat Assistant**: Get health advice from an AI pharmacist
- **👥 Caregiver Mode**: Manage medications for family members
- **📱 Multi-language Support**: Available in multiple languages

### Advanced Symptom Analysis
- **Guest Mode Support**: Use symptom checker without registration
- **Risk Assessment**: AI-powered urgency level determination
- **Comprehensive Analysis**: Detailed health recommendations
- **Assessment History**: Track your health assessments over time
- **Fallback Analysis**: Works even when AI API is unavailable

### User Experience
- **Responsive Design**: Works on desktop, tablet, and mobile
- **Real-time Updates**: Live medication reminders and notifications
- **Secure Authentication**: JWT-based security with optional guest access
- **Professional UI**: Clean, medical-grade interface design

## 🛠 Tech Stack

### Frontend
- **React 18** + **TypeScript** + **Vite**
- **Tailwind CSS** for styling
- **React Router** for navigation
- **Lucide React** for icons
- **Context API** for state management

### Backend
- **Node.js** + **Express.js**
- **SQLite** database with custom helpers
- **JWT** authentication
- **Multer** for file uploads
- **Bcrypt** for password hashing
- **CORS** enabled

### AI Integration
- **Together AI** (Primary) - Mixtral-8x7B-Instruct model
- **Comprehensive Fallback** - Local analysis when AI unavailable
- **Medical-grade Prompts** - Specialized for healthcare analysis

### Additional Services
- **Twilio** (Optional) - SMS reminders
- **Node-cron** - Scheduled tasks
- **Axios** - HTTP client

## 📦 Installation & Setup

### Prerequisites
- Node.js 16+ and npm
- Git

### Quick Start

1. **Clone the repository:**
```bash
git clone <repository-url>
cd ai-virtual-pharmacist
```

2. **Install dependencies:**
```bash
# Backend dependencies
cd server
npm install

# Frontend dependencies
cd ../frontend
npm install
```

3. **Environment Configuration:**
Create `.env` file in the server directory:
```env
# Database Configuration
DB_HOST=srv1148.hstgr.io
DB_USER=u530425252_cigna
DB_PASSWORD=Anirudh@k28
DB_NAME=u530425252_cigna

# JWT Secret
JWT_SECRET=ai-virtual-pharmacist-jwt-secret-2024

# Together AI Configuration
TOGETHER_API_KEY=your_together_ai_api_key

# Twilio Configuration (optional)
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=+1234567890

# Server Configuration
PORT=5000
NODE_ENV=development

# File Upload Configuration
MAX_FILE_SIZE=10485760
UPLOAD_DIR=uploads

# CORS Configuration
CORS_ORIGIN=http://localhost:3000
```

4. **Database Setup:**
```bash
cd server
node database.js  # Initialize database
node create-demo-user.js  # Create demo user
node add-test-data.js  # Add sample data
```

5. **Start Development Servers:**
```bash
# Terminal 1: Backend server
cd server
npm run dev

# Terminal 2: Frontend server
cd frontend
npm run dev
```

6. **Access the Application:**
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000

## 🔐 Demo Credentials

**Demo User Account:**
- Email: `demo@pharmacist.com`
- Password: `demo123`

**Guest Mode:**
- No registration required for symptom checker
- Limited functionality (no history saving)

## 🏗️ Project Structure

```
project/
├── frontend/          # React + TypeScript frontend
│   ├── src/
│   │   ├── components/    # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── contexts/      # React contexts (Auth, Language, etc.)
│   │   └── services/      # API services
│   ├── package.json
│   └── vite.config.ts
├── server/            # Node.js + Express backend
│   ├── uploads/       # File upload storage
│   ├── database.js    # Database initialization
│   ├── server.js      # Main server file
│   ├── symptomChecker.js # AI symptom analysis
│   └── package.json
└── README.md
```

## 📚 API Documentation

### Authentication Endpoints
```
POST /api/auth/register     # Register new user
POST /api/auth/login        # User login
GET  /api/auth/profile      # Get user profile
PUT  /api/auth/profile      # Update user profile
```

### Symptom Analysis Endpoints
```
GET  /api/symptoms/list     # Get available symptoms
POST /api/symptoms/analyze  # Analyze symptoms (guest + auth)
GET  /api/symptoms/history  # Get assessment history (auth only)
```

### Medication Management
```
GET    /api/medications           # Get user medications
POST   /api/medications           # Add new medication
PUT    /api/medications/:id       # Update medication
DELETE /api/medications/:id       # Delete medication
POST   /api/drug-interactions/check # Check interactions
```

### Prescription & Analysis
```
POST /api/prescriptions/analyze   # Analyze prescription image
POST /api/pills/identify          # Identify pill by image
```

### Reminders & Notifications
```
GET  /api/reminders              # Get medication reminders
POST /api/reminders              # Create reminder
PUT  /api/reminders/:id          # Update reminder
DELETE /api/reminders/:id        # Delete reminder
```

## 🎯 Key Features Explained

### AI Symptom Checker
- **Guest Mode**: Works without login, shows guest banner
- **Authenticated Mode**: Full features with history saving
- **Fallback Analysis**: Comprehensive local analysis when AI unavailable
- **Risk Assessment**: Emergency, urgent, moderate, low classifications
- **Professional Disclaimers**: Medical-grade safety warnings

### Assessment History
- **Timeline View**: Chronological list of all assessments
- **Detailed Analysis**: Full AI analysis and recommendations
- **Risk Indicators**: Color-coded urgency levels
- **Export Options**: Download assessment reports

### Medication Management
- **Visual Recognition**: Upload pill images for identification
- **Interaction Checking**: Real-time drug interaction warnings
- **Reminder System**: Customizable medication schedules
- **Caregiver Support**: Manage medications for family members

## 🚀 Development

### Available Scripts
```bash
# Root level
npm run dev              # Start both frontend and backend
npm run install:all      # Install all dependencies

# Frontend (in frontend/)
npm run dev              # Start Vite dev server
npm run build            # Build for production
npm run preview          # Preview production build

# Backend (in server/)
npm run dev              # Start with nodemon
npm start                # Start production server
```

### Adding New Features
1. **Frontend**: Add components in `frontend/src/components/`
2. **Backend**: Add routes in `server/server.js`
3. **Database**: Update schema in `server/database.js`

## 📱 Usage Guide

### For Patients
1. **Register/Login** or use **Guest Mode**
2. **Symptom Checker**: Analyze symptoms and get AI recommendations
3. **Medication Management**: Track pills, set reminders
4. **History**: Review past assessments and medications

### For Caregivers
1. **Caregiver Mode**: Manage medications for family members
2. **Shared Access**: Monitor medication adherence
3. **Emergency Contacts**: Quick access to healthcare providers

## 🔒 Security & Privacy

- **JWT Authentication**: Secure token-based authentication
- **Data Encryption**: Sensitive data encrypted at rest
- **HIPAA Considerations**: Healthcare data handling best practices
- **Guest Mode**: No data persistence for privacy-conscious users

## 🌐 Deployment

### Production Setup
1. **Environment**: Set `NODE_ENV=production`
2. **Database**: Configure production database
3. **SSL**: Enable HTTPS for secure communication
4. **Monitoring**: Set up logging and error tracking

### Docker Deployment
```bash
# Build and run with Docker
docker-compose up --build
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/new-feature`
3. Commit changes: `git commit -m 'Add new feature'`
4. Push to branch: `git push origin feature/new-feature`
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Check the documentation
- Review the user manual

---

**⚠️ Medical Disclaimer**: This application is for informational purposes only and does not replace professional medical advice. Always consult with healthcare providers for medical decisions.
