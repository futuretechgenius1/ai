const bcrypt = require('bcryptjs');
const { dbHelpers } = require('./database');

async function createDemoUser() {
  try {
    // Check if demo user already exists
    const existingUser = await dbHelpers.get('SELECT id FROM users WHERE email = ?', ['demo@pharmacist.com']);
    
    if (existingUser) {
      console.log('Demo user already exists with ID:', existingUser.id);
      return existingUser.id;
    }

    // Create demo user
    const hashedPassword = await bcrypt.hash('demo123', 10);
    
    const result = await dbHelpers.run(
      `INSERT INTO users (email, password, first_name, last_name, phone, created_at) 
       VALUES (?, ?, ?, ?, ?, datetime('now'))`,
      ['demo@pharmacist.com', hashedPassword, 'Demo', 'User', '+1234567890']
    );

    console.log('Created demo user with ID:', result.lastID);
    return result.lastID;
    
  } catch (error) {
    console.error('Error creating demo user:', error);
    throw error;
  }
}

// Run the script
createDemoUser().then((userId) => {
  console.log('Demo user setup completed. User ID:', userId);
  process.exit(0);
}).catch(error => {
  console.error('Script failed:', error);
  process.exit(1);
});
