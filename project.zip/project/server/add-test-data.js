const { dbHelpers } = require('./database');

async function addTestSymptomData() {
  try {
    // Get the demo user ID
    const user = await dbHelpers.get('SELECT id FROM users WHERE email = ?', ['demo@pharmacist.com']);
    
    if (!user) {
      console.log('Demo user not found. Please create demo user first.');
      return;
    }

    console.log('Found demo user with ID:', user.id);

    // Add test symptom assessments
    const testAssessments = [
      {
        symptoms: ['headache', 'fever', 'fatigue'],
        duration: ['2-3-days', '1-2-days', '2-3-days'],
        severity: ['moderate', 'mild', 'moderate'],
        risk_score: 65,
        urgency_level: 'moderate',
        ai_analysis: 'Based on the reported symptoms of headache, fever, and fatigue lasting 2-3 days, this appears to be consistent with a viral upper respiratory infection or flu-like illness. The moderate severity and duration suggest monitoring is appropriate.',
        recommended_action: 'Monitor symptoms, rest, stay hydrated, and consider over-the-counter fever reducers if needed.',
        follow_up_needed: false
      },
      {
        symptoms: ['chest pain', 'shortness of breath'],
        duration: ['less-than-1-day', 'less-than-1-day'],
        severity: ['high', 'moderate'],
        risk_score: 85,
        urgency_level: 'urgent',
        ai_analysis: 'Chest pain combined with shortness of breath requires immediate medical evaluation to rule out serious cardiac or pulmonary conditions. These symptoms warrant urgent medical attention.',
        recommended_action: 'Seek immediate medical attention. Consider emergency room visit or urgent care.',
        follow_up_needed: true
      },
      {
        symptoms: ['nausea', 'abdominal pain'],
        duration: ['1-2-days', '1-2-days'],
        severity: ['mild', 'moderate'],
        risk_score: 45,
        urgency_level: 'low',
        ai_analysis: 'Mild nausea and moderate abdominal pain for 1-2 days may indicate gastroenteritis or dietary indiscretion. Symptoms are generally manageable with conservative care.',
        recommended_action: 'Rest, clear fluids, bland diet. Monitor for worsening symptoms.',
        follow_up_needed: false
      }
    ];

    for (const assessment of testAssessments) {
      await dbHelpers.run(
        `INSERT INTO symptom_assessments (
          user_id, symptoms, symptom_duration, symptom_severity,
          risk_score, urgency_level, ai_analysis, recommended_action,
          medication_recommendations, provider_recommendations, telemedicine_options,
          follow_up_needed, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now', '-' || ? || ' hours'))`,
        [
          user.id,
          JSON.stringify(assessment.symptoms),
          JSON.stringify(assessment.duration),
          JSON.stringify(assessment.severity),
          assessment.risk_score,
          assessment.urgency_level,
          assessment.ai_analysis,
          assessment.recommended_action,
          JSON.stringify([]),
          JSON.stringify([]),
          JSON.stringify([]),
          assessment.follow_up_needed,
          Math.floor(Math.random() * 72) // Random hours in the past 3 days
        ]
      );
    }

    console.log('Successfully added test symptom assessment data!');
    
    // Verify the data was added
    const count = await dbHelpers.get(
      'SELECT COUNT(*) as count FROM symptom_assessments WHERE user_id = ?',
      [user.id]
    );
    
    console.log(`Total assessments for demo user: ${count.count}`);
    
  } catch (error) {
    console.error('Error adding test data:', error);
  }
}

// Run the script
addTestSymptomData().then(() => {
  console.log('Test data script completed');
  process.exit(0);
}).catch(error => {
  console.error('Script failed:', error);
  process.exit(1);
});
