const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');

// Create database connection
const dbPath = path.join(__dirname, 'pharmacist.db');
const db = new sqlite3.Database(dbPath);

// Enable foreign keys
db.run('PRAGMA foreign_keys = ON');

// Initialize database with tables and sample data
async function initializeDatabase() {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // Users table
      db.run(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) UNIQUE NOT NULL,
          password VARCHAR(255) NOT NULL,
          phone VARCHAR(20),
          language VARCHAR(10) DEFAULT 'en',
          profile_photo TEXT,
          notifications_enabled BOOLEAN DEFAULT TRUE,
          privacy_settings TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // Medications table
      db.run(`
        CREATE TABLE IF NOT EXISTS medications (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          name VARCHAR(255) NOT NULL,
          generic_name VARCHAR(255),
          dosage VARCHAR(100),
          frequency VARCHAR(100),
          instructions TEXT,
          start_date DATE,
          end_date DATE,
          prescriber VARCHAR(255),
          pharmacy VARCHAR(255),
          refills_remaining INTEGER DEFAULT 0,
          active BOOLEAN DEFAULT TRUE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
      `);

      // Reminders table
      db.run(`
        CREATE TABLE IF NOT EXISTS reminders (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          medication_id INTEGER NOT NULL,
          reminder_time TIME NOT NULL,
          days_of_week VARCHAR(20) DEFAULT '1,2,3,4,5,6,7',
          active BOOLEAN DEFAULT TRUE,
          sms_enabled BOOLEAN DEFAULT FALSE,
          last_sent DATETIME NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (medication_id) REFERENCES medications(id) ON DELETE CASCADE
        )
      `);

      // Medication history table
      db.run(`
        CREATE TABLE IF NOT EXISTS medication_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          medication_id INTEGER NOT NULL,
          action VARCHAR(50) NOT NULL,
          taken_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          notes TEXT,
          side_effects TEXT,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (medication_id) REFERENCES medications(id) ON DELETE CASCADE
        )
      `);

      // Prescriptions table
      db.run(`
        CREATE TABLE IF NOT EXISTS prescriptions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          file_path VARCHAR(500),
          original_text TEXT,
          analyzed_data TEXT,
          analysis_date DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
      `);

      // Caregivers table
      db.run(`
        CREATE TABLE IF NOT EXISTS caregivers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          patient_id INTEGER NOT NULL,
          caregiver_id INTEGER NOT NULL,
          relationship VARCHAR(100),
          permissions TEXT,
          active BOOLEAN DEFAULT TRUE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
          FOREIGN KEY (caregiver_id) REFERENCES users(id) ON DELETE CASCADE
        )
      `);

      // Symptom assessments table
      db.run(`
        CREATE TABLE IF NOT EXISTS symptom_assessments (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          symptoms TEXT NOT NULL,
          symptom_duration TEXT,
          symptom_severity TEXT,
          risk_score INTEGER,
          urgency_level VARCHAR(20),
          ai_analysis TEXT,
          recommended_action TEXT,
          medication_recommendations TEXT,
          provider_recommendations TEXT,
          telemedicine_options TEXT,
          follow_up_needed BOOLEAN DEFAULT FALSE,
          follow_up_date DATETIME,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
      `);

      // Add sample data
      addSampleData(() => {
        console.log('SQLite database initialized successfully');
        resolve();
      });
    });
  });
}

// Add sample data for demo
function addSampleData(callback) {
  // Check if demo user exists
  db.get('SELECT id FROM users WHERE email = ?', ['demo@pharmacist.com'], async (err, user) => {
    if (err) {
      console.error('Error checking demo user:', err);
      return callback();
    }

    if (!user) {
      // Create demo user
      const hashedPassword = await bcrypt.hash('demo123', 10);
      db.run(
        'INSERT INTO users (name, email, password, phone, language) VALUES (?, ?, ?, ?, ?)',
        ['Demo User', 'demo@pharmacist.com', hashedPassword, '+1234567890', 'en'],
        function(err) {
          if (err) {
            console.error('Error creating demo user:', err);
            return callback();
          }
          
          const userId = this.lastID;
          addSampleMedications(userId, callback);
        }
      );
    } else {
      addSampleMedications(user.id, callback);
    }
  });
}

function addSampleMedications(userId, callback) {
  // Check if medications already exist
  db.get('SELECT COUNT(*) as count FROM medications WHERE user_id = ?', [userId], (err, result) => {
    if (err || result.count > 0) {
      return callback();
    }

    const medications = [
      {
        name: 'Paracetamol',
        generic_name: 'Acetaminophen',
        dosage: '500mg',
        frequency: 'Twice daily',
        instructions: 'Take with food to reduce stomach irritation',
        prescriber: 'Dr. Smith',
        pharmacy: 'City Pharmacy',
        refills_remaining: 2
      },
      {
        name: 'Ibuprofen',
        generic_name: 'Ibuprofen',
        dosage: '400mg',
        frequency: 'Three times daily',
        instructions: 'Take after meals',
        prescriber: 'Dr. Johnson',
        pharmacy: 'Health Plus Pharmacy',
        refills_remaining: 1
      },
      {
        name: 'Vitamin D3',
        generic_name: 'Cholecalciferol',
        dosage: '1000 IU',
        frequency: 'Once daily',
        instructions: 'Take with breakfast',
        prescriber: 'Dr. Wilson',
        pharmacy: 'Wellness Pharmacy',
        refills_remaining: 3
      },
      {
        name: 'Aspirin',
        generic_name: 'Acetylsalicylic acid',
        dosage: '81mg',
        frequency: 'Once daily',
        instructions: 'Take with food, low-dose for heart health',
        prescriber: 'Dr. Brown',
        pharmacy: 'Care Pharmacy',
        refills_remaining: 5
      }
    ];

    let completed = 0;
    medications.forEach((med, index) => {
      db.run(
        `INSERT INTO medications (user_id, name, generic_name, dosage, frequency, instructions, prescriber, pharmacy, refills_remaining, start_date, end_date) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, date('now'), date('now', '+30 days'))`,
        [userId, med.name, med.generic_name, med.dosage, med.frequency, med.instructions, med.prescriber, med.pharmacy, med.refills_remaining],
        function(err) {
          if (err) {
            console.error('Error adding medication:', err);
          } else {
            // Add reminders for this medication
            addSampleReminders(userId, this.lastID);
          }
          
          completed++;
          if (completed === medications.length) {
            console.log('Sample medications and reminders added');
            callback();
          }
        }
      );
    });
  });
}

function addSampleReminders(userId, medicationId) {
  const reminders = [
    { time: '08:00', medication_id: medicationId },
    { time: '14:00', medication_id: medicationId },
    { time: '20:00', medication_id: medicationId }
  ];

  reminders.forEach(reminder => {
    db.run(
      'INSERT INTO reminders (user_id, medication_id, reminder_time, active, sms_enabled) VALUES (?, ?, ?, ?, ?)',
      [userId, reminder.medication_id, reminder.time, true, false]
    );
  });
}

// Database query helpers
const dbHelpers = {
  // Execute query with parameters
  run: (sql, params = []) => {
    return new Promise((resolve, reject) => {
      db.run(sql, params, function(err) {
        if (err) reject(err);
        else resolve({ lastID: this.lastID, changes: this.changes });
      });
    });
  },

  // Get single row
  get: (sql, params = []) => {
    return new Promise((resolve, reject) => {
      db.get(sql, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  },

  // Get all rows
  all: (sql, params = []) => {
    return new Promise((resolve, reject) => {
      db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }
};

module.exports = {
  db,
  initializeDatabase,
  dbHelpers
};
