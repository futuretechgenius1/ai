const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cron = require('node-cron');
const twilio = require('twilio');
const { db, initializeDatabase, dbHelpers } = require('./database');
const {
  assessRisk,
  getMedicationRecommendations,
  analyzeSymptoms,
  findNearbyProviders,
  getTelemedicineOptions,
  SYMPTOM_DATABASE
} = require('./symptomChecker');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use('/uploads', express.static('uploads'));

// Create uploads directory if it doesn't exist
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only images (JPEG, JPG, PNG) and PDF files are allowed'));
    }
  }
});

// Initialize SQLite database
initializeDatabase().catch(console.error);

// Twilio configuration (optional)
let twilioClient = null;
if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN &&
    process.env.TWILIO_ACCOUNT_SID.startsWith('AC')) {
  try {
    twilioClient = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN
    );
    console.log('Twilio SMS service initialized');
  } catch (error) {
    console.warn('Twilio initialization failed:', error.message);
  }
} else {
  console.log('Twilio SMS service not configured (optional)');
}

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Database initialization is handled by database.js





// Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'AI Virtual Pharmacist Assistant API is running' });
});

// Dashboard Statistics
app.get('/api/dashboard/stats', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;

    // Get total prescriptions count (using existing prescriptions table)
    const prescriptionsCount = await dbHelpers.get(
      'SELECT COUNT(*) as count FROM prescriptions WHERE user_id = ?',
      [userId]
    );

    // Get active reminders count (using correct column name 'active')
    const remindersCount = await dbHelpers.get(
      'SELECT COUNT(*) as count FROM reminders WHERE user_id = ? AND active = 1',
      [userId]
    );

    // Get medication history count (drugs checked)
    const historyCount = await dbHelpers.get(
      'SELECT COUNT(DISTINCT medication_id) as count FROM medication_history WHERE user_id = ?',
      [userId]
    );

    // Get total medications count (active medications)
    const medicationsCount = await dbHelpers.get(
      'SELECT COUNT(*) as count FROM medications WHERE user_id = ? AND active = 1',
      [userId]
    );

    // Get recent medication actions count (last 7 days)
    const recentActionsCount = await dbHelpers.get(
      'SELECT COUNT(*) as count FROM medication_history WHERE user_id = ? AND taken_at >= datetime("now", "-7 days")',
      [userId]
    );

    res.json({
      totalPrescriptions: prescriptionsCount?.count || 0,
      activeReminders: remindersCount?.count || 0,
      drugsChecked: historyCount?.count || 0,
      activeMedications: medicationsCount?.count || 0,
      recentActions: recentActionsCount?.count || 0
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Dashboard Recent Activity
app.get('/api/dashboard/activity', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;

    // Get recent medication history as activity
    const activities = await dbHelpers.all(
      `SELECT
        mh.id,
        mh.action as type,
        m.name as title,
        COALESCE(mh.notes, 'Medication ' || mh.action) as description,
        mh.taken_at as timestamp,
        CASE
          WHEN mh.action = 'taken' THEN 'completed'
          WHEN mh.action = 'missed' THEN 'overdue'
          WHEN mh.action = 'consultation' THEN 'in-progress'
          ELSE 'pending'
        END as status
       FROM medication_history mh
       LEFT JOIN medications m ON mh.medication_id = m.id
       WHERE mh.user_id = ?
       ORDER BY mh.taken_at DESC
       LIMIT 10`,
      [userId]
    );

    // Get recent reminders as activity (simplified to avoid schema issues)
    const reminders = await dbHelpers.all(
      `SELECT
        r.id,
        'reminder' as type,
        'Reminder: ' || m.name as title,
        'Take ' || m.dosage || ' at ' || substr(r.reminder_time, 1, 5) as description,
        date('now') || ' ' || r.reminder_time as timestamp,
        CASE
          WHEN r.active = 1 THEN 'pending'
          ELSE 'completed'
        END as status
       FROM reminders r
       LEFT JOIN medications m ON r.medication_id = m.id
       WHERE r.user_id = ?
       ORDER BY r.reminder_time DESC
       LIMIT 5`,
      [userId]
    );

    // Combine and sort activities
    const allActivities = [...activities, ...reminders]
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);

    res.json(allActivities);
  } catch (error) {
    console.error('Error fetching dashboard activity:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update User Profile
app.put('/api/user/profile', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;
    const { name, phone, language, profilePhoto, notifications, privacy } = req.body;

    // Update user profile in database
    await dbHelpers.run(
      `UPDATE users SET
        name = ?,
        phone = ?,
        language = ?,
        profile_photo = ?
       WHERE id = ?`,
      [
        name,
        phone || null,
        language || 'en',
        profilePhoto || null,
        userId
      ]
    );

    // Update user preferences (you might want to create a separate table for this)
    // For now, we'll just return success

    res.json({
      message: 'Profile updated successfully',
      user: {
        name,
        phone,
        language,
        profilePhoto
      }
    });
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Profile Photo Upload
app.post('/api/user/profile-photo', authenticateToken, upload.single('profilePhoto'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No photo uploaded' });
    }

    const userId = req.user.userId;
    const photoPath = req.file.path;

    // Update user's profile photo in database
    await dbHelpers.run(
      'UPDATE users SET profile_photo = ? WHERE id = ?',
      [photoPath, userId]
    );

    res.json({
      message: 'Profile photo uploaded successfully',
      photoPath: photoPath
    });
  } catch (error) {
    console.error('Error uploading profile photo:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get User Profile
app.get('/api/user/profile', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;

    const user = await dbHelpers.get(
      'SELECT id, name, email, phone, language, profile_photo, notifications_enabled, privacy_settings FROM users WHERE id = ?',
      [userId]
    );

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      language: user.language,
      profilePhoto: user.profile_photo,
      notificationsEnabled: user.notifications_enabled,
      privacySettings: user.privacy_settings ? JSON.parse(user.privacy_settings) : {}
    });
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// User Authentication Routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { email, password, firstName, lastName } = req.body;

    // Validate required fields
    if (!email || !password || !firstName || !lastName) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    // Check if user already exists
    const existingUser = await dbHelpers.get(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if (existingUser) {
      return res.status(400).json({ error: 'User already exists with this email' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert new user
    const result = await dbHelpers.run(
      `INSERT INTO users (email, password, name, phone, language)
       VALUES (?, ?, ?, ?, ?)`,
      [email, hashedPassword, `${firstName} ${lastName}`, '', 'en']
    );

    // Generate JWT token
    const token = jwt.sign(
      { userId: result.lastID, email: email },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      message: 'User registered successfully',
      token: token,
      user: {
        id: result.lastID,
        email: email,
        firstName: firstName,
        lastName: lastName,
        preferredLanguage: 'en'
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = await dbHelpers.get(
      'SELECT id, email, password, name FROM users WHERE email = ?',
      [email]
    );

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    
    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({
      message: 'Login successful',
      token: token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        preferredLanguage: 'en' // Default language
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Medication Routes
app.get('/api/medications', authenticateToken, async (req, res) => {
  try {
    const medications = await dbHelpers.all(
      'SELECT * FROM medications WHERE user_id = ? AND active = 1 ORDER BY created_at DESC',
      [req.user.userId]
    );
    res.json(medications);
  } catch (error) {
    console.error('Error fetching medications:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/medications', authenticateToken, async (req, res) => {
  try {
    const { medication_name, dosage, frequency, instructions, prescriber_name, prescriber_contact, duration_days, refills_remaining } = req.body;

    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format

    const result = await dbHelpers.run(
      `INSERT INTO medications (user_id, name, dosage, frequency, instructions, prescriber, start_date, end_date, refills_remaining, active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.user.userId, medication_name, dosage, frequency, instructions, prescriber_name, today, new Date(Date.now() + 30*24*60*60*1000).toISOString().split('T')[0], refills_remaining || 0, 1]
    );

    res.status(201).json({
      message: 'Medication added successfully',
      medicationId: result.lastID
    });
  } catch (error) {
    console.error('Error adding medication:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/medications/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, genericName, dosage, frequency, instructions, startDate, endDate, prescriber, pharmacy, refillsRemaining, active } = req.body;

    await dbHelpers.run(
      `UPDATE medications SET name = ?, generic_name = ?, dosage = ?, frequency = ?, instructions = ?,
       start_date = ?, end_date = ?, prescriber = ?, pharmacy = ?, refills_remaining = ?, active = ?
       WHERE id = ? AND user_id = ?`,
      [name, genericName, dosage, frequency, instructions, startDate, endDate, prescriber, pharmacy, refillsRemaining, active ? 1 : 0, id, req.user.userId]
    );

    res.json({ message: 'Medication updated successfully' });
  } catch (error) {
    console.error('Error updating medication:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/api/medications/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    await dbHelpers.run(
      'UPDATE medications SET active = 0 WHERE id = ? AND user_id = ?',
      [id, req.user.userId]
    );

    res.json({ message: 'Medication deactivated successfully' });
  } catch (error) {
    console.error('Error deactivating medication:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Reminder Routes
app.get('/api/reminders', authenticateToken, async (req, res) => {
  try {
    const reminders = await dbHelpers.all(
      `SELECT r.*, m.name as medication_name, m.dosage
       FROM reminders r
       JOIN medications m ON r.medication_id = m.id
       WHERE r.user_id = ?
       ORDER BY r.reminder_time`,
      [req.user.userId]
    );
    res.json(reminders);
  } catch (error) {
    console.error('Error fetching reminders:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/reminders', authenticateToken, async (req, res) => {
  try {
    const { prescriptionId, reminderType, scheduledTime, message } = req.body;

    const result = await dbHelpers.run(
      'INSERT INTO reminders (user_id, medication_id, reminder_time, active, sms_enabled) VALUES (?, ?, ?, ?, ?)',
      [req.user.userId, prescriptionId, scheduledTime, 1, 0]
    );

    res.status(201).json({
      message: 'Reminder created successfully',
      reminderId: result.lastID
    });
  } catch (error) {
    console.error('Error creating reminder:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.put('/api/reminders/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { scheduledTime, message, reminderType } = req.body;

    await dbHelpers.run(
      'UPDATE reminders SET reminder_time = ? WHERE id = ? AND user_id = ?',
      [scheduledTime, id, req.user.userId]
    );

    res.json({ message: 'Reminder updated successfully' });
  } catch (error) {
    console.error('Error updating reminder:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.delete('/api/reminders/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    await dbHelpers.run(
      'DELETE FROM reminders WHERE id = ? AND user_id = ?',
      [id, req.user.userId]
    );

    res.json({ message: 'Reminder deleted successfully' });
  } catch (error) {
    console.error('Error deleting reminder:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Prescription Analysis Routes
app.post('/api/prescriptions/upload', authenticateToken, upload.single('prescription'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const result = await dbHelpers.run(
      'INSERT INTO prescriptions (user_id, file_path) VALUES (?, ?)',
      [req.user.userId, req.file.path]
    );

    res.json({
      message: 'Prescription uploaded successfully',
      prescriptionId: result.lastID,
      filePath: req.file.path
    });
  } catch (error) {
    console.error('Error uploading prescription:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/prescriptions/:id/analyze', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { originalText, analyzedData } = req.body;

    await dbHelpers.run(
      'UPDATE prescriptions SET original_text = ?, analyzed_data = ? WHERE id = ? AND user_id = ?',
      [originalText, JSON.stringify(analyzedData), id, req.user.userId]
    );

    res.json({ message: 'Prescription analysis saved successfully' });
  } catch (error) {
    console.error('Error saving prescription analysis:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Medication History Routes
app.get('/api/medication-history', authenticateToken, async (req, res) => {
  try {
    const history = await dbHelpers.all(
      `SELECT mh.*, m.name as medication_name
       FROM medication_history mh
       JOIN medications m ON mh.medication_id = m.id
       WHERE mh.user_id = ?
       ORDER BY mh.taken_at DESC
       LIMIT 100`,
      [req.user.userId]
    );
    res.json(history);
  } catch (error) {
    console.error('Error fetching medication history:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/medication-history', authenticateToken, async (req, res) => {
  try {
    const { medicationId, action, notes, sideEffects } = req.body;

    // Convert undefined to null for database
    const notesValue = notes || null;
    const sideEffectsValue = sideEffects || null;

    const result = await dbHelpers.run(
      'INSERT INTO medication_history (user_id, medication_id, action, notes, side_effects) VALUES (?, ?, ?, ?, ?)',
      [req.user.userId, medicationId, action, notesValue, sideEffectsValue]
    );

    res.status(201).json({
      message: 'Medication history recorded successfully',
      historyId: result.lastID
    });
  } catch (error) {
    console.error('Error recording medication history:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// SMS Reminder Functions
async function sendSMSReminder(phoneNumber, medicationName, dosage, time) {
  try {
    if (!twilioClient) {
      console.log('Twilio not configured, skipping SMS reminder');
      return;
    }

    const message = `🏥 Medication Reminder: It's time to take your ${medicationName} (${dosage}). Take care! Reply STOP to opt out.`;

    await twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: phoneNumber
    });

    console.log(`SMS reminder sent to ${phoneNumber} for ${medicationName}`);
  } catch (error) {
    console.error('Error sending SMS reminder:', error);
  }
}

// Cron job for checking reminders (runs every minute) - DISABLED due to schema mismatch
/*
cron.schedule('* * * * *', async () => {
  try {
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
    const currentDay = now.getDay() || 7; // Convert Sunday (0) to 7

    // Cron job disabled - would need to be updated for SQLite
    console.log('Reminder cron job disabled');
  } catch (error) {
    console.error('Error in reminder cron job:', error);
  }
});
*/

// Caregiver Routes
app.get('/api/caregivers', authenticateToken, async (req, res) => {
  try {
    const caregivers = await dbHelpers.all(
      `SELECT c.*, u.name, u.email
       FROM caregivers c
       JOIN users u ON c.caregiver_id = u.id
       WHERE c.patient_id = ? AND c.active = 1`,
      [req.user.userId]
    );
    res.json(caregivers);
  } catch (error) {
    console.error('Error fetching caregivers:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/patients', authenticateToken, async (req, res) => {
  try {
    const patients = await dbHelpers.all(
      `SELECT c.*, u.name, u.email
       FROM caregivers c
       JOIN users u ON c.patient_id = u.id
       WHERE c.caregiver_id = ? AND c.active = 1`,
      [req.user.userId]
    );
    res.json(patients);
  } catch (error) {
    console.error('Error fetching patients:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/caregivers', authenticateToken, async (req, res) => {
  try {
    const { caregiverEmail, relationship, permissions } = req.body;

    // Find caregiver by email
    const caregiver = await dbHelpers.get(
      'SELECT id FROM users WHERE email = ?',
      [caregiverEmail]
    );

    if (!caregiver) {
      return res.status(404).json({ error: 'Caregiver not found with this email' });
    }

    const caregiverId = caregiver.id;

    // Check if relationship already exists
    const existing = await dbHelpers.get(
      'SELECT id FROM caregivers WHERE patient_id = ? AND caregiver_id = ?',
      [req.user.userId, caregiverId]
    );

    if (existing) {
      return res.status(400).json({ error: 'Caregiver relationship already exists' });
    }

    const result = await dbHelpers.run(
      'INSERT INTO caregivers (patient_id, caregiver_id, relationship, permissions) VALUES (?, ?, ?, ?)',
      [req.user.userId, caregiverId, relationship, JSON.stringify(permissions)]
    );

    res.status(201).json({
      message: 'Caregiver added successfully',
      caregiverId: result.lastID
    });
  } catch (error) {
    console.error('Error adding caregiver:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Translation API endpoint
app.post('/api/translate', authenticateToken, async (req, res) => {
  try {
    const { text, targetLanguage } = req.body;

    // This would integrate with Together AI for translation
    // For now, return the original text as placeholder
    res.json({
      originalText: text,
      translatedText: text, // Placeholder - implement actual translation
      targetLanguage: targetLanguage
    });
  } catch (error) {
    console.error('Error translating text:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// AI Symptom Checker Routes

// Get available symptoms for autocomplete
app.get('/api/symptoms/list', (req, res) => {
  try {
    const symptoms = Object.keys(SYMPTOM_DATABASE).map(symptom => ({
      name: symptom,
      category: SYMPTOM_DATABASE[symptom].category,
      severity: SYMPTOM_DATABASE[symptom].severity
    }));

    res.json(symptoms);
  } catch (error) {
    console.error('Error fetching symptoms list:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Analyze symptoms and provide assessment
app.post('/api/symptoms/analyze', async (req, res) => {
  try {
    // Check if user is authenticated (optional for demo)
    let userId = null;
    let user = null;

    // Try to get user from token if provided
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (token) {
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        userId = decoded.userId;
        user = await dbHelpers.get('SELECT * FROM users WHERE id = ?', [userId]);
      } catch (error) {
        // Token invalid, continue without user
        console.log('Invalid token, continuing without authentication');
      }
    }

    const {
      symptoms,
      duration,
      severity,
      patientInfo,
      location
    } = req.body;

    if (!symptoms || symptoms.length === 0) {
      return res.status(400).json({ error: 'Symptoms are required' });
    }

    // Prepare patient info
    const patientData = {
      age: patientInfo?.age || 30,
      gender: patientInfo?.gender || 'not specified',
      conditions: patientInfo?.conditions || [],
      medications: patientInfo?.medications || []
    };

    // Perform risk assessment
    const riskAssessment = assessRisk(symptoms, patientData.age, patientData.conditions);

    // Get medication recommendations
    const medicationRecommendations = getMedicationRecommendations(symptoms);

    // Get AI analysis
    const aiAnalysis = await analyzeSymptoms(symptoms, duration, severity, patientData);

    // Find nearby providers
    const nearbyProviders = findNearbyProviders(location, riskAssessment.urgencyLevel);

    // Get telemedicine options
    const telemedicineOptions = getTelemedicineOptions(riskAssessment.urgencyLevel);

    // Save assessment to database (only if user is authenticated)
    let assessmentResult = null;
    if (userId) {
      assessmentResult = await dbHelpers.run(
        `INSERT INTO symptom_assessments (
          user_id, symptoms, symptom_duration, symptom_severity,
          risk_score, urgency_level, ai_analysis, recommended_action,
          medication_recommendations, provider_recommendations, telemedicine_options,
          follow_up_needed
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userId,
          JSON.stringify(symptoms),
          JSON.stringify(duration),
          JSON.stringify(severity),
          riskAssessment.riskScore,
          riskAssessment.urgencyLevel,
          aiAnalysis,
          riskAssessment.action,
          JSON.stringify(medicationRecommendations),
          JSON.stringify(nearbyProviders),
          JSON.stringify(telemedicineOptions),
          riskAssessment.urgencyLevel === 'emergency' || riskAssessment.urgencyLevel === 'urgent'
        ]
      );
    }

    // Prepare response
    const response = {
      assessmentId: assessmentResult?.lastID || null,
      riskAssessment,
      aiAnalysis,
      medicationRecommendations,
      nearbyProviders,
      telemedicineOptions,
      disclaimer: 'This assessment is for informational purposes only and does not replace professional medical advice. Please consult with a healthcare provider for proper diagnosis and treatment.',
      guestMode: !userId
    };

    res.json(response);
  } catch (error) {
    console.error('Error analyzing symptoms:', error);
    console.error('Error stack:', error.stack);
    res.status(500).json({
      error: 'Internal server error',
      message: error.message,
      details: 'Failed to analyze symptoms. Please try again.'
    });
  }
});

// Get symptom assessment history
app.get('/api/symptoms/history', async (req, res) => {
  try {
    // Check if user is authenticated (optional for demo)
    let userId = null;

    // Try to get user from token if provided
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (token) {
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        userId = decoded.userId;
      } catch (error) {
        // Token invalid, return empty history for guest users
        console.log('Invalid token for history request, returning empty history');
        return res.json([]);
      }
    } else {
      // No token provided, return empty history for guest users
      return res.json([]);
    }

    if (!userId) {
      return res.json([]);
    }

    const assessments = await dbHelpers.all(
      `SELECT * FROM symptom_assessments
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT 20`,
      [userId]
    );

    // Parse JSON fields
    const formattedAssessments = assessments.map(assessment => ({
      ...assessment,
      symptoms: JSON.parse(assessment.symptoms),
      symptom_duration: JSON.parse(assessment.symptom_duration || '[]'),
      symptom_severity: JSON.parse(assessment.symptom_severity || '[]'),
      medication_recommendations: JSON.parse(assessment.medication_recommendations || '[]'),
      provider_recommendations: JSON.parse(assessment.provider_recommendations || '[]'),
      telemedicine_options: JSON.parse(assessment.telemedicine_options || '[]')
    }));

    res.json(formattedAssessments);
  } catch (error) {
    console.error('Error fetching symptom history:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get specific symptom assessment
app.get('/api/symptoms/assessment/:id', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;
    const assessmentId = req.params.id;

    const assessment = await dbHelpers.get(
      'SELECT * FROM symptom_assessments WHERE id = ? AND user_id = ?',
      [assessmentId, userId]
    );

    if (!assessment) {
      return res.status(404).json({ error: 'Assessment not found' });
    }

    // Parse JSON fields
    const formattedAssessment = {
      ...assessment,
      symptoms: JSON.parse(assessment.symptoms),
      symptom_duration: JSON.parse(assessment.symptom_duration || '[]'),
      symptom_severity: JSON.parse(assessment.symptom_severity || '[]'),
      medication_recommendations: JSON.parse(assessment.medication_recommendations || '[]'),
      provider_recommendations: JSON.parse(assessment.provider_recommendations || '[]'),
      telemedicine_options: JSON.parse(assessment.telemedicine_options || '[]')
    };

    res.json(formattedAssessment);
  } catch (error) {
    console.error('Error fetching symptom assessment:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update follow-up status
app.put('/api/symptoms/assessment/:id/follow-up', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;
    const assessmentId = req.params.id;
    const { followUpCompleted, followUpNotes } = req.body;

    await dbHelpers.run(
      `UPDATE symptom_assessments
       SET follow_up_needed = ?, follow_up_date = CURRENT_TIMESTAMP
       WHERE id = ? AND user_id = ?`,
      [!followUpCompleted, assessmentId, userId]
    );

    res.json({ message: 'Follow-up status updated successfully' });
  } catch (error) {
    console.error('Error updating follow-up status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
