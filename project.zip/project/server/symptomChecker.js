const axios = require('axios');

// Symptom categories and their associated conditions
const SYMPTOM_DATABASE = {
  // Respiratory symptoms
  'cough': {
    category: 'respiratory',
    severity: 'mild',
    commonCauses: ['common cold', 'flu', 'allergies', 'bronchitis'],
    redFlags: ['blood in cough', 'severe chest pain', 'difficulty breathing']
  },
  'shortness of breath': {
    category: 'respiratory',
    severity: 'moderate',
    commonCauses: ['asthma', 'anxiety', 'heart problems', 'lung infection'],
    redFlags: ['severe difficulty breathing', 'chest pain', 'blue lips']
  },
  'chest pain': {
    category: 'cardiovascular',
    severity: 'high',
    commonCauses: ['muscle strain', 'acid reflux', 'anxiety', 'heart problems'],
    redFlags: ['crushing chest pain', 'pain radiating to arm', 'sweating with chest pain']
  },
  
  // Gastrointestinal symptoms
  'nausea': {
    category: 'gastrointestinal',
    severity: 'mild',
    commonCauses: ['food poisoning', 'motion sickness', 'pregnancy', 'medication side effect'],
    redFlags: ['severe dehydration', 'blood in vomit', 'severe abdominal pain']
  },
  'abdominal pain': {
    category: 'gastrointestinal',
    severity: 'moderate',
    commonCauses: ['indigestion', 'gas', 'food poisoning', 'appendicitis'],
    redFlags: ['severe pain', 'fever with pain', 'vomiting blood']
  },
  'diarrhea': {
    category: 'gastrointestinal',
    severity: 'mild',
    commonCauses: ['food poisoning', 'viral infection', 'medication side effect', 'stress'],
    redFlags: ['blood in stool', 'severe dehydration', 'high fever']
  },
  
  // Neurological symptoms
  'headache': {
    category: 'neurological',
    severity: 'mild',
    commonCauses: ['tension', 'dehydration', 'stress', 'migraine'],
    redFlags: ['sudden severe headache', 'headache with fever and stiff neck', 'vision changes']
  },
  'dizziness': {
    category: 'neurological',
    severity: 'moderate',
    commonCauses: ['dehydration', 'low blood pressure', 'inner ear problems', 'medication side effect'],
    redFlags: ['fainting', 'severe headache with dizziness', 'chest pain with dizziness']
  },
  
  // General symptoms
  'fever': {
    category: 'general',
    severity: 'moderate',
    commonCauses: ['viral infection', 'bacterial infection', 'flu', 'cold'],
    redFlags: ['very high fever (>103°F)', 'fever with stiff neck', 'difficulty breathing with fever']
  },
  'fatigue': {
    category: 'general',
    severity: 'mild',
    commonCauses: ['lack of sleep', 'stress', 'viral infection', 'anemia'],
    redFlags: ['extreme fatigue with chest pain', 'fatigue with shortness of breath', 'unexplained weight loss']
  }
};

// Medication recommendations based on symptoms
const MEDICATION_RECOMMENDATIONS = {
  'cough': [
    { name: 'Dextromethorphan', type: 'OTC', dosage: '15-30mg every 4-6 hours', notes: 'For dry cough' },
    { name: 'Guaifenesin', type: 'OTC', dosage: '200-400mg every 4 hours', notes: 'For productive cough' },
    { name: 'Honey', type: 'Natural', dosage: '1-2 teaspoons as needed', notes: 'Natural cough suppressant' }
  ],
  'headache': [
    { name: 'Acetaminophen', type: 'OTC', dosage: '500-1000mg every 4-6 hours', notes: 'Max 3000mg/day' },
    { name: 'Ibuprofen', type: 'OTC', dosage: '200-400mg every 4-6 hours', notes: 'Take with food' },
    { name: 'Aspirin', type: 'OTC', dosage: '325-650mg every 4 hours', notes: 'Avoid if under 18' }
  ],
  'fever': [
    { name: 'Acetaminophen', type: 'OTC', dosage: '500-1000mg every 4-6 hours', notes: 'Reduces fever and pain' },
    { name: 'Ibuprofen', type: 'OTC', dosage: '200-400mg every 4-6 hours', notes: 'Anti-inflammatory' }
  ],
  'nausea': [
    { name: 'Dramamine', type: 'OTC', dosage: '50-100mg every 4-6 hours', notes: 'For motion sickness' },
    { name: 'Ginger', type: 'Natural', dosage: '250mg 4 times daily', notes: 'Natural anti-nausea' },
    { name: 'Pepto-Bismol', type: 'OTC', dosage: '30ml every 30-60 minutes', notes: 'For stomach upset' }
  ],
  'diarrhea': [
    { name: 'Loperamide', type: 'OTC', dosage: '2mg after each loose stool', notes: 'Max 8mg/day' },
    { name: 'Pepto-Bismol', type: 'OTC', dosage: '30ml every 30-60 minutes', notes: 'For stomach upset' }
  ]
};

// Risk assessment based on symptoms and patient factors
function assessRisk(symptoms, patientAge, existingConditions = []) {
  let riskScore = 0;
  let redFlags = [];
  let recommendations = [];

  symptoms.forEach(symptom => {
    const symptomData = SYMPTOM_DATABASE[symptom.toLowerCase()];
    if (symptomData) {
      // Add base risk score
      switch (symptomData.severity) {
        case 'mild': riskScore += 1; break;
        case 'moderate': riskScore += 3; break;
        case 'high': riskScore += 5; break;
      }

      // Check for red flags
      redFlags.push(...symptomData.redFlags);
    }
  });

  // Age-based risk adjustment
  if (patientAge > 65) riskScore += 2;
  if (patientAge < 2) riskScore += 3;

  // Existing conditions risk adjustment
  if (existingConditions.includes('diabetes')) riskScore += 2;
  if (existingConditions.includes('heart disease')) riskScore += 3;
  if (existingConditions.includes('immunocompromised')) riskScore += 3;

  // Determine urgency level
  let urgencyLevel;
  let action;
  
  if (riskScore >= 8) {
    urgencyLevel = 'emergency';
    action = 'Seek immediate emergency care';
  } else if (riskScore >= 5) {
    urgencyLevel = 'urgent';
    action = 'See a doctor within 24 hours';
  } else if (riskScore >= 3) {
    urgencyLevel = 'moderate';
    action = 'Schedule appointment with doctor within 2-3 days';
  } else {
    urgencyLevel = 'low';
    action = 'Monitor symptoms, consider self-care';
  }

  return {
    riskScore,
    urgencyLevel,
    action,
    redFlags: [...new Set(redFlags)]
  };
}

// Generate medication recommendations
function getMedicationRecommendations(symptoms) {
  const recommendations = [];
  
  symptoms.forEach(symptom => {
    const meds = MEDICATION_RECOMMENDATIONS[symptom.toLowerCase()];
    if (meds) {
      recommendations.push({
        symptom: symptom,
        medications: meds
      });
    }
  });

  return recommendations;
}

// AI-powered symptom analysis using Together AI
async function analyzeSymptoms(symptoms, duration, severity, patientInfo) {
  try {
    const prompt = `
As a medical AI assistant, analyze these symptoms and provide a preliminary assessment:

Patient Information:
- Age: ${patientInfo.age}
- Gender: ${patientInfo.gender}
- Existing conditions: ${patientInfo.conditions?.join(', ') || 'None'}
- Current medications: ${patientInfo.medications?.join(', ') || 'None'}

Symptoms:
${symptoms.map((s, i) => `${i + 1}. ${s} (Duration: ${duration[i] || 'Not specified'}, Severity: ${severity[i] || 'Not specified'})`).join('\n')}

Please provide:
1. Most likely conditions (top 3)
2. Recommended next steps
3. Warning signs to watch for
4. Self-care recommendations
5. When to seek immediate medical attention

Keep the response professional but accessible to patients.
`;

    const response = await axios.post('https://api.together.xyz/v1/chat/completions', {
      model: 'mistralai/Mixtral-8x7B-Instruct-v0.1',
      messages: [
        {
          role: 'system',
          content: 'You are a medical AI assistant providing preliminary symptom analysis. Always emphasize that this is not a substitute for professional medical advice and patients should consult healthcare providers for proper diagnosis and treatment.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      max_tokens: 1000,
      temperature: 0.3
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.TOGETHER_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    return response.data.choices[0].message.content;
  } catch (error) {
    console.error('Error calling Together AI API:', error.message);
    if (error.response) {
      console.error('API Error Response:', error.response.data);
      console.error('API Error Status:', error.response.status);
    }

    // Fallback analysis based on symptoms
    const fallbackAnalysis = generateFallbackAnalysis(symptoms, duration, severity, patientInfo);
    return fallbackAnalysis;
  }
}

// Generate a fallback analysis when AI API is unavailable
function generateFallbackAnalysis(symptoms, duration, severity, patientInfo) {
  const analysisTemplate = `
PRELIMINARY SYMPTOM ASSESSMENT

Patient Profile:
- Age: ${patientInfo.age || 'Not specified'}
- Gender: ${patientInfo.gender || 'Not specified'}
- Existing conditions: ${patientInfo.conditions?.join(', ') || 'None reported'}

Reported Symptoms:
${symptoms.map((s, i) => `• ${s} (Duration: ${duration[i] || 'Not specified'}, Severity: ${severity[i] || 'Not specified'})`).join('\n')}

ASSESSMENT:

Most Likely Conditions:
Based on the reported symptoms, possible conditions may include:
1. Viral upper respiratory infection (if respiratory symptoms present)
2. Tension headache or migraine (if headache reported)
3. Gastroenteritis (if gastrointestinal symptoms present)

Recommended Next Steps:
• Monitor symptoms for changes in severity or duration
• Stay hydrated and get adequate rest
• Consider over-the-counter medications for symptom relief
• Keep a symptom diary to track progression

Warning Signs - Seek Immediate Medical Attention If:
• Symptoms worsen significantly or rapidly
• High fever (>103°F/39.4°C) develops
• Severe difficulty breathing or chest pain
• Signs of dehydration (dizziness, dry mouth, decreased urination)
• Persistent vomiting or inability to keep fluids down

Self-Care Recommendations:
• Rest and adequate sleep
• Maintain proper hydration
• Use appropriate over-the-counter medications as directed
• Apply heat/cold therapy for pain relief as appropriate

When to See a Doctor:
• Symptoms persist beyond 7-10 days
• Symptoms worsen despite self-care measures
• Development of new concerning symptoms
• If you have underlying health conditions that may complicate recovery

IMPORTANT DISCLAIMER:
This assessment is for informational purposes only and does not replace professional medical advice. Please consult with a healthcare provider for proper diagnosis and treatment, especially if symptoms are severe or persistent.
`;

  return analysisTemplate.trim();
}

// Find nearby healthcare providers (mock implementation)
function findNearbyProviders(location, urgencyLevel) {
  // This would integrate with real healthcare provider APIs
  const mockProviders = [
    {
      name: 'City Medical Center',
      type: 'Emergency Room',
      distance: '0.5 miles',
      phone: '(555) 123-4567',
      address: '123 Main St, City, State',
      waitTime: '15 minutes',
      acceptsInsurance: true
    },
    {
      name: 'QuickCare Urgent Care',
      type: 'Urgent Care',
      distance: '1.2 miles',
      phone: '(555) 234-5678',
      address: '456 Oak Ave, City, State',
      waitTime: '30 minutes',
      acceptsInsurance: true
    },
    {
      name: 'Dr. Smith Family Practice',
      type: 'Primary Care',
      distance: '2.1 miles',
      phone: '(555) 345-6789',
      address: '789 Pine St, City, State',
      waitTime: 'Next available: Tomorrow 2:00 PM',
      acceptsInsurance: true
    }
  ];

  // Filter based on urgency level
  if (urgencyLevel === 'emergency') {
    return mockProviders.filter(p => p.type === 'Emergency Room');
  } else if (urgencyLevel === 'urgent') {
    return mockProviders.filter(p => p.type === 'Emergency Room' || p.type === 'Urgent Care');
  } else {
    return mockProviders;
  }
}

// Telemedicine integration (mock implementation)
function getTelemedicineOptions(urgencyLevel) {
  const telemedicineProviders = [
    {
      name: 'TeleHealth Now',
      availability: 'Available now',
      cost: '$49',
      specialties: ['General Medicine', 'Urgent Care'],
      rating: 4.8,
      url: 'https://telehealthnow.com'
    },
    {
      name: 'Virtual Care Plus',
      availability: 'Next available: 15 minutes',
      cost: '$39',
      specialties: ['Family Medicine', 'Internal Medicine'],
      rating: 4.6,
      url: 'https://virtualcareplus.com'
    },
    {
      name: 'Doctor On Demand',
      availability: 'Available now',
      cost: '$75',
      specialties: ['Emergency Medicine', 'Psychiatry'],
      rating: 4.9,
      url: 'https://doctorondemand.com'
    }
  ];

  return telemedicineProviders;
}

module.exports = {
  assessRisk,
  getMedicationRecommendations,
  analyzeSymptoms,
  findNearbyProviders,
  getTelemedicineOptions,
  SYMPTOM_DATABASE,
  MEDICATION_RECOMMENDATIONS
};
