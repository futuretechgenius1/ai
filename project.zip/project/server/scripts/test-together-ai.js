const Together = require('together-ai');

async function testTogetherAI() {
  try {
    console.log('Testing Together AI with new model...');
    
    const together = new Together({
      apiKey: '7323b782a40ca2bdbdf780016aeb8662befc0894c9f4e5385bfcdde33f5147a1'
    });

    // Test the new model
    const response = await together.chat.completions.create({
      messages: [
        { role: "user", content: "What are the common side effects of aspirin?" }
      ],
      model: "mistralai/Mistral-7B-Instruct-v0.1",
      max_tokens: 200,
      temperature: 0.1
    });

    const content = response.choices[0]?.message?.content;
    
    if (content) {
      console.log('✅ Together AI working with new model!');
      console.log('Response:', content);
    } else {
      console.log('❌ No response content received');
    }

  } catch (error) {
    console.error('❌ Together AI test failed:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
    }
  }
}

testTogetherAI();
