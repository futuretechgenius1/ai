const mysql = require('mysql2/promise');
require('dotenv').config();

async function checkPrescriptionsTable() {
  const dbConfig = {
    host: process.env.DB_HOST || 'srv1148.hstgr.io',
    user: process.env.DB_USER || 'u530425252_cigna',
    password: process.env.DB_PASSWORD || 'Anirudh@k28',
    database: process.env.DB_NAME || 'u530425252_cigna',
  };

  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to database');

    // Check prescriptions table structure
    try {
      const [columns] = await connection.execute('DESCRIBE prescriptions');
      console.log('\n📋 Prescriptions table structure:');
      columns.forEach(col => {
        console.log(`  - ${col.Field} (${col.Type}) ${col.Null === 'NO' ? 'NOT NULL' : 'NULL'} ${col.Key ? col.Key : ''}`);
      });
      
      // Check if there are any prescriptions
      const [prescriptions] = await connection.execute('SELECT COUNT(*) as count FROM prescriptions');
      console.log(`\n📊 Existing prescriptions count: ${prescriptions[0].count}`);
      
      if (prescriptions[0].count > 0) {
        const [prescList] = await connection.execute('SELECT id, user_id, medication_id, dosage, frequency FROM prescriptions LIMIT 5');
        console.log('\n💊 Sample prescriptions:');
        prescList.forEach(presc => {
          console.log(`  - ID: ${presc.id}, User: ${presc.user_id}, Medication: ${presc.medication_id}, Dosage: ${presc.dosage}, Frequency: ${presc.frequency}`);
        });
      }
    } catch (error) {
      console.log('\n❌ Prescriptions table error:', error.message);
    }

    await connection.end();
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

checkPrescriptionsTable();
