const mysql = require('mysql2/promise');
require('dotenv').config();

async function checkTables() {
  const dbConfig = {
    host: process.env.DB_HOST || 'srv1148.hstgr.io',
    user: process.env.DB_USER || 'u530425252_cigna',
    password: process.env.DB_PASSWORD || 'Anirudh@k28',
    database: process.env.DB_NAME || 'u530425252_cigna',
  };

  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to database');

    // Check what tables exist
    const [tables] = await connection.execute('SHOW TABLES');
    console.log('\n📋 Available tables:');
    tables.forEach(table => {
      console.log('  -', Object.values(table)[0]);
    });

    // Check users table structure if it exists
    try {
      const [columns] = await connection.execute('DESCRIBE users');
      console.log('\n👤 Users table structure:');
      columns.forEach(col => {
        console.log(`  - ${col.Field} (${col.Type}) ${col.Null === 'NO' ? 'NOT NULL' : 'NULL'} ${col.Key ? col.Key : ''}`);
      });
    } catch (error) {
      console.log('\n❌ Users table does not exist');
    }

    // Check if there are any existing users
    try {
      const [users] = await connection.execute('SELECT COUNT(*) as count FROM users');
      console.log(`\n📊 Existing users count: ${users[0].count}`);
      
      if (users[0].count > 0) {
        const [userList] = await connection.execute('SELECT id, email, first_name, last_name FROM users LIMIT 5');
        console.log('\n👥 Existing users:');
        userList.forEach(user => {
          console.log(`  - ID: ${user.id}, Email: ${user.email}, Name: ${user.first_name} ${user.last_name}`);
        });
      }
    } catch (error) {
      console.log('\n❌ Could not check users:', error.message);
    }

    await connection.end();
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

checkTables();
