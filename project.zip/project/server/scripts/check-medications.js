const mysql = require('mysql2/promise');
require('dotenv').config();

async function checkMedicationsTable() {
  const dbConfig = {
    host: process.env.DB_HOST || 'srv1148.hstgr.io',
    user: process.env.DB_USER || 'u530425252_cigna',
    password: process.env.DB_PASSWORD || 'Anirudh@k28',
    database: process.env.DB_NAME || 'u530425252_cigna',
  };

  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to database');

    // Check medications table structure
    try {
      const [columns] = await connection.execute('DESCRIBE medications');
      console.log('\n💊 Medications table structure:');
      columns.forEach(col => {
        console.log(`  - ${col.Field} (${col.Type}) ${col.Null === 'NO' ? 'NOT NULL' : 'NULL'} ${col.Key ? col.Key : ''}`);
      });
    } catch (error) {
      console.log('\n❌ Medications table does not exist');
    }

    // Check reminders table structure
    try {
      const [columns] = await connection.execute('DESCRIBE reminders');
      console.log('\n⏰ Reminders table structure:');
      columns.forEach(col => {
        console.log(`  - ${col.Field} (${col.Type}) ${col.Null === 'NO' ? 'NOT NULL' : 'NULL'} ${col.Key ? col.Key : ''}`);
      });
    } catch (error) {
      console.log('\n❌ Reminders table does not exist');
    }

    // Check medication_history table structure
    try {
      const [columns] = await connection.execute('DESCRIBE medication_history');
      console.log('\n📊 Medication History table structure:');
      columns.forEach(col => {
        console.log(`  - ${col.Field} (${col.Type}) ${col.Null === 'NO' ? 'NOT NULL' : 'NULL'} ${col.Key ? col.Key : ''}`);
      });
    } catch (error) {
      console.log('\n❌ Medication History table does not exist');
    }

    await connection.end();
  } catch (error) {
    console.error('❌ Error:', error);
  }
}

checkMedicationsTable();
