const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

async function createTestUser() {
  const dbConfig = {
    host: process.env.DB_HOST || 'srv1148.hstgr.io',
    user: process.env.DB_USER || 'u530425252_cigna',
    password: process.env.DB_PASSWORD || 'Anirudh@k28',
    database: process.env.DB_NAME || 'u530425252_cigna',
  };

  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to database');

    // Test user credentials
    const testUser = {
      email: 'demo@pharmacist.com',
      password: 'demo123',
      firstName: 'Demo',
      lastName: 'User',
      memberId: 'DEMO001',
      planType: 'Premium'
    };

    // Check if user already exists
    const [existingUsers] = await connection.execute(
      'SELECT id FROM users WHERE email = ?',
      [testUser.email]
    );

    if (existingUsers.length > 0) {
      console.log('Test user already exists!');
      console.log('Email:', testUser.email);
      console.log('Password:', testUser.password);
      await connection.end();
      return;
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(testUser.password, 10);

    // Insert test user
    const [result] = await connection.execute(
      `INSERT INTO users (email, password_hash, first_name, last_name, member_id, plan_type)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        testUser.email,
        hashedPassword,
        testUser.firstName,
        testUser.lastName,
        testUser.memberId,
        testUser.planType
      ]
    );

    console.log('✅ Test user created successfully!');
    console.log('📧 Email:', testUser.email);
    console.log('🔑 Password:', testUser.password);
    console.log('👤 Name:', testUser.firstName, testUser.lastName);
    console.log('🆔 User ID:', result.insertId);

    // Add some sample medications for the test user
    const sampleMedications = [
      {
        name: 'Metformin',
        generic_name: 'Metformin HCl',
        dosage: '500mg',
        frequency: 'Twice daily',
        instructions: 'Take with meals',
        start_date: '2024-01-01',
        prescriber: 'Dr. Smith',
        pharmacy: 'CVS Pharmacy',
        refills_remaining: 3
      },
      {
        name: 'Lisinopril',
        generic_name: 'Lisinopril',
        dosage: '10mg',
        frequency: 'Once daily',
        instructions: 'Take in the morning',
        start_date: '2024-01-01',
        prescriber: 'Dr. Johnson',
        pharmacy: 'Walgreens',
        refills_remaining: 5
      },
      {
        name: 'Aspirin',
        generic_name: 'Acetylsalicylic acid',
        dosage: '81mg',
        frequency: 'Once daily',
        instructions: 'Take with food',
        start_date: '2024-01-01',
        prescriber: 'Dr. Smith',
        pharmacy: 'CVS Pharmacy',
        refills_remaining: 2
      }
    ];

    for (const med of sampleMedications) {
      await connection.execute(
        `INSERT INTO medications (user_id, name, generic_name, dosage, frequency, instructions, start_date, prescriber, pharmacy, refills_remaining) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          result.insertId,
          med.name,
          med.generic_name,
          med.dosage,
          med.frequency,
          med.instructions,
          med.start_date,
          med.prescriber,
          med.pharmacy,
          med.refills_remaining
        ]
      );
    }

    console.log('✅ Sample medications added!');

    // Add some sample reminders
    const sampleReminders = [
      {
        medication_id: 1, // Will be auto-incremented
        reminder_time: '08:00',
        days_of_week: '1,2,3,4,5,6,7',
        sms_enabled: false
      },
      {
        medication_id: 2,
        reminder_time: '09:00',
        days_of_week: '1,2,3,4,5,6,7',
        sms_enabled: false
      }
    ];

    // Get the medication IDs for the user
    const [medications] = await connection.execute(
      'SELECT id FROM medications WHERE user_id = ? ORDER BY id',
      [result.insertId]
    );

    for (let i = 0; i < sampleReminders.length && i < medications.length; i++) {
      await connection.execute(
        'INSERT INTO reminders (user_id, medication_id, reminder_time, days_of_week, sms_enabled) VALUES (?, ?, ?, ?, ?)',
        [
          result.insertId,
          medications[i].id,
          sampleReminders[i].reminder_time,
          sampleReminders[i].days_of_week,
          sampleReminders[i].sms_enabled
        ]
      );
    }

    console.log('✅ Sample reminders added!');

    await connection.end();
    console.log('\n🎉 Test user setup complete! You can now login with:');
    console.log('📧 Email: test@pharmacist.com');
    console.log('🔑 Password: password123');

  } catch (error) {
    console.error('❌ Error creating test user:', error);
  }
}

createTestUser();
