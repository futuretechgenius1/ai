const axios = require('axios');

async function testRemindersAPI() {
  try {
    console.log('Testing Reminders API...');
    
    // First login to get token
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'demo@pharmacist.com',
      password: 'demo123'
    });
    
    const token = loginResponse.data.token;
    console.log('✅ Login successful');
    
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    
    // Test reminders endpoint
    const remindersResponse = await axios.get('http://localhost:5000/api/reminders', { headers });
    console.log('✅ Reminders API working');
    console.log('📋 Reminders data structure:');
    
    if (remindersResponse.data.length > 0) {
      const reminder = remindersResponse.data[0];
      console.log('Sample reminder:', JSON.stringify(reminder, null, 2));
    } else {
      console.log('No reminders found');
    }
    
    // Test medications endpoint
    const medicationsResponse = await axios.get('http://localhost:5000/api/medications', { headers });
    console.log('✅ Medications API working');
    console.log('💊 Medications data structure:');
    
    if (medicationsResponse.data.length > 0) {
      const medication = medicationsResponse.data[0];
      console.log('Sample medication:', JSON.stringify(medication, null, 2));
    } else {
      console.log('No medications found');
    }
    
  } catch (error) {
    console.error('❌ API test failed:', error.response?.data || error.message);
  }
}

testRemindersAPI();
