const axios = require('axios');

async function testRegistration() {
  try {
    console.log('Testing registration endpoint...');
    
    const testUser = {
      email: 'test@example.com',
      password: 'testpassword123',
      firstName: 'Test',
      lastName: 'User'
    };

    const response = await axios.post('http://localhost:5000/api/auth/register', testUser);
    
    console.log('✅ Registration successful!');
    console.log('Response:', response.data);
    
  } catch (error) {
    if (error.response) {
      console.error('❌ Registration failed:', error.response.status, error.response.data);
    } else {
      console.error('❌ Registration failed:', error.message);
    }
  }
}

testRegistration();
