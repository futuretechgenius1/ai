const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
require('dotenv').config();

async function createSimpleUser() {
  const dbConfig = {
    host: process.env.DB_HOST || 'srv1148.hstgr.io',
    user: process.env.DB_USER || 'u530425252_cigna',
    password: process.env.DB_PASSWORD || 'Anirudh@k28',
    database: process.env.DB_NAME || 'u530425252_cigna',
  };

  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to database');

    // Test user credentials
    const testUser = {
      email: 'pharmacist@demo.com',
      password: 'demo123',
      firstName: 'Pharmacist',
      lastName: 'Demo',
      memberId: 'PHARM001',
      planType: 'Premium'
    };

    // Check if user already exists
    const [existingUsers] = await connection.execute(
      'SELECT id FROM users WHERE email = ?',
      [testUser.email]
    );

    if (existingUsers.length > 0) {
      console.log('✅ User already exists!');
      console.log('📧 Email:', testUser.email);
      console.log('🔑 Password:', testUser.password);
      await connection.end();
      return;
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(testUser.password, 10);

    // Insert test user
    const [result] = await connection.execute(
      `INSERT INTO users (email, password_hash, first_name, last_name, member_id, plan_type) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [
        testUser.email,
        hashedPassword,
        testUser.firstName,
        testUser.lastName,
        testUser.memberId,
        testUser.planType
      ]
    );

    console.log('✅ Test user created successfully!');
    console.log('📧 Email:', testUser.email);
    console.log('🔑 Password:', testUser.password);
    console.log('👤 Name:', testUser.firstName, testUser.lastName);
    console.log('🆔 User ID:', result.insertId);

    await connection.end();
    console.log('\n🎉 You can now login with:');
    console.log('📧 Email: pharmacist@demo.com');
    console.log('🔑 Password: demo123');

  } catch (error) {
    console.error('❌ Error creating user:', error);
  }
}

createSimpleUser();
