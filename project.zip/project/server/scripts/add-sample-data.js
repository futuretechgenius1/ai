const mysql = require('mysql2/promise');
require('dotenv').config();

async function addSampleData() {
  const dbConfig = {
    host: process.env.DB_HOST || 'srv1148.hstgr.io',
    user: process.env.DB_USER || 'u530425252_cigna',
    password: process.env.DB_PASSWORD || 'Anirudh@k28',
    database: process.env.DB_NAME || 'u530425252_cigna',
  };

  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to database');

    // Get the demo user ID
    const [users] = await connection.execute(
      'SELECT id FROM users WHERE email = ?',
      ['demo@pharmacist.com']
    );

    if (users.length === 0) {
      console.log('❌ Demo user not found');
      await connection.end();
      return;
    }

    const userId = users[0].id;
    console.log('✅ Found demo user with ID:', userId);

    // Add sample prescriptions
    const samplePrescriptions = [
      {
        medication_name: 'Metformin',
        dosage: '500mg',
        frequency: 'Twice daily',
        instructions: 'Take with meals to reduce stomach upset',
        prescriber_name: 'Dr. Sarah Johnson',
        prescriber_contact: 'sarah.johnson@healthcenter.com',
        duration_days: 90,
        refills_remaining: 3
      },
      {
        medication_name: 'Lisinopril',
        dosage: '10mg',
        frequency: 'Once daily',
        instructions: 'Take in the morning, preferably at the same time each day',
        prescriber_name: 'Dr. Michael Chen',
        prescriber_contact: 'michael.chen@cardiology.com',
        duration_days: 30,
        refills_remaining: 5
      },
      {
        medication_name: 'Aspirin',
        dosage: '81mg',
        frequency: 'Once daily',
        instructions: 'Take with food to prevent stomach irritation',
        prescriber_name: 'Dr. Sarah Johnson',
        prescriber_contact: 'sarah.johnson@healthcenter.com',
        duration_days: 365,
        refills_remaining: 2
      }
    ];

    const today = new Date().toISOString().split('T')[0];

    for (const prescription of samplePrescriptions) {
      const [result] = await connection.execute(
        `INSERT INTO prescriptions (user_id, medication_name, dosage, frequency, instructions, prescriber_name, prescriber_contact, prescription_date, start_date, duration_days, refills_remaining, is_active)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE)`,
        [
          userId,
          prescription.medication_name,
          prescription.dosage,
          prescription.frequency,
          prescription.instructions,
          prescription.prescriber_name,
          prescription.prescriber_contact,
          today,
          today,
          prescription.duration_days,
          prescription.refills_remaining
        ]
      );
      console.log(`✅ Added prescription: ${prescription.medication_name} (ID: ${result.insertId})`);
    }

    // Add sample reminders
    const [prescriptions] = await connection.execute(
      'SELECT id, medication_name FROM prescriptions WHERE user_id = ?',
      [userId]
    );

    const sampleReminders = [
      {
        reminder_type: 'dose',
        scheduled_time: new Date(Date.now() + 60 * 60 * 1000).toISOString(), // 1 hour from now
        message: 'Time to take your Metformin (500mg)'
      },
      {
        reminder_type: 'dose',
        scheduled_time: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
        message: 'Time to take your Lisinopril (10mg)'
      }
    ];

    for (let i = 0; i < sampleReminders.length && i < prescriptions.length; i++) {
      const reminder = sampleReminders[i];
      const prescription = prescriptions[i];
      
      const [result] = await connection.execute(
        'INSERT INTO reminders (user_id, prescription_id, reminder_type, scheduled_time, message, is_sent) VALUES (?, ?, ?, ?, ?, FALSE)',
        [
          userId,
          prescription.id,
          reminder.reminder_type,
          reminder.scheduled_time,
          reminder.message
        ]
      );
      console.log(`✅ Added reminder for ${prescription.medication_name} (ID: ${result.insertId})`);
    }

    // Add sample medication history
    const sampleHistory = [
      {
        medication_id: 1, // Will use the first medication from the medications table
        action: 'taken',
        notes: 'Taken as prescribed with breakfast'
      },
      {
        medication_id: 1,
        action: 'missed',
        notes: 'Forgot to take morning dose'
      }
    ];

    // Get some medications from the reference table
    const [medications] = await connection.execute(
      'SELECT id FROM medications LIMIT 2'
    );

    for (let i = 0; i < sampleHistory.length && i < medications.length; i++) {
      const history = sampleHistory[i];
      const medication = medications[i];
      
      const [result] = await connection.execute(
        'INSERT INTO medication_history (user_id, medication_id, action, notes) VALUES (?, ?, ?, ?)',
        [
          userId,
          medication.id,
          history.action,
          history.notes
        ]
      );
      console.log(`✅ Added medication history entry (ID: ${result.insertId})`);
    }

    await connection.end();
    console.log('\n🎉 Sample data added successfully!');
    console.log('You can now test the application with sample prescriptions, reminders, and history.');

  } catch (error) {
    console.error('❌ Error adding sample data:', error);
  }
}

addSampleData();
