const axios = require('axios');

async function testAPI() {
  try {
    console.log('Testing API endpoints...');
    
    // First login to get token
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'demo@pharmacist.com',
      password: 'demo123'
    });
    
    const token = loginResponse.data.token;
    console.log('✅ Login successful, token received');
    
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    
    // Test medications endpoint
    try {
      const medicationsResponse = await axios.get('http://localhost:5000/api/medications', { headers });
      console.log('✅ Medications endpoint working:', medicationsResponse.data.length, 'medications found');
    } catch (error) {
      console.error('❌ Medications endpoint failed:', error.response?.data || error.message);
    }
    
    // Test reminders endpoint
    try {
      const remindersResponse = await axios.get('http://localhost:5000/api/reminders', { headers });
      console.log('✅ Reminders endpoint working:', remindersResponse.data.length, 'reminders found');
    } catch (error) {
      console.error('❌ Reminders endpoint failed:', error.response?.data || error.message);
    }
    
    // Test medication history endpoint
    try {
      const historyResponse = await axios.get('http://localhost:5000/api/medication-history', { headers });
      console.log('✅ Medication history endpoint working:', historyResponse.data.length, 'history entries found');
    } catch (error) {
      console.error('❌ Medication history endpoint failed:', error.response?.data || error.message);
    }
    
  } catch (error) {
    console.error('❌ API test failed:', error.response?.data || error.message);
  }
}

testAPI();
