const axios = require('axios');

async function testRemindersCRUD() {
  try {
    console.log('Testing Reminders CRUD operations...');
    
    // First login to get token
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'demo@pharmacist.com',
      password: 'demo123'
    });
    
    const token = loginResponse.data.token;
    console.log('✅ Login successful');
    
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
    
    // Get prescriptions first
    const prescriptionsResponse = await axios.get('http://localhost:5000/api/medications', { headers });
    const prescriptions = prescriptionsResponse.data;
    
    if (prescriptions.length === 0) {
      console.log('❌ No prescriptions found to create reminders for');
      return;
    }
    
    console.log(`✅ Found ${prescriptions.length} prescriptions`);
    
    // Test CREATE reminder
    const newReminder = {
      prescriptionId: prescriptions[0].id,
      reminderType: 'dose',
      scheduledTime: new Date(Date.now() + 60 * 60 * 1000).toISOString(), // 1 hour from now
      message: 'Test reminder message'
    };
    
    const createResponse = await axios.post('http://localhost:5000/api/reminders', newReminder, { headers });
    console.log('✅ CREATE reminder successful:', createResponse.data);
    
    const reminderId = createResponse.data.reminderId;
    
    // Test READ reminders
    const readResponse = await axios.get('http://localhost:5000/api/reminders', { headers });
    console.log('✅ READ reminders successful:', readResponse.data.length, 'reminders found');
    
    // Test UPDATE reminder
    const updateData = {
      scheduledTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
      message: 'Updated reminder message',
      reminderType: 'dose'
    };
    
    const updateResponse = await axios.put(`http://localhost:5000/api/reminders/${reminderId}`, updateData, { headers });
    console.log('✅ UPDATE reminder successful:', updateResponse.data);
    
    // Test DELETE reminder
    const deleteResponse = await axios.delete(`http://localhost:5000/api/reminders/${reminderId}`, { headers });
    console.log('✅ DELETE reminder successful:', deleteResponse.data);
    
    console.log('\n🎉 All Reminder CRUD operations working correctly!');
    
  } catch (error) {
    if (error.response) {
      console.error('❌ Test failed:', error.response.status, error.response.data);
    } else {
      console.error('❌ Test failed:', error.message);
    }
  }
}

testRemindersCRUD();
