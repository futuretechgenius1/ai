const Together = require('together-ai');

async function testDrugInteractions() {
  try {
    console.log('Testing Drug Interaction Checker...');
    
    const together = new Together({
      apiKey: '7323b782a40ca2bdbdf780016aeb8662befc0894c9f4e5385bfcdde33f5147a1'
    });

    const medications = ['Aspirin 81mg', 'Warfarin 5mg', 'Ibuprofen 200mg'];
    const medicationList = medications.join(', ');
    
    const prompt = `Analyze drug interactions for these medications: ${medicationList}

Please provide a comprehensive analysis in JSON format with this structure:
[
  {
    "severity": "low|moderate|high|severe",
    "description": "detailed description of the interaction",
    "recommendation": "clinical recommendation",
    "medications": ["med1", "med2"]
  }
]

If no significant interactions are found, return an empty array: []`;

    const response = await together.chat.completions.create({
      messages: [{ role: "user", content: prompt }],
      model: "mistralai/Mistral-7B-Instruct-v0.1",
      max_tokens: 1500,
      temperature: 0.1
    });

    const content = response.choices[0]?.message?.content;
    
    if (content) {
      console.log('✅ AI Response received');
      console.log('Raw response:', content);
      
      try {
        const jsonStart = content.indexOf('[');
        const jsonEnd = content.lastIndexOf(']') + 1;
        
        if (jsonStart === -1 || jsonEnd === 0) {
          throw new Error('No valid JSON found in response');
        }
        
        const jsonStr = content.slice(jsonStart, jsonEnd);
        const parsedInteractions = JSON.parse(jsonStr);
        
        console.log('✅ JSON parsing successful');
        console.log('Interactions found:', parsedInteractions.length);
        
        if (parsedInteractions.length > 0) {
          console.log('Sample interaction:', JSON.stringify(parsedInteractions[0], null, 2));
        }
        
      } catch (parseError) {
        console.error('❌ JSON parsing failed:', parseError.message);
        console.log('Attempting to extract JSON manually...');
      }
    } else {
      console.log('❌ No response content received');
    }

  } catch (error) {
    console.error('❌ Drug interaction test failed:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
    }
  }
}

testDrugInteractions();
