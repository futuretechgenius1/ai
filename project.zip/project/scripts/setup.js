#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

console.log('🚀 Setting up Medication Management Application...\n');

// Check if .env file exists in server directory
const envPath = path.join(__dirname, '../server/.env');
const envExamplePath = path.join(__dirname, '../server/.env.example');

function createEnvFile() {
  const envContent = `# Database Configuration
DB_HOST=srv1148.hstgr.io
DB_USER=u530425252_cigna
DB_PASSWORD=Anirudh@k28
DB_NAME=u530425252_cigna

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production

# Together AI Configuration
TOGETHER_API_KEY=7323b782a40ca2bdbdf780016aeb8662befc0894c9f4e5385bfcdde33f5147a1

# Twilio Configuration (Optional)
TWILIO_ACCOUNT_SID=your-twilio-account-sid
TWILIO_AUTH_TOKEN=your-twilio-auth-token
TWILIO_PHONE_NUMBER=your-twilio-phone-number

# Server Configuration
PORT=5000
NODE_ENV=development
`;

  try {
    fs.writeFileSync(envPath, envContent);
    console.log('✅ Created server/.env file with default configuration');
  } catch (error) {
    console.error('❌ Failed to create .env file:', error.message);
  }
}

function runCommand(command, description) {
  return new Promise((resolve, reject) => {
    console.log(`🔄 ${description}...`);
    
    const [cmd, ...args] = command.split(' ');
    const child = spawn(cmd, args, {
      stdio: 'inherit',
      shell: true,
      cwd: process.cwd()
    });
    
    child.on('error', (error) => {
      console.error(`❌ Error: ${error.message}`);
      reject(error);
    });
    
    child.on('close', (code) => {
      if (code === 0) {
        console.log(`✅ ${description} completed\n`);
        resolve();
      } else {
        console.log(`❌ ${description} failed with code ${code}\n`);
        reject(new Error(`Command failed with code ${code}`));
      }
    });
  });
}

async function setup() {
  try {
    // Check if .env exists
    if (!fs.existsSync(envPath)) {
      console.log('📝 Setting up environment configuration...');
      createEnvFile();
      console.log('⚠️  Please review and update server/.env with your actual credentials\n');
    } else {
      console.log('✅ Environment file already exists\n');
    }
    
    // Install dependencies
    await runCommand('npm run install:all', 'Installing all dependencies');
    
    console.log('🎉 Setup completed successfully!\n');
    console.log('📋 Next steps:');
    console.log('1. Review and update server/.env with your database credentials');
    console.log('2. Run "npm run dev" to start the development servers');
    console.log('3. Open http://localhost:5173 in your browser\n');
    
  } catch (error) {
    console.error('❌ Setup failed:', error.message);
    process.exit(1);
  }
}

setup();
