#!/usr/bin/env node

const { spawn } = require('child_process');
const path = require('path');

const commands = {
  'install': {
    description: 'Install all dependencies',
    command: 'npm run install:all'
  },
  'dev': {
    description: 'Start development servers',
    command: 'npm run dev'
  },
  'frontend': {
    description: 'Start only frontend',
    command: 'npm run dev:frontend'
  },
  'backend': {
    description: 'Start only backend',
    command: 'npm run dev:backend'
  },
  'build': {
    description: 'Build frontend for production',
    command: 'npm run build'
  },
  'clean': {
    description: 'Clean all node_modules',
    command: 'npm run clean'
  },
  'test-api': {
    description: 'Test backend API endpoints',
    command: 'cd server && node scripts/test-api.js'
  },
  'test-reminders': {
    description: 'Test reminder CRUD operations',
    command: 'cd server && node scripts/test-reminders-crud.js'
  }
};

function showHelp() {
  console.log('\n🚀 Medication Management App - Development Helper\n');
  console.log('Available commands:\n');
  
  Object.entries(commands).forEach(([cmd, info]) => {
    console.log(`  ${cmd.padEnd(15)} - ${info.description}`);
  });
  
  console.log('\nUsage: node scripts/dev-helper.js <command>');
  console.log('Example: node scripts/dev-helper.js dev\n');
}

function runCommand(commandKey) {
  const command = commands[commandKey];
  
  if (!command) {
    console.error(`❌ Unknown command: ${commandKey}`);
    showHelp();
    process.exit(1);
  }
  
  console.log(`🔄 Running: ${command.description}`);
  console.log(`📝 Command: ${command.command}\n`);
  
  const [cmd, ...args] = command.command.split(' ');
  const child = spawn(cmd, args, {
    stdio: 'inherit',
    shell: true,
    cwd: process.cwd()
  });
  
  child.on('error', (error) => {
    console.error(`❌ Error: ${error.message}`);
    process.exit(1);
  });
  
  child.on('close', (code) => {
    if (code === 0) {
      console.log(`\n✅ Command completed successfully`);
    } else {
      console.log(`\n❌ Command failed with code ${code}`);
      process.exit(code);
    }
  });
}

// Main execution
const commandKey = process.argv[2];

if (!commandKey || commandKey === 'help' || commandKey === '--help' || commandKey === '-h') {
  showHelp();
} else {
  runCommand(commandKey);
}
